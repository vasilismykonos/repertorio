// apps/web/app/api/rooms/[room]/route.ts
import { NextResponse } from "next/server";

type ApiResponse = {
  success: boolean;
  message?: string;
};

function getRoomsBaseUrl(): string {
  const base =
    process.env.ROOMS_HTTP_BASE_URL ||
    process.env.NEXT_PUBLIC_ROOMS_HTTP_BASE_URL ||
    "http://localhost:4455";

  return base.replace(/\/+$/, "");
}

// DELETE /api/rooms/[room]
// Proxy σε Node /delete-room (POST), διαγράφει το room.
export async function DELETE(
  _req: Request,
  context: { params: { room?: string; rooms?: string } }
) {
  const rawParam =
    context.params?.room ?? context.params?.rooms ?? "";
  const room = decodeURIComponent(rawParam).trim();

  if (!room) {
    return NextResponse.json(
      {
        success: false,
        message: "Απαιτείται όνομα δωματίου.",
      } satisfies ApiResponse,
      { status: 400 }
    );
  }

  try {
    const upstream = await fetch(`${getRoomsBaseUrl()}/delete-room`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room }),
    });

    let upstreamJson: any = {};
    try {
      upstreamJson = await upstream.json();
    } catch {
      upstreamJson = {};
    }

    if (!upstream.ok || upstreamJson.success === false) {
      const status = upstream.status || 500;

      return NextResponse.json(
        {
          success: false,
          message:
            upstreamJson.message ||
            `Σφάλμα rooms server (HTTP ${status}).`,
        } satisfies ApiResponse,
        { status }
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: upstreamJson.message || "Το room διαγράφηκε.",
      } satisfies ApiResponse
    );
  } catch (err) {
    console.error("[DELETE /api/rooms/[room]] Σφάλμα:", err);
    return NextResponse.json(
      {
        success: false,
        message: "Αποτυχία επικοινωνίας με rooms server.",
      } satisfies ApiResponse,
      { status: 500 }
    );
  }
}
