"use client";

import { useCallback, useEffect, useState } from "react";

type Room = {
  room: string;
  userCount: number;
  hasPassword: boolean;
};

type RoomsClientProps = {
  initialRooms: Room[];
  isLoggedIn: boolean;
  isAdmin: boolean;
  initialCurrentRoom: string | null;
};

type ApiResponse = {
  success: boolean;
  message?: string;
};

/**
 * RoomsClient
 *
 * Ανάλογο του παλιού shortcode, αλλά σε React:
 *  - Φόρμα δημιουργίας room
 *  - Λίστα rooms με πλήθος χρηστών
 *  - Κουμπιά Σύνδεση / Αποσύνδεση / Διαγραφή
 *  - Επικοινωνία με:
 *      - GET    /api/rooms
 *      - POST   /api/rooms/create
 *      - POST   /api/rooms/join
 *      - POST   /api/rooms/disconnect
 *      - DELETE /api/rooms/[room]
 */

export default function RoomsClient({
  initialRooms,
  isLoggedIn,
  isAdmin,
  initialCurrentRoom,
}: RoomsClientProps) {
  const [rooms, setRooms] = useState<Room[]>(initialRooms);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusColor, setStatusColor] = useState<string | undefined>(
    undefined
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [currentRoom, setCurrentRoom] = useState<string | null>(
    initialCurrentRoom
  );

  // Φόρμες δημιουργίας / σύνδεσης
  const [createName, setCreateName] = useState("");
  const [createPassword, setCreatePassword] = useState("");
  const [passwords, setPasswords] = useState<Record<string, string>>({});

  // -------------------------------------------------
  // Utility: εμφάνιση status
  // -------------------------------------------------
  const showStatus = useCallback(
    (message: string, color?: string) => {
      setStatusMessage(message);
      setStatusColor(color);
      if (message) {
        setTimeout(() => {
          setStatusMessage(null);
          setStatusColor(undefined);
        }, 4000);
      }
    },
    [setStatusMessage, setStatusColor]
  );

  // -------------------------------------------------
  // Utility: ανανέωση λίστας rooms από το API
  // -------------------------------------------------
  const refreshRooms = useCallback(async () => {
    try {
      const res = await fetch("/api/rooms", { cache: "no-store" });
      if (!res.ok) {
        throw new Error("Αποτυχία φόρτωσης rooms");
      }
      const data = (await res.json()) as Room[];
      setRooms(data);
    } catch (err) {
      console.error("Σφάλμα στο refreshRooms:", err);
      showStatus("❌ Αποτυχία φόρτωσης rooms.", "#e57373");
    }
  }, [showStatus]);

  // -------------------------------------------------
  // Utility: bridge προς window.RepRoomsSwitchRoom (RoomsProvider)
  // -------------------------------------------------
  const callRepRoomsSwitch = (room: string | null, password: string) => {
    if (typeof window === "undefined") return;

    const fn = (window as any).RepRoomsSwitchRoom;
    if (typeof fn === "function") {
      fn(room, password);
    } else {
      console.warn(
        "[RoomsClient] RepRoomsSwitchRoom δεν βρέθηκε στο window."
      );
    }
  };

  // -------------------------------------------------
  // Αρχικό sync λίστας rooms
  // -------------------------------------------------
  useEffect(() => {
    setRooms(initialRooms);
    setCurrentRoom(initialCurrentRoom);
  }, [initialRooms, initialCurrentRoom]);

  // -------------------------------------------------
  // CREATE ROOM
  // -------------------------------------------------
  const handleCreateRoom = async () => {
    if (!isLoggedIn) {
      alert("Πρέπει να έχεις κάνει login για να δημιουργήσεις room.");
      return;
    }

    const room = createName.trim();
    const password = createPassword.trim();

    if (!room) {
      alert("Συμπλήρωσε όνομα room.");
      return;
    }

    if (/\s/.test(room)) {
      alert("Το όνομα του room δεν πρέπει να περιέχει κενά.");
      return;
    }

    setLoading(true);
    showStatus("⏳ Γίνεται δημιουργία room...", "#ccc");

    try {
      const res = await fetch("/api/rooms/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, password }),
      });

      const json = (await res.json()) as ApiResponse;
      if (!res.ok || !json.success) {
        showStatus(
          "❌ Δεν ήταν δυνατή η δημιουργία room: " +
            (json.message || "Άγνωστο σφάλμα."),
          "#e57373"
        );
        return;
      }

      showStatus("✅ Το room δημιουργήθηκε.", "#81c784");
      setCreateName("");
      setCreatePassword("");
      await refreshRooms();
    } catch (err: any) {
      alert("❌ Σφάλμα επικοινωνίας: " + err.message);
      showStatus("❌ Σφάλμα επικοινωνίας.", "#e57373");
    } finally {
      setLoading(false);
    }
  };

  // -------------------------------------------------
  // CONNECT / JOIN ROOM
  // -------------------------------------------------
  const handleConnectRoom = async (room: string, hasPassword: boolean) => {
    if (!isLoggedIn) {
      alert("Πρέπει να έχεις κάνει login για να συνδεθείς σε room.");
      return;
    }

    let password = "";
    if (hasPassword) {
      password = passwords[room] ?? "";
      if (!password) {
        const userInput = window.prompt(
          `Το room "${room}" έχει κωδικό. Δώσε password:`,
          ""
        );
        if (userInput === null) {
          return;
        }
        password = userInput.trim();
      }
    }

    setLoading(true);
    showStatus(`⏳ Σύνδεση στο room "${room}"...`, "#ccc");

    try {
      const res = await fetch("/api/rooms/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, password }),
      });

      const json = (await res.json()) as ApiResponse;
      if (!res.ok || !json.success) {
        showStatus(
          "❌ Δεν ήταν δυνατή η σύνδεση στο room: " +
            (json.message || "Άγνωστο σφάλμα."),
          "#e57373"
        );
        return;
      }

      if (hasPassword && password) {
        setPasswords((prev) => ({
          ...prev,
          [room]: password,
        }));
      }

      setCurrentRoom(room);
      callRepRoomsSwitch(room, password);

      showStatus(`✅ Συνδέθηκες στο room "${room}".`, "#81c784");
      await refreshRooms();
    } catch (err: any) {
      alert("❌ Σφάλμα επικοινωνίας: " + err.message);
      showStatus("❌ Σφάλμα επικοινωνίας.", "#e57373");
    } finally {
      setLoading(false);
    }
  };

  // -------------------------------------------------
  // DISCONNECT
  // -------------------------------------------------
  const handleDisconnect = async () => {
    if (!currentRoom) {
      return;
    }

    setLoading(true);
    showStatus("⏳ Αποσύνδεση από το room...", "#ccc");

    try {
      const res = await fetch("/api/rooms/disconnect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room: currentRoom }),
      });

      const json = (await res.json()) as ApiResponse;
      if (!json.success) {
        showStatus(
          "❌ Δεν ήταν δυνατή η αποσύνδεση από το room: " +
            (json.message || "Άγνωστο σφάλμα."),
          "#e57373"
        );
        return;
      }

      setCurrentRoom(null);
      callRepRoomsSwitch(null, "");

      showStatus("✅ Αποσυνδέθηκες από το room.", "#81c784");
      refreshRooms();
    } catch (err: any) {
      alert("❌ Σφάλμα επικοινωνίας: " + err.message);
      showStatus("❌ Σφάλμα επικοινωνίας.", "#e57373");
    } finally {
      setLoading(false);
    }
  };

  // -------------------------------------------------
  // DELETE ROOM (ADMIN ONLY)
  // -------------------------------------------------
  const handleDeleteRoom = async (room: string) => {
    if (!isAdmin) return;

    const ok = window.confirm(
      `Να διαγραφεί οριστικά το room "${room}" ; Όλοι οι συνδεδεμένοι χρήστες θα αποσυνδεθούν.`
    );
    if (!ok) return;

    setLoading(true);
    showStatus("⏳ Διαγραφή room...", "#ccc");

    try {
      const res = await fetch(`/api/rooms/${encodeURIComponent(room)}`, {
        method: "DELETE",
      });

      const json = (await res.json()) as ApiResponse;
      if (!json.success) {
        showStatus(
          "❌ Δεν ήταν δυνατή η διαγραφή room: " +
            (json.message || "Άγνωστο σφάλμα."),
          "#e57373"
        );
        return;
      }

      if (currentRoom === room) {
        setCurrentRoom(null);
        callRepRoomsSwitch(null, "");
      }

      showStatus("✅ Το room διαγράφηκε.", "#81c784");
      refreshRooms();
    } catch (err: any) {
      alert("❌ Σφάλμα επικοινωνίας: " + err.message);
      showStatus("❌ Σφάλμα επικοινωνίας.", "#e57373");
    } finally {
      setLoading(false);
    }
  };

  // -------------------------------------------------
  // Live ενημέρωση πλήθους από το WebSocket (RoomsProvider)
  // -------------------------------------------------
  useEffect(() => {
    if (typeof window === "undefined") return;

    const handler = (event: Event) => {
      const custom = event as CustomEvent<{
        room: string;
        count: number;
        deviceIds?: string[];
        users?: any[];
      }>;

      if (!custom.detail) return;

      const { room, count } = custom.detail;

      if (!room || typeof count !== "number") {
        return;
      }

      setRooms((prev) =>
        prev.map((r) =>
          r.room === room ? { ...r, userCount: count } : r
        )
      );
    };

    window.addEventListener(
      "rep_rooms_update_count",
      handler as EventListener
    );

    return () => {
      window.removeEventListener(
        "rep_rooms_update_count",
        handler as EventListener
      );
    };
  }, []);

  // Φιλτράρισμα λίστας rooms
  const filteredRooms = rooms.filter((r) =>
    r.room.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="rooms-container">
      {/* Φόρμα δημιουργίας room */}
      <div className="create-room-box">
        <h4>Δημιουργία νέου room</h4>
        <div className="create-room-fields">
          <input
            type="text"
            placeholder="Όνομα room (χωρίς κενά)"
            value={createName}
            onChange={(e) => setCreateName(e.target.value)}
            disabled={loading}
          />
          <input
            type="password"
            placeholder="Κωδικός (προαιρετικά)"
            value={createPassword}
            onChange={(e) => setCreatePassword(e.target.value)}
            disabled={loading}
          />
        </div>
        <button
          type="button"
          className="room-create-btn"
          onClick={handleCreateRoom}
          disabled={loading}
        >
          ➕ Δημιουργία room
        </button>
      </div>

      {/* Status bar */}
      {statusMessage && (
        <div
          className="rooms-status"
          style={{ backgroundColor: statusColor || "#424242" }}
        >
          {statusMessage}
        </div>
      )}

      {/* Αναζήτηση */}
      <div className="rooms-search-box">
        <input
          type="text"
          placeholder="Αναζήτηση room..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          disabled={loading}
        />
      </div>

      {/* Λίστα rooms */}
      <div className="rooms-list">
        {filteredRooms.length === 0 && (
          <div className="rooms-empty">Δεν υπάρχουν rooms.</div>
        )}

        {filteredRooms.map((r) => {
          const isCurrent =
            currentRoom &&
            currentRoom.toLowerCase() === r.room.toLowerCase();

          return (
            <div key={r.room} className="rooms-item">
              <div className="rooms-item-main">
                <div className="rooms-item-title">
                  <span className="rooms-room-name">{r.room}</span>
                  {r.hasPassword && (
                    <span className="rooms-room-lock" title="Έχει κωδικό">
                      🔒
                    </span>
                  )}
                </div>
                <div className="rooms-item-sub">
                  <span className="rooms-room-count">
                    Χρήστες: {r.userCount ?? 0}
                  </span>
                  {isCurrent && (
                    <span className="rooms-room-current">(τρέχον room)</span>
                  )}
                </div>
              </div>

              <div className="rooms-item-actions">
                <div className="rooms-item-actions-inner">
                  {!isCurrent && (
                    <button
                      type="button"
                      className="room-action-btn"
                      onClick={() =>
                        handleConnectRoom(r.room, r.hasPassword)
                      }
                      disabled={loading}
                    >
                      Σύνδεση
                    </button>
                  )}
                  {isCurrent && (
                    <button
                      type="button"
                      className="room-action-btn"
                      onClick={handleDisconnect}
                      disabled={loading}
                    >
                      Αποσύνδεση
                    </button>
                  )}
                  {isAdmin && (
                    <button
                      type="button"
                      className="room-action-btn room-delete-btn"
                      onClick={() => handleDeleteRoom(r.room)}
                      disabled={loading}
                    >
                      🗑️ Διαγραφή
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
