"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { useSession } from "next-auth/react";

type RoomsContextType = {
  wsConnected: boolean;
  currentRoom: string | null;
  switchRoom: (room: string | null, password?: string) => void;
  lastSyncId: number;
  ignoreSyncUntil: number;
};

const RoomsContext = createContext<RoomsContextType | undefined>(undefined);

// Σταθερό deviceId ανά browser (localStorage)
function getDeviceId(): string | null {
  if (typeof window === "undefined") return null;

  const key = "rep_device_id";
  let existing = window.localStorage.getItem(key);

  if (existing && existing.trim() !== "") {
    return existing;
  }

  const generated = "dev_" + Math.random().toString(36).slice(2, 10);
  try {
    window.localStorage.setItem(key, generated);
  } catch {
    // ignore
  }
  return generated;
}

// Τρέχον URL (για logging στον rooms server)
function getSenderUrl(): string | null {
  if (typeof window === "undefined") return null;
  return window.location.href;
}

// WebSocket URL (Nginx: /rooms-api/ws → rooms server)
function getWsUrl(): string | null {
  if (typeof window === "undefined") return null;

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const host = window.location.host;

  return `${protocol}://${host}/rooms-api/ws`;
}

export function RoomsProvider({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();

  const getUserMeta = () => {
    const anySession: any = session as any;
    const user = anySession?.user || null;

    const userId = user?.id ?? null;
    const username =
      user?.displayName ??
      user?.name ??
      user?.username ??
      user?.email ??
      null;

    return { userId, username };
  };

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [lastSyncId, setLastSyncId] = useState<number>(0);
  const [ignoreSyncUntil, setIgnoreSyncUntil] = useState<number>(0);

  // Αποθήκευση room σε localStorage + event
  const saveRoom = (room: string | null) => {
    if (typeof window === "undefined") return;

    if (room && room.trim() !== "") {
      window.localStorage.setItem("rep_current_room", room.trim());
    } else {
      window.localStorage.removeItem("rep_current_room");
    }

    const evt = new CustomEvent("rep_current_room_changed", {
      detail: { room: room || null },
    });
    window.dispatchEvent(evt);
  };

  // Αποστολή join στον WebSocket (με device_id / user_id / username)
  const sendJoin = (room: string, password: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    const deviceId = getDeviceId();
    const senderUrl = getSenderUrl();
    const { userId, username } = getUserMeta();

    const payload: any = {
      type: "join_room",
      room,
      password,
    };

    if (deviceId) {
      payload.device_id = deviceId;
      payload.deviceId = deviceId;
    }

    if (senderUrl) {
      payload.url = senderUrl;
      payload.sender_url = senderUrl;
    }

    if (userId) {
      payload.user_id = userId;
    }

    if (username) {
      payload.username = username;
    }

    wsRef.current.send(JSON.stringify(payload));
  };

  // Αποστολή leave_room
  const sendLeave = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    wsRef.current.send(
      JSON.stringify({
        type: "leave_room",
      })
    );
  };

  // Heartbeat (ping)
  const stopHeartbeat = () => {
    if (heartbeatRef.current) {
      clearInterval(heartbeatRef.current);
      heartbeatRef.current = null;
    }
  };

  const startHeartbeat = () => {
    stopHeartbeat();
    if (!wsRef.current) return;

    heartbeatRef.current = setInterval(() => {
      try {
        if (
          wsRef.current &&
          wsRef.current.readyState === WebSocket.OPEN
        ) {
          wsRef.current.send(JSON.stringify({ type: "ping" }));
        }
      } catch {
        // ignore
      }
    }, 20000);
  };

  // Reconnect logic
  const scheduleReconnect = () => {
    if (reconnectRef.current) return;

    reconnectRef.current = setTimeout(() => {
      reconnectRef.current = null;
      connectWS();
    }, 3000);
  };

  // Σύνδεση WebSocket (1 ενεργή σύνδεση)
  const connectWS = () => {
    if (typeof window === "undefined") return;

    if (
      wsRef.current &&
      (wsRef.current.readyState === WebSocket.OPEN ||
        wsRef.current.readyState === WebSocket.CONNECTING)
    ) {
      return;
    }

    const wsUrl = getWsUrl();
    if (!wsUrl) return;

    console.log("[RoomsProvider] connecting to", wsUrl);

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("[RoomsProvider] WebSocket open");
      setWsConnected(true);
      startHeartbeat();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data || typeof data !== "object") return;

        const t = (data as any).type || (data as any).action;

        if (t === "song_sync") {
          setLastSyncId(Date.now());
        }

        if (t === "update_count") {
          const room =
            (data as any).user_room ||
            (data as any).room ||
            null;
          const count =
            typeof (data as any).count === "number"
              ? (data as any).count
              : null;

          console.log(
            "[RoomsProvider] update_count",
            room,
            count,
            (data as any).deviceIds
          );

          if (room && typeof window !== "undefined" && count !== null) {
            const ev = new CustomEvent("rep_rooms_update_count", {
              detail: {
                room,
                count,
                deviceIds: (data as any).deviceIds ?? [],
                users: (data as any).users ?? [],
              },
            });
            window.dispatchEvent(ev);
          }
        }
      } catch (err) {
        console.warn("[RoomsProvider] failed to parse message", err);
      }
    };

    ws.onclose = (ev) => {
      console.log(
        "[RoomsProvider] WebSocket closed",
        ev.code,
        ev.reason
      );
      setWsConnected(false);
      stopHeartbeat();
      scheduleReconnect();
    };

    ws.onerror = (event) => {
      // ΔΕΝ κλείνουμε εμείς το socket εδώ, απλά κάνουμε log.
      console.error("[RoomsProvider] WebSocket error:", event);
    };
  };

  // MOUNT → load room from localStorage + connect WS
  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = window.localStorage.getItem("rep_current_room");
      if (stored && stored.trim() !== "") {
        setCurrentRoom(stored.trim());
      }
    }

    connectWS();

    return () => {
      stopHeartbeat();
      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {
          // ignore
        }
      }
      if (reconnectRef.current) {
        clearTimeout(reconnectRef.current);
        reconnectRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Όταν αλλάξει wsConnected ή currentRoom → κάνε join
  useEffect(() => {
    if (!wsConnected || !currentRoom) return;
    sendJoin(currentRoom, "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wsConnected, currentRoom]);

  // Public API: switchRoom
  const switchRoom = (room: string | null, password: string = "") => {
    if (!room || room.trim() === "") {
      sendLeave();
      setCurrentRoom(null);
      saveRoom(null);
      return;
    }

    const clean = room.trim();
    setCurrentRoom(clean);
    saveRoom(clean);

    sendJoin(clean, password);
  };

  // GLOBAL EXPOSE – για RoomsClient / WordPress compatibility
  useEffect(() => {
    if (typeof window === "undefined") return;

    (window as any).RepRoomsSwitchRoom = (
      room: string | null,
      pwd: string = ""
    ) => {
      switchRoom(room, pwd);
    };

    return () => {
      if (typeof window === "undefined") return;
      delete (window as any).RepRoomsSwitchRoom;
    };
  }, [switchRoom]);

  const value: RoomsContextType = {
    wsConnected,
    currentRoom,
    switchRoom,
    lastSyncId,
    ignoreSyncUntil,
  };

  return (
    <RoomsContext.Provider value={value}>
      {children}
    </RoomsContext.Provider>
  );
}

export function useRooms(): RoomsContextType {
  const ctx = useContext(RoomsContext);
  if (!ctx) {
    throw new Error("useRooms must be used within a RoomsProvider");
  }
  return ctx;
}
