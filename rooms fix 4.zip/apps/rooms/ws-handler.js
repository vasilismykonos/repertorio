/*
 * ws-handler.js – Implements the WebSocket protocol for rooms.
 *
 * Each connected browser tab initiates the connection by sending an
 * `init_connection` message (ή, στο νέο σύστημα, `type: "join_room"`)
 * με όνομα room, device ID, user ID και username.
 *
 * Ο server απαντά με `update_count` (και ως `type: "update_count"`)
 * και, αν χρειάζεται, με το τελευταίο `song_sync` (`type: "song_sync"`).
 */

function safeJSONParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

/**
 * Broadcast σε όλα τα sockets του room.
 * Αν δοθεί exceptDeviceId, δεν στέλνει στο συγκεκριμένο device.
 */
function broadcastToRoom(roomManager, room, payload, exceptDeviceId = null) {
  const message = JSON.stringify(payload);
  const clients = roomManager.getRoomClients(room);

  for (const client of clients) {
    if (!client || client.readyState !== 1) continue;
    const devId = client.__deviceId;
    if (exceptDeviceId && devId && devId === exceptDeviceId) continue;
    try {
      client.send(message);
    } catch {
      // ignore send errors
    }
  }
}

/**
 * Handle a WebSocket connection for the rooms service.
 *
 * @param {WebSocket} ws
 * @param {http.IncomingMessage} req
 * @param {RoomManager} roomManager
 * @param {string|null} msgRaw – optional initial message
 */
function handleWSConnection(ws, req, roomManager, msgRaw = null) {
  // Heartbeat γίνεται στο index.js (isAlive / ping / pong)

  /**
   * Επεξεργασία μηνύματος από τον client.
   * Υποστηρίζει:
   *  - παλιό πρωτόκολλο:  { action, user_room, device_id, ... }
   *  - νέο πρωτόκολλο:   { type, room, deviceId, ... }
   */
  function processMessage(raw) {
    const msg = safeJSONParse(raw);
    if (!msg || typeof msg !== "object") return;

    let action = msg.action || null;
    let user_room = msg.user_room || null;
    let device_id = msg.device_id || null;
    const sender_url = msg.sender_url || msg.url || null;

    // --------------------------------------------------------
    // type -> action (από το RoomsProvider)
    // --------------------------------------------------------
    if (!action && typeof msg.type === "string") {
      switch (msg.type) {
        case "join_room":
          action = "init_connection";
          break;
        case "leave_room":
          action = "leave_room";
          break;
        case "song_sync":
          action = "song_sync";
          break;
        case "ping":
          action = "ping";
          break;
        default:
          break;
      }
    }

    // room -> user_room
    if (!user_room) {
      if (typeof msg.user_room === "string") user_room = msg.user_room;
      else if (typeof msg.room === "string") user_room = msg.room;
      else if (typeof msg.roomName === "string") user_room = msg.roomName;
    }

    // deviceId -> device_id
    if (!device_id) {
      if (typeof msg.device_id === "string") device_id = msg.device_id;
      else if (typeof msg.deviceId === "string") device_id = msg.deviceId;
      else if (typeof msg.clientId === "string") device_id = msg.clientId;
    }

    // --------------------------------------------------------
    // PING – δεν χρειάζονται room / device_id
    // --------------------------------------------------------
    if (action === "ping") {
      try {
        ws.send(
          JSON.stringify({
            action: "pong",
            type: "pong",
            ts: Date.now(),
          }),
        );
      } catch {}
      return;
    }

    // Αν ΔΕΝ έχουμε action ή room, δεν κάνουμε τίποτα
    if (!action || !user_room) return;

    // Για actions που απαιτούν device_id, φτιάξε αν λείπει
    if (
      !device_id &&
      (action === "init_connection" ||
        action === "song_sync" ||
        action === "leave_room")
    ) {
      if (ws.__deviceId && typeof ws.__deviceId === "string") {
        device_id = ws.__deviceId;
      } else {
        device_id = `ws_${Math.random().toString(36).slice(2, 10)}`;
        ws.__deviceId = device_id;
      }
    }

    if (
      !device_id &&
      (action === "init_connection" ||
        action === "song_sync" ||
        action === "leave_room")
    ) {
      return;
    }

    // --------------------------------------------------------
    // INIT CONNECTION
    // --------------------------------------------------------
    if (action === "init_connection") {
      ws.__room = user_room;
      ws.__deviceId = device_id;
      ws.__userId = msg.user_id || null;
      ws.__username = msg.username || null;
      const clientLastSeenId = msg.last_seen_sync_id || null;

      // Εγγραφή client στο RoomManager
      roomManager.addClient(user_room, device_id, ws);

      // Καθάρισμα παλιών συμμετοχών του ίδιου device σε άλλα rooms
      if (typeof roomManager.clients === "object") {
        for (const [rName, roomMap] of roomManager.clients.entries()) {
          if (rName === user_room) continue;
          for (const [key, entry] of roomMap.entries()) {
            if (entry.deviceId === device_id) {
              try {
                if (entry.ws && entry.ws.readyState === 1) {
                  entry.ws.close(4000, "Moved to another room");
                }
              } catch {}
              roomMap.delete(key);
            }
          }
        }
      }

      if (msg.user_id || msg.username) {
        roomManager.setClientMeta(
          user_room,
          device_id,
          msg.user_id || null,
          msg.username || null,
        );
        console.log(
          `🟢 ${user_room}: συνδέθηκε ${
            msg.username || "anonymous"
          } (ID: ${msg.user_id || "-"})`,
        );
      } else {
        console.log(
          `⚠️ ${user_room}: σύνδεση χωρίς στοιχεία χρήστη από device ${device_id}`,
        );
      }

      // Στέλνουμε immediate update_count ΜΟΝΟ σε αυτόν τον client
      const ids = roomManager.getRoomDeviceIds(user_room);
      const users = roomManager.getRoomUsers(user_room);
      try {
        ws.send(
          JSON.stringify({
            action: "update_count",
            type: "update_count",
            user_room,
            count: ids.length,
            deviceIds: ids,
            users,
          }),
        );
      } catch {}

      // Last song_sync για νέο client (αν υπάρχει και είναι πρόσφατο)
      try {
        const last = roomManager.getLastSync(user_room);
        if (last && last.sender_url) {
          const sameDevice =
            last.device_id && last.device_id === device_id;
          const MAX_LAST_SYNC_AGE_MS = 10 * 60 * 1000; // 10 λεπτά
          const tooOld =
            typeof last.timestamp === "number" &&
            Date.now() - last.timestamp > MAX_LAST_SYNC_AGE_MS;
          const alreadySeen =
            last.sync_id &&
            clientLastSeenId &&
            clientLastSeenId === last.sync_id;

          if (!sameDevice && !tooOld && !alreadySeen) {
            const resendPayload = Object.assign({}, last, {
              manual: true,
              type: "song_sync",
            });
            ws.send(JSON.stringify(resendPayload));
            console.log(
              `[ROOM:${user_room}] Sent last song_sync to new client device=${device_id} -> ${last.sender_url}`,
            );
          } else {
            console.log(
              `[ROOM:${user_room}] Not sending last song_sync (sameDevice=${sameDevice}, tooOld=${tooOld}, alreadySeen=${alreadySeen})`,
            );
          }
        }
      } catch (err) {
        console.error(
          "Failed to send last song_sync on init_connection:",
          err,
        );
      }

      // Broadcast update_count σε ΟΛΟΥΣ τους άλλους clients του room
      setTimeout(() => {
        const idsNow = roomManager.getRoomDeviceIds(user_room);
        const usersNow = roomManager.getRoomUsers(user_room);
        broadcastToRoom(
          roomManager,
          user_room,
          {
            action: "update_count",
            type: "update_count",
            user_room,
            count: idsNow.length,
            deviceIds: idsNow,
            users: usersNow,
          },
          ws.__deviceId,
        );
      }, 500);
    }

    // --------------------------------------------------------
    // SONG SYNC
    // --------------------------------------------------------
    else if (action === "song_sync") {
      const sync_id =
        Date.now().toString(36) +
        Math.random().toString(36).slice(2, 10);

      const payload = {
        action: "song_sync",
        type: "song_sync",
        sender_user_id: ws.__userId || null,
        sender_username: ws.__username || null,
        user_room,
        device_id,
        sender_url,
        selected_tonicity: msg.selected_tonicity || null,
        sync_id,
        timestamp: Date.now(),
      };

      roomManager.setLastSync(user_room, payload);
      console.log(
        `[ROOM:${user_room}] song_sync από ${device_id} (tonicity=${payload.selected_tonicity})`,
      );

      broadcastToRoom(roomManager, user_room, payload, device_id);
    }

    // --------------------------------------------------------
    // LEAVE ROOM
    // --------------------------------------------------------
    else if (action === "leave_room") {
      const room = ws.__room;
      if (room) {
        roomManager.removeClient(room, ws);
        const deviceIds = roomManager.getRoomDeviceIds(room);
        const users = roomManager.getRoomUsers(room);
        broadcastToRoom(roomManager, room, {
          action: "update_count",
          type: "update_count",
          user_room: room,
          count: deviceIds.length,
          deviceIds,
          users,
        });
      }
      try {
        ws.close();
      } catch {}
    }
  }

  ws.on("message", processMessage);

  if (msgRaw) {
    processMessage(msgRaw);
  }

  const GRACE_MS = 8000;
  ws.on("close", (code, reason) => {
    const room = ws.__room;
    const deviceId = ws.__deviceId;
    console.log(
      `[ROOM:${room || "-"}] WS close: code=${code} ` +
        `reason=${reason?.toString?.() || ""} device=${deviceId || "-"}`,
    );

    if (!room || !deviceId) return;

    setTimeout(() => {
      roomManager.removeClient(room, ws);
      const deviceIds = roomManager.getRoomDeviceIds(room);
      const users = roomManager.getRoomUsers(room);
      broadcastToRoom(roomManager, room, {
        action: "update_count",
        type: "update_count",
        user_room: room,
        count: deviceIds.length,
        deviceIds,
        users,
      });

      console.log(
        `[ROOM:${room}] cleanup after close for device=${deviceId} ` +
          `(${deviceIds.length} ενεργοί χρήστες)`,
      );
    }, GRACE_MS);
  });

  ws.on("error", (err) => {
    console.error("WebSocket internal error:", err.message);
  });
}

module.exports = { handleWSConnection };
