
/**
 * utils.js — currently unused helpers placeholder
 * (kept for future extensions/logging)
 */
module.exports = {};
