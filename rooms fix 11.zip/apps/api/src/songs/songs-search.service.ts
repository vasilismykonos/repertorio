// apps/api/src/songs/songs-search.service.ts
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import type { Prisma } from "@prisma/client";
import { SongStatus } from "@prisma/client";

type SearchParams = {
  q?: string;
  skip?: number;
  take?: number;
  createdByUserId?: number;
};

type SearchResultItem = {
  song_id: number;
  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number;
  partiture: number;
  status: string;
  score: number;
};

type SearchResult = {
  total: number;
  items: SearchResultItem[];
};

@Injectable()
export class SongsSearchService {
  // Δεν χρησιμοποιούμε ES προσωρινά – μόνο Prisma.
  constructor(private readonly prisma: PrismaService) {}

  // Μετατροπή ενός Song (Prisma) σε SearchResultItem με score=0
  private mapSongWithoutScore(s: any): SearchResultItem {
    let chordsValue = 0;
    if (s.chords) {
      const parsed = parseInt(s.chords as any, 10);
      if (!Number.isNaN(parsed)) {
        chordsValue = parsed;
      }
    }

    return {
      song_id: s.id,
      title: s.title ?? "",
      firstLyrics: s.firstLyrics ?? "",
      lyrics: s.lyrics ?? "",
      characteristics: s.characteristics ?? "",
      originalKey: s.originalKey ?? "",
      chords: chordsValue,
      partiture: s.scoreFile ? 1 : 0,
      status: s.status ? String(s.status) : "",
      score: 0,
    };
  }

  // Αναζήτηση σε Postgres με q (μόνο PUBLISHED για global search)
  private async searchPostgresWithQuery(
    q: string,
    skip: number,
    take: number,
  ): Promise<SearchResult> {
    const where: Prisma.SongWhereInput = {
      status: SongStatus.PUBLISHED,
      OR: [
        { title: { contains: q, mode: "insensitive" } },
        { firstLyrics: { contains: q, mode: "insensitive" } },
        { lyrics: { contains: q, mode: "insensitive" } },
      ],
    };

    const [songs, total] = await Promise.all([
      this.prisma.song.findMany({
        where,
        skip,
        take,
        orderBy: { title: "asc" },
      }),
      this.prisma.song.count({ where }),
    ]);

    return {
      total,
      items: songs.map((s) => this.mapSongWithoutScore(s)),
    };
  }

  async search(params: SearchParams): Promise<SearchResult> {
    const q = (params.q || "").trim();
    const skip = params.skip ?? 0;
    const take = params.take ?? 20;
    const createdByUserId = params.createdByUserId;

    // --------------------------------------------------------------------
    // 0) Αν έχουμε createdByUserId -> πάντα Postgres (με optional q)
    //    Εδώ αφήνουμε ΟΛΑ τα status, γιατί είναι προσωπική λίστα χρήστη.
    // --------------------------------------------------------------------
    if (typeof createdByUserId === "number") {
      const where: Prisma.SongWhereInput = {
        createdByUserId,
      };

      if (q) {
        where.OR = [
          { title: { contains: q, mode: "insensitive" } },
          { firstLyrics: { contains: q, mode: "insensitive" } },
          { lyrics: { contains: q, mode: "insensitive" } },
        ];
      }

      const [songs, total] = await Promise.all([
        this.prisma.song.findMany({
          where,
          skip,
          take,
          orderBy: { id: "desc" },
        }),
        this.prisma.song.count({ where }),
      ]);

      return {
        total,
        items: songs.map((s) => this.mapSongWithoutScore(s)),
      };
    }

    // --------------------------------------------------------------------
    // 1) Χωρίς q -> επιστρέφουμε ΜΟΝΟ PUBLISHED τραγούδια από PostgreSQL
    // --------------------------------------------------------------------
    if (!q) {
      const where: Prisma.SongWhereInput = {
        status: SongStatus.PUBLISHED,
      };

      const [songs, total] = await Promise.all([
        this.prisma.song.findMany({
          where,
          skip,
          take,
          orderBy: [{ title: "asc" }],
        }),
        this.prisma.song.count({ where }),
      ]);

      return {
        total,
        items: songs.map((s) => this.mapSongWithoutScore(s)),
      };
    }

    // --------------------------------------------------------------------
    // 2) Με q (χωρίς createdByUserId) → ΜΟΝΟ Postgres (προσωρινά, χωρίς ES)
    // --------------------------------------------------------------------
    return this.searchPostgresWithQuery(q, skip, take);
  }
}
