// apps/rooms/ws-handler.js

/**
 * Ασφαλές JSON.parse
 */
function safeJSONParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

/**
 * Στέλνει JSON σε client.
 */
function send(ws, obj) {
  try {
    ws.send(JSON.stringify(obj));
  } catch (err) {
    // ignore
  }
}

/**
 * Broadcast σε όλο το room.
 */
function broadcastToRoom(roomManager, room, obj, excludeWs = null) {
  const set = roomManager.clients.get(room);
  if (!set) return;
  const payload = JSON.stringify(obj);
  for (const client of set) {
    if (excludeWs && client === excludeWs) continue;
    try {
      client.send(payload);
    } catch {
      // ignore
    }
  }
}

/**
 * Διαχείριση WebSocket connection.
 *
 * Πρωτόκολλο μηνυμάτων από browser:
 *
 *   { "type": "join_room",
 *     "room": "MyRoom",
 *     "password": "1234",
 *     "deviceId": "abc",
 *     "userId": 1,
 *     "username": "Vasilis" }
 *
 *   { "type": "leave_room" }
 *
 *   { "type": "song_sync",
 *     "room": "MyRoom",
 *     "syncId": 42,
 *     "payload": { ... } }
 */
function handleWSConnection(ws, req, roomManager) {
  ws.isAlive = true;

  ws.on("pong", () => {
    ws.isAlive = true;
  });

  // Μόλις συνδεθεί ο client
  send(ws, { type: "welcome", message: "connected" });

  ws.on("message", (raw) => {
    const msg = safeJSONParse(String(raw));
    if (!msg || typeof msg !== "object") return;

    const type = msg.type || msg.action;

    // ------------------------------------------------------
    // JOIN ROOM
    // ------------------------------------------------------
    if (type === "join_room" || type === "init_connection") {
      const room = String(msg.room || "").trim();
      const password = msg.password || "";
      const deviceId = msg.deviceId || null;
      const userId = Number.isFinite(msg.userId) ? Number(msg.userId) : null;
      const username = msg.username || null;

      if (!room) {
        send(ws, {
          type: "join_denied",
          reason: "EMPTY_ROOM_NAME",
        });
        return;
      }

      // Αν δεν υπάρχει ήδη το room, το δημιουργεί (χωρίς password).
      // Αν θέλεις strict συμπεριφορά, μπορείς να το αλλάξεις να απαιτεί ήδη υπάρχον room.
      roomManager.ensureRoom(room);

      // Έλεγχος password
      const ok = roomManager.verifyPassword(room, password);
      if (!ok) {
        send(ws, {
          type: "join_denied",
          room,
          reason: "WRONG_PASSWORD",
        });
        return;
      }

      // Attach client
      const userCount = roomManager.attachClient(room, ws, {
        deviceId,
        userId,
        username,
      });

      // Επιβεβαίωση στον ίδιο
      send(ws, {
        type: "join_accepted",
        room,
        userCount,
      });

      // Ενημέρωση όλων στο room για το νέο count
      broadcastToRoom(roomManager, room, {
        type: "update_count",
        room,
        userCount,
      });

      // Στείλε στον νέο client το τελευταίο song_sync, αν υπάρχει
      const lastSync = roomManager.getLastSync(room);
      if (lastSync) {
        send(ws, {
          type: "song_sync",
          room,
          syncId: lastSync.syncId,
          payload: lastSync.payload,
        });
      }

      return;
    }

    // ------------------------------------------------------
    // LEAVE ROOM
    // ------------------------------------------------------
    if (type === "leave_room" || type === "disconnect") {
      const { room, userCount } = roomManager.detachClient(ws);
      if (room) {
        broadcastToRoom(roomManager, room, {
          type: "update_count",
          room,
          userCount,
        });
      }
      return;
    }

    // ------------------------------------------------------
    // SONG_SYNC – broadcast
    // ------------------------------------------------------
    if (type === "song_sync") {
      const info = roomManager.getClientInfo(ws);
      const room = String(msg.room || info.room || "").trim();
      if (!room) return;

      const syncId = Number.isFinite(msg.syncId) ? Number(msg.syncId) : Date.now();
      const payload = msg.payload ?? null;

      // Αποθήκευση τελευταίας κατάστασης για το room
      roomManager.setLastSync(room, { syncId, payload });

      // Broadcast σε όλους στο room (εκτός από τον sender αν θέλεις)
      broadcastToRoom(roomManager, room, {
        type: "song_sync",
        room,
        syncId,
        payload,
      });

      return;
    }

    // ------------------------------------------------------
    // Ping/Pong λογικό επίπεδο (προαιρετικό)
    // ------------------------------------------------------
    if (type === "ping") {
      send(ws, { type: "pong" });
      return;
    }
  });

  ws.on("close", () => {
    const { room, userCount } = roomManager.detachClient(ws);
    if (room) {
      broadcastToRoom(roomManager, room, {
        type: "update_count",
        room,
        userCount,
      });
    }
  });

  ws.on("error", () => {
    const { room, userCount } = roomManager.detachClient(ws);
    if (room) {
      broadcastToRoom(roomManager, room, {
        type: "update_count",
        room,
        userCount,
      });
    }
  });
}

module.exports = {
  handleWSConnection,
};
