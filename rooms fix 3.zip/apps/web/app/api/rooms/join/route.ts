// apps/web/app/api/rooms/join/route.ts
import { NextResponse } from "next/server";

type ApiResponse = {
  success: boolean;
  message?: string;
};

function getRoomsBaseUrl(): string {
  const base =
    process.env.ROOMS_HTTP_BASE_URL ||
    process.env.NEXT_PUBLIC_ROOMS_HTTP_BASE_URL ||
    "http://localhost:4455";

  return base.replace(/\/+$/, "");
}

// POST /api/rooms/join
// Ελέγχει (μέσω Node rooms server) αν το room υπάρχει
// και αν ο κωδικός είναι σωστός, χρησιμοποιώντας
// το endpoint /verify-room-password.
export async function POST(req: Request) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const room = typeof body.room === "string" ? body.room.trim() : "";
  const password =
    typeof body.password === "string" ? body.password : "";

  if (!room) {
    return NextResponse.json(
      {
        success: false,
        message: "Απαιτείται όνομα δωματίου.",
      } satisfies ApiResponse,
      { status: 400 }
    );
  }

  try {
    const upstream = await fetch(
      `${getRoomsBaseUrl()}/verify-room-password`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, password }),
      }
    );

    let upstreamJson: any = {};
    try {
      upstreamJson = await upstream.json();
    } catch {
      upstreamJson = {};
    }

    // Αν ο rooms-server γυρίσει error (404/403 κ.λπ.)
    if (!upstream.ok || upstreamJson.success === false) {
      const status = upstream.status || 403;

      let message = upstreamJson.message as string | undefined;
      if (!message) {
        if (status === 404) {
          message = "Το room δεν βρέθηκε.";
        } else if (status === 403) {
          message = "Λάθος κωδικός δωματίου.";
        } else {
          message = `Σφάλμα rooms server (HTTP ${status}).`;
        }
      }

      return NextResponse.json(
        {
          success: false,
          message,
        } satisfies ApiResponse,
        { status }
      );
    }

    // Όλα καλά – το RoomsClient θα καλέσει callRepRoomsSwitch(...)
    return NextResponse.json(
      {
        success: true,
        message: upstreamJson.message || "Επιτυχής σύνδεση στο room.",
      } satisfies ApiResponse
    );
  } catch (err) {
    console.error("[POST /api/rooms/join] Σφάλμα:", err);
    return NextResponse.json(
      {
        success: false,
        message: "Αποτυχία επικοινωνίας με rooms server.",
      } satisfies ApiResponse,
      { status: 500 }
    );
  }
}

