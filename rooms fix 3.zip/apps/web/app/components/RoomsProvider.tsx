"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

type RoomsContextType = {
  wsConnected: boolean;
  currentRoom: string | null;
  switchRoom: (room: string | null, password?: string) => void;
  lastSyncId: number;
  ignoreSyncUntil: number;
};

const RoomsContext = createContext<RoomsContextType | undefined>(undefined);

function getWsUrl(): string | null {
  if (typeof window === "undefined") {
    return null;
  }

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const host = window.location.host; // app.repertorio.net ή dev.repertorio.net

  // Nginx proxy: /rooms-api/ws -> 127.0.0.1:4455/ws
  return `${protocol}://${host}/rooms-api/ws`;
}

export function RoomsProvider({ children }: { children: React.ReactNode }) {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [lastSyncId, setLastSyncId] = useState<number>(0);
  const [ignoreSyncUntil, setIgnoreSyncUntil] = useState<number>(0);

  // --------------------------------------------------------------------
  // Αποθήκευση room σε localStorage
  // --------------------------------------------------------------------
  const saveRoom = (room: string | null) => {
    if (typeof window === "undefined") return;

    if (room && room.trim() !== "") {
      window.localStorage.setItem("rep_current_room", room.trim());
    } else {
      window.localStorage.removeItem("rep_current_room");
    }

    const evt = new CustomEvent("rep_current_room_changed", {
      detail: { room: room || null },
    });
    window.dispatchEvent(evt);
  };

  // --------------------------------------------------------------------
  // Αποστολή join / leave στον WebSocket
  // --------------------------------------------------------------------
  const sendJoin = (room: string, password: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    wsRef.current.send(
      JSON.stringify({
        type: "join_room",
        room,
        password,
      })
    );
  };

  const sendLeave = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    wsRef.current.send(
      JSON.stringify({
        type: "leave_room",
      })
    );
  };

  // --------------------------------------------------------------------
  // Heartbeat (ping)
  // --------------------------------------------------------------------
  const stopHeartbeat = () => {
    if (heartbeatRef.current) {
      clearInterval(heartbeatRef.current);
      heartbeatRef.current = null;
    }
  };

  const startHeartbeat = () => {
    stopHeartbeat();
    if (!wsRef.current) return;

    heartbeatRef.current = setInterval(() => {
      try {
        if (
          wsRef.current &&
          wsRef.current.readyState === WebSocket.OPEN
        ) {
          wsRef.current.send(JSON.stringify({ type: "ping" }));
        }
      } catch {
        // ignore
      }
    }, 20000); // κάθε 20s
  };

  // --------------------------------------------------------------------
  // Reconnect logic
  // --------------------------------------------------------------------
  const scheduleReconnect = () => {
    if (reconnectRef.current) {
      return;
    }
    reconnectRef.current = setTimeout(() => {
      reconnectRef.current = null;
      connectWS();
    }, 3000);
  };

  // --------------------------------------------------------------------
  // Σύνδεση WebSocket
  // --------------------------------------------------------------------
  const connectWS = () => {
    if (typeof window === "undefined") return;

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
    }

    const wsUrl = getWsUrl();
    if (!wsUrl) return;

    console.log("[RoomsProvider] connecting to", wsUrl);

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("[RoomsProvider] WebSocket open");
      setWsConnected(true);
      startHeartbeat();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (!data || typeof data !== "object") return;

        const t = data.type || data.action;

        if (t === "song_sync") {
          // απλά για να έχουμε ένα "σημάδι" ότι ήρθε sync
          setLastSyncId(Date.now());
        }

        if (t === "update_count") {
          // εδώ μπορούμε αργότερα να περάσουμε live μετρητές στο UI
          // προς το παρόν απλά το log-άρουμε για debug
          console.log(
            "[RoomsProvider] update_count",
            data.user_room,
            data.count,
            data.deviceIds
          );
        }
      } catch (err) {
        console.warn("[RoomsProvider] failed to parse message", err);
      }
    };

    ws.onclose = (ev) => {
      console.log(
        "[RoomsProvider] WebSocket closed",
        ev.code,
        ev.reason
      );
      setWsConnected(false);
      stopHeartbeat();
      scheduleReconnect();
    };

    ws.onerror = (err) => {
      console.error("[RoomsProvider] WebSocket error:", err);
      try {
        ws.close();
      } catch {
        // ignore
      }
    };
  };

  // --------------------------------------------------------------------
  // MOUNT → φόρτωση room από localStorage + άνοιγμα WebSocket
  // --------------------------------------------------------------------
  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = window.localStorage.getItem("rep_current_room");
      if (stored && stored.trim() !== "") {
        setCurrentRoom(stored.trim());
      }
    }

    connectWS();

    return () => {
      stopHeartbeat();
      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {
          // ignore
        }
      }
      if (reconnectRef.current) {
        clearTimeout(reconnectRef.current);
        reconnectRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --------------------------------------------------------------------
  // Όταν αλλάξει wsConnected ή currentRoom → αν είμαστε συνδεδεμένοι, κάνε join
  // --------------------------------------------------------------------
  useEffect(() => {
    if (!wsConnected || !currentRoom) return;
    sendJoin(currentRoom, "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wsConnected, currentRoom]);

  // --------------------------------------------------------------------
  // Public API: switchRoom
  // --------------------------------------------------------------------
  const switchRoom = (room: string | null, password: string = "") => {
    if (!room || room.trim() === "") {
      // leave
      sendLeave();
      setCurrentRoom(null);
      saveRoom(null);
      return;
    }

    const clean = room.trim();
    setCurrentRoom(clean);
    saveRoom(clean);

    // αν ο WS είναι ήδη open, στέλνουμε join
    sendJoin(clean, password);
  };

  // --------------------------------------------------------------------
  // GLOBAL EXPOSE (WordPress compatibility)
  // --------------------------------------------------------------------
  useEffect(() => {
    if (typeof window === "undefined") return;

    (window as any).RepRoomsSwitchRoom = (
      room: string | null,
      pwd: string = ""
    ) => {
      switchRoom(room, pwd);
    };
  }, [switchRoom]);

  const value: RoomsContextType = {
    wsConnected,
    currentRoom,
    switchRoom,
    lastSyncId,
    ignoreSyncUntil,
  };

  return (
    <RoomsContext.Provider value={value}>
      {children}
    </RoomsContext.Provider>
  );
}

export function useRooms(): RoomsContextType {
  const ctx = useContext(RoomsContext);
  if (!ctx) {
    throw new Error("useRooms must be used within a RoomsProvider");
  }
  return ctx;
}
