"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import FiltersModal from "./FiltersModal";
import type { Option } from "./FilterSelectWithSearch";

const API_BASE_URL = "https://api.repertorio.net/api/v1";

type SongSearchItem = {
  song_id: number;
  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number | string | boolean | null;
  partiture: number | string | boolean | null;
  status: string;
  score: number;
  views: number | null;

  // πιθανές μορφές κατηγορίας
  category_id?: number | null;
  categoryId?: number | null;
  categoryTitle?: string | null;
  category?: string | null;
  category_title?: string | null;

  // πιθανές μορφές ρυθμού
  rythm_id?: number | null;
  rythmId?: number | null;
  rythmTitle?: string | null;
  rythm?: string | null;
  rhythm_id?: number | null;
  rhythmId?: number | null;
  rhythmTitle?: string | null;
};

type SongsSearchResponse = {
  total: number;
  items: SongSearchItem[];
};

type CategoryDto = {
  id: number;
  title: string;
  _count?: { songs?: number };
  songCount?: number;
  songsCount?: number;
  [key: string]: any;
};

type RythmDto = {
  id: number;
  title: string;
  _count?: { songs?: number };
  songCount?: number;
  songsCount?: number;
  [key: string]: any;
};

type SongsPageSearchParams = {
  take?: string | string[];
  skip?: string | string[];

  q?: string | string[];
  search_term?: string | string[];

  chords?: string | string[];
  partiture?: string | string[];
  category_id?: string | string[];
  rythm_id?: string | string[];
  characteristics?: string | string[];
  lyrics?: string | string[];
  status?: string | string[];
  popular?: string | string[];
  createdByUserId?: string | string[];
};

type FiltersState = {
  take: number;
  skip: number;

  q: string;

  chords: string;
  partiture: string;
  category_id: string;
  rythm_id: string;
  characteristics: string;
  lyrics: string;
  status: string;
  popular: string;
  createdByUserId: string;
};

type CountsResult = {
  chordsCounts: Record<string, number>;
  partitureCounts: Record<string, number>;
  lyricsCounts: Record<string, number>;
  statusCounts: Record<string, number>;

  characteristicsList: string[];
  characteristicsCountMap: Record<string, number>;

  categoryCountById: Record<string, number>;
  categoryCountByTitle: Record<string, number>;
  categoryIdByTitle: Record<string, number | null>;

  rythmCountById: Record<string, number>;
  rythmCountByTitle: Record<string, number>;
  rythmIdByTitle: Record<string, number | null>;
};

type Props = {
  searchParams?: SongsPageSearchParams;
};

// -------------------- helpers --------------------

function normalizeParam(p: string | string[] | undefined): string {
  if (!p) return "";
  if (Array.isArray(p)) {
    return p
      .join(",")
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean)
      .join(",");
  }
  return p;
}

function buildQueryFromFilters(filters: FiltersState): string {
  const params = new URLSearchParams();

  params.set("take", String(filters.take));
  params.set("skip", String(filters.skip));

  // Στέλνουμε ΚΑΙ q ΚΑΙ search_term, για συμβατότητα με το API
  if (filters.q) {
    params.set("q", filters.q);
    params.set("search_term", filters.q);
  }

  if (filters.chords) params.set("chords", filters.chords);
  if (filters.partiture) params.set("partiture", filters.partiture);
  if (filters.category_id) params.set("category_id", filters.category_id);
  if (filters.rythm_id) params.set("rythm_id", filters.rythm_id);
  if (filters.characteristics)
    params.set("characteristics", filters.characteristics);
  if (filters.lyrics) params.set("lyrics", filters.lyrics);
  if (filters.status) params.set("status", filters.status);
  if (filters.popular === "1") params.set("popular", "1");
  if (filters.createdByUserId)
    params.set("createdByUserId", filters.createdByUserId);

  return params.toString();
}


async function parseJsonSafe<T>(res: Response): Promise<T> {
  const ct = res.headers.get("content-type") || "";
  const text = await res.text();
  if (!ct.includes("application/json")) {
    throw new Error(
      `Expected JSON but got content-type "${ct}". Body (trimmed): ${text.slice(
        0,
        200,
      )}`,
    );
  }
  return JSON.parse(text) as T;
}

function computeCountsFromSongs(songs: SongSearchItem[]): CountsResult {
  const chordsCounts: Record<string, number> = {
    "1": 0,
    "0": 0,
    null: 0,
  } as any;
  const partitureCounts: Record<string, number> = {
    "1": 0,
    "0": 0,
    null: 0,
  } as any;
  const lyricsCounts: Record<string, number> = { null: 0 } as any;
  const statusCounts: Record<string, number> = {};

  const characteristicsSet = new Set<string>();
  const characteristicsCountMap: Record<string, number> = {};

  const categoryCountById: Record<string, number> = {};
  const categoryCountByTitle: Record<string, number> = {};
  const categoryIdByTitle: Record<string, number | null> = {};

  const rythmCountById: Record<string, number> = {};
  const rythmCountByTitle: Record<string, number> = {};
  const rythmIdByTitle: Record<string, number | null> = {};

  for (const song of songs) {
    // chords
    const chordsVal = song.chords;
    if (chordsVal === 1 || chordsVal === "1" || chordsVal === true) {
      chordsCounts["1"]++;
    } else if (
      chordsVal === 0 ||
      chordsVal === "0" ||
      chordsVal === false
    ) {
      chordsCounts["0"]++;
    } else {
      chordsCounts["null"] = (chordsCounts["null"] || 0) + 1;
    }

    // partiture
    const partVal = song.partiture;
    if (partVal === 1 || partVal === "1" || partVal === true) {
      partitureCounts["1"]++;
    } else if (partVal === 0 || partVal === "0" || partVal === false) {
      partitureCounts["0"]++;
    } else {
      partitureCounts["null"] = (partitureCounts["null"] || 0) + 1;
    }

    // lyrics
    const hasLyrics = !!(song.lyrics && song.lyrics.trim().length > 0);
    if (!hasLyrics) {
      lyricsCounts["null"] = (lyricsCounts["null"] || 0) + 1;
    }

    // status
    const st = song.status || "";
    if (st) {
      statusCounts[st] = (statusCounts[st] || 0) + 1;
    }

    // characteristics
    const rawChar = (song.characteristics || "").trim();
    if (rawChar) {
      for (const part of rawChar.split(",")) {
        const v = part.trim();
        if (!v) continue;
        characteristicsSet.add(v);
        characteristicsCountMap[v] = (characteristicsCountMap[v] || 0) + 1;
      }
    }

    // Κατηγορία
    const rawCategoryId =
      song.category_id ??
      song.categoryId ??
      (song as any).category_id ??
      (song as any).categoryId ??
      null;

    const rawCategoryTitleField =
      song.categoryTitle ??
      song.category ??
      song.category_title ??
      (song as any).categoryTitle ??
      (song as any).category ??
      (song as any).category_title ??
      "";

    let catTitleFromId: string | null = null;
    let numericCategoryId: number | null = null;

    if (rawCategoryId !== null && rawCategoryId !== undefined) {
      const cidStr = String(rawCategoryId).trim();
      if (/^\d+$/.test(cidStr)) {
        numericCategoryId = Number(cidStr);
        categoryCountById[cidStr] = (categoryCountById[cidStr] || 0) + 1;
      } else if (cidStr) {
        catTitleFromId = cidStr;
      }
    }

    const finalCategoryTitle = (
      catTitleFromId || rawCategoryTitleField || ""
    ).trim();

    if (finalCategoryTitle) {
      categoryCountByTitle[finalCategoryTitle] =
        (categoryCountByTitle[finalCategoryTitle] || 0) + 1;
      // χαρτογράφηση Title → Id αν το ξέρουμε
      if (numericCategoryId !== null) {
        categoryIdByTitle[finalCategoryTitle] = numericCategoryId;
      } else if (!(finalCategoryTitle in categoryIdByTitle)) {
        categoryIdByTitle[finalCategoryTitle] = null;
      }
    }

    // Ρυθμός
    const rawRythmId =
      song.rythm_id ??
      song.rythmId ??
      song.rhythm_id ??
      song.rhythmId ??
      (song as any).rythm_id ??
      (song as any).rythmId ??
      (song as any).rhythm_id ??
      (song as any).rhythmId ??
      null;

    const rawRythmTitleField =
      song.rythmTitle ??
      song.rythm ??
      song.rhythmTitle ??
      (song as any).rhythm ??
      (song as any).rythmTitle ??
      (song as any).rythm ??
      (song as any).rhythmTitle ??
      (song as any).rhythm ??
      "";

    let rTitleFromId: string | null = null;
    let numericRythmId: number | null = null;

    if (rawRythmId !== null && rawRythmId !== undefined) {
      const ridStr = String(rawRythmId).trim();
      if (/^\d+$/.test(ridStr)) {
        numericRythmId = Number(ridStr);
        rythmCountById[ridStr] = (rythmCountById[ridStr] || 0) + 1;
      } else if (ridStr) {
        rTitleFromId = ridStr;
      }
    }

    const finalRythmTitle = (rTitleFromId || rawRythmTitleField || "").trim();

    if (finalRythmTitle) {
      rythmCountByTitle[finalRythmTitle] =
        (rythmCountByTitle[finalRythmTitle] || 0) + 1;
      if (numericRythmId !== null) {
        rythmIdByTitle[finalRythmTitle] = numericRythmId;
      } else if (!(finalRythmTitle in rythmIdByTitle)) {
        rythmIdByTitle[finalRythmTitle] = null;
      }
    }
  }

  const characteristicsList = Array.from(characteristicsSet).sort((a, b) =>
    a.localeCompare(b, "el"),
  );

  return {
    chordsCounts,
    partitureCounts,
    lyricsCounts,
    statusCounts,
    characteristicsList,
    characteristicsCountMap,
    categoryCountById,
    categoryCountByTitle,
    categoryIdByTitle,
    rythmCountById,
    rythmCountByTitle,
    rythmIdByTitle,
  };
}

function buildLyricsPreview(song: SongSearchItem): string {
  const characteristics = song.characteristics || "";
  const isOrganiko = characteristics.includes("Οργανικό");

  if (isOrganiko) {
    return "(Οργανικό)";
  }

  const lyrics = (song.lyrics || "").trim();
  if (!lyrics) {
    return "(Χωρίς διαθέσιμους στίχους)";
  }

  const base = (song.firstLyrics || "").trim() || lyrics;
  const words = base.split(/\s+/).filter(Boolean);
  const short = words.slice(0, 5).join(" ");
  return words.length > 5 ? `${short}...` : short;
}

function buildYoutubeUrl(song: SongSearchItem): string {
  const base = "https://www.youtube.com/results";
  const q = `${song.title || ""} ${song.firstLyrics || ""}`.trim();
  const params = new URLSearchParams({
    search_query: q || song.title || "",
    app: "revanced",
  });
  return `${base}?${params.toString()}`;
}

const YOUTUBE_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/youtube.png";
const GUITAR_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/guitar.png";
const SOL_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/sol.png";

// -------------------- ΚΥΡΙΑ ΣΥΝΑΡΤΗΣΗ --------------------

export default function SongsSearchClient({ searchParams }: Props) {
  // αρχικό state από searchParams (URL)
  const [filters, setFilters] = useState<FiltersState>(() => {
    const sp = searchParams || {};
    const take = Number(normalizeParam(sp.take) || "50");
    const skip = Number(normalizeParam(sp.skip) || "0");

    const qRaw =
      normalizeParam(sp.q) || normalizeParam(sp.search_term) || "";
    const q = qRaw.toString().trim();

    return {
      take,
      skip,
      q,
      chords: normalizeParam(sp.chords),
      partiture: normalizeParam(sp.partiture),
      category_id: normalizeParam(sp.category_id),
      rythm_id: normalizeParam(sp.rythm_id),
      characteristics: normalizeParam(sp.characteristics),
      lyrics: normalizeParam(sp.lyrics),
      status: normalizeParam(sp.status),
      popular: normalizeParam(sp.popular),
      createdByUserId: normalizeParam(sp.createdByUserId),
    };
  });

  const [categories, setCategories] = useState<CategoryDto[]>([]);
  const [rythms, setRythms] = useState<RythmDto[]>([]);

  const [songs, setSongs] = useState<SongSearchItem[]>([]);
  const [total, setTotal] = useState<number>(0);

  const [categoryOptions, setCategoryOptions] = useState<Option[]>([]);
  const [rythmOptions, setRythmOptions] = useState<Option[]>([]);
  const [characteristicsOptions, setCharacteristicsOptions] = useState<
    Option[]
  >([]);

  const [chordsCounts, setChordsCounts] = useState<Record<string, number>>({
    "1": 0,
    "0": 0,
    null: 0,
  } as any);
  const [partitureCounts, setPartitureCounts] = useState<
    Record<string, number>
  >({
    "1": 0,
    "0": 0,
    null: 0,
  } as any);
  const [lyricsCounts, setLyricsCounts] = useState<Record<string, number>>({
    null: 0,
  } as any);
  const [statusCounts, setStatusCounts] = useState<Record<string, number>>({});

  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // 1. Φόρτωση κατηγοριών / ρυθμών μία φορά, από Nest API
  useEffect(() => {
    let cancelled = false;

    async function loadStaticFilters() {
      try {
        const [catsRes, rythmsRes] = await Promise.all([
          fetch(`${API_BASE_URL}/categories`),
          fetch(`${API_BASE_URL}/rythms`),
        ]);

        if (!catsRes.ok) {
          console.error(
            "[SongsSearchClient] /categories HTTP error",
            catsRes.status,
          );
        }
        if (!rythmsRes.ok) {
          console.error(
            "[SongsSearchClient] /rythms HTTP error",
            rythmsRes.status,
          );
        }

        const catsJson = catsRes.ok
          ? await parseJsonSafe<CategoryDto[]>(catsRes).catch((err) => {
              console.error(
                "[SongsSearchClient] parse /categories JSON error",
                err,
              );
              return [];
            })
          : [];

        const rythmsJson = rythmsRes.ok
          ? await parseJsonSafe<RythmDto[]>(rythmsRes).catch((err) => {
              console.error(
                "[SongsSearchClient] parse /rythms JSON error",
                err,
              );
              return [];
            })
          : [];

        if (cancelled) return;

        setCategories(Array.isArray(catsJson) ? catsJson : []);
        setRythms(Array.isArray(rythmsJson) ? rythmsJson : []);
      } catch (err) {
        console.error(
          "[SongsSearchClient] Failed to load categories/rythms",
          err,
        );
        if (cancelled) return;
        setCategories([]);
        setRythms([]);
      }
    }

    loadStaticFilters();

    return () => {
      cancelled = true;
    };
  }, []);

  // 2. Φόρτωση τραγουδιών + δυναμικά counts σε κάθε αλλαγή filters
  useEffect(() => {
    let cancelled = false;

    async function loadSongs() {
      setLoading(true);
      setError(null);

      try {
        const qs = buildQueryFromFilters(filters);

        let data: SongsSearchResponse = { total: 0, items: [] };

        // Προσπάθεια από ES (Nest API)
        try {
          const esUrl = `${API_BASE_URL}/songs-es/search?${qs}`;
          const resEs = await fetch(esUrl);
          if (!resEs.ok) {
            throw new Error(`ES search HTTP ${resEs.status}`);
          }
          data = await parseJsonSafe<SongsSearchResponse>(resEs);
        } catch (errEs) {
          console.error(
            "[SongsSearchClient] ES search failed, fallback to /songs/search",
            errEs,
          );
          const fallbackUrl = `${API_BASE_URL}/songs/search?${qs}`;
          const resFallback = await fetch(fallbackUrl);
          if (!resFallback.ok) {
            throw new Error(
              `Fallback /songs/search HTTP ${resFallback.status}`,
            );
          }
          data = await parseJsonSafe<SongsSearchResponse>(resFallback);
        }

        let items = data.items ?? [];

        // πραγματικές προβολές από Nest API
        items = await Promise.all(
          items.map(async (song) => {
            try {
              const detailUrl = `${API_BASE_URL}/songs/${song.song_id}?noIncrement=1`;
              const resDetail = await fetch(detailUrl);
              if (!resDetail.ok) return song;

              const detail = await parseJsonSafe<any>(resDetail);
              const views =
                detail && typeof detail.views === "number"
                  ? detail.views
                  : song.views ?? null;

              return { ...song, views };
            } catch (err) {
              console.error(
                "[SongsSearchClient] Failed to fetch views for song",
                {
                  songId: song.song_id,
                  err,
                },
              );
              return song;
            }
          }),
        );

        // ταξινόμηση δημοφιλών
        if (filters.popular === "1") {
          items.sort((a, b) => {
            const va =
              typeof a.views === "number" && !Number.isNaN(a.views)
                ? a.views
                : -1;
            const vb =
              typeof b.views === "number" && !Number.isNaN(b.views)
                ? b.views
                : -1;
            return vb - va;
          });
        }

        if (cancelled) return;

        setSongs(items);
        setTotal(typeof data.total === "number" ? data.total : items.length);

        // counts ΜΟΝΟ από τα filtered αποτελέσματα (skroutz-style)
        const counts = computeCountsFromSongs(items);

        setChordsCounts(counts.chordsCounts);
        setPartitureCounts(counts.partitureCounts);
        setLyricsCounts(counts.lyricsCounts);
        setStatusCounts(counts.statusCounts);

        const characteristicsOpts =
          counts.characteristicsList.length > 0
            ? counts.characteristicsList.map((c) => ({
                value: c,
                label: c,
                count: counts.characteristicsCountMap[c] ?? 0,
              }))
            : [
                {
                  value: "Οργανικό",
                  label: "Οργανικό",
                  count:
                    counts.characteristicsCountMap["Οργανικό"] ?? 0,
                },
              ];
        setCharacteristicsOptions(characteristicsOpts);

        // Αν έχουμε categories από API, χρησιμοποιούμε αυτά.
        // Αλλιώς, φτιάχνουμε options από τα counts / τίτλους τραγουδιών.
        let catOpts: Option[] = [];
        if (categories.length > 0) {
          catOpts = categories.map((c) => {
            const idKey = String(c.id);
            const fromId = counts.categoryCountById[idKey];
            const fromTitle = counts.categoryCountByTitle[c.title];
            const count =
              fromId !== undefined
                ? fromId
                : fromTitle !== undefined
                ? fromTitle
                : 0;
            return { value: idKey, label: c.title, count };
          });
        } else {
          catOpts = Object.keys(counts.categoryCountByTitle).map((title) => {
            const count = counts.categoryCountByTitle[title];
            const id = counts.categoryIdByTitle[title];
            const value = id != null ? String(id) : title;
            return { value, label: title, count };
          });
        }
        const finalCategoryOptions =
            catOpts.length > 10
                ? catOpts.filter((o) => (o.count ?? 0) > 0)
                : catOpts;

            setCategoryOptions(finalCategoryOptions);


        let rOpts: Option[] = [];
        if (rythms.length > 0) {
          rOpts = rythms.map((r) => {
            const idKey = String(r.id);
            const fromId = counts.rythmCountById[idKey];
            const fromTitle = counts.rythmCountByTitle[r.title];
            const count =
              fromId !== undefined
                ? fromId
                : fromTitle !== undefined
                ? fromTitle
                : 0;
            return { value: idKey, label: r.title, count };
          });
        } else {
          rOpts = Object.keys(counts.rythmCountByTitle).map((title) => {
            const count = counts.rythmCountByTitle[title];
            const id = counts.rythmIdByTitle[title];
            const value = id != null ? String(id) : title;
            return { value, label: title, count };
          });
        }
        const finalRythmOptions =
            rOpts.length > 10
                ? rOpts.filter((o) => (o.count ?? 0) > 0)
                : rOpts;

            setRythmOptions(finalRythmOptions);


        // ενημέρωση URL χωρίς reload
        const urlQs = buildQueryFromFilters(filters);
        const url = urlQs ? `/songs?${urlQs}` : "/songs";
        if (typeof window !== "undefined") {
          window.history.replaceState(null, "", url);
        }
      } catch (err: any) {
        console.error("[SongsSearchClient] Error while loading songs", err);
        if (cancelled) return;
        setError(
          "Προέκυψε σφάλμα κατά την φόρτωση τραγουδιών. Δες το console log για λεπτομέρειες.",
        );
        setSongs([]);
        setTotal(0);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadSongs();

    return () => {
      cancelled = true;
    };
  }, [filters, categories, rythms]);

  // helper για αλλαγές φίλτρων
  const patchFilters = (patch: Partial<FiltersState>) => {
    setFilters((prev) => ({
      ...prev,
      ...patch,
      skip: patch.skip !== undefined ? patch.skip : 0,
    }));
  };

  const handleQuickFilter = (patch: Partial<FiltersState>) => {
    patchFilters(patch);
  };

  const hasPrev = filters.skip > 0;
  const hasNext = filters.skip + filters.take < total;

  const goToPage = (newSkip: number) => {
    patchFilters({ skip: newSkip });
  };

  const maxScore = useMemo(() => {
    if (songs.length === 0) return 0;
    return songs.reduce((max, s) => {
      const val =
        typeof s.score === "number" && !Number.isNaN(s.score) ? s.score : 0;
      return val > max ? val : max;
    }, 0);
  }, [songs]);

  return (
    <section style={{ padding: "16px 24px" }}>
      <h1 style={{ fontSize: "1.6rem", marginBottom: 12 }}>
        Αναζήτηση τραγουδιών
      </h1>

      <header style={{ marginBottom: 12 }}>
        <p style={{ marginTop: 4 }}>
          Βρέθηκαν <strong>{total}</strong> τραγούδια.
        </p>
        {filters.q && (
          <p style={{ marginTop: 4 }}>
            Φράση αναζήτησης: <strong>{filters.q}</strong>
          </p>
        )}
      </header>

      {/* Γρήγορα φίλτρα + κουμπί modal */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          gap: 8,
          marginBottom: 12,
        }}
      >
        <button
          type="button"
          onClick={() =>
            handleQuickFilter({
              chords: filters.chords === "1" ? "" : "1",
            })
          }
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              filters.chords === "1" ? "2px solid #fff" : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          🎸 Με συγχορδίες
        </button>

        <button
          type="button"
          onClick={() =>
            handleQuickFilter({
              partiture: filters.partiture === "1" ? "" : "1",
            })
          }
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              filters.partiture === "1"
                ? "2px solid #fff"
                : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          🎼 Με παρτιτούρα
        </button>

        <button
          type="button"
          onClick={() =>
            handleQuickFilter({
              lyrics: filters.lyrics === "null" ? "" : "null",
            })
          }
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              filters.lyrics === "null"
                ? "2px solid #fff"
                : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          📜 Χωρίς στίχους
        </button>

        <button
          type="button"
          onClick={() =>
            handleQuickFilter({
              characteristics:
                filters.characteristics === "Οργανικό"
                  ? ""
                  : "Οργανικό",
            })
          }
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              filters.characteristics === "Οργανικό"
                ? "2px solid #fff"
                : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          🌿 Οργανικό
        </button>

        <button
          type="button"
          onClick={() =>
            handleQuickFilter({
              popular: filters.popular === "1" ? "" : "1",
            })
          }
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              filters.popular === "1"
                ? "2px solid #fff"
                : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          ⭐ Δημοφιλή
        </button>

        <div style={{ marginLeft: "auto" }}>
          <FiltersModal
            q={filters.q}
            take={filters.take}
            skip={filters.skip}
            chords={filters.chords}
            partiture={filters.partiture}
            category_id={filters.category_id}
            rythm_id={filters.rythm_id}
            characteristics={filters.characteristics}
            lyrics={filters.lyrics}
            status={filters.status}
            popular={filters.popular}
            createdByUserId={filters.createdByUserId}
            categoryOptions={categoryOptions}
            rythmOptions={rythmOptions}
            characteristicsOptions={characteristicsOptions}
            chordsCounts={chordsCounts}
            partitureCounts={partitureCounts}
            lyricsCounts={lyricsCounts}
            statusCounts={statusCounts}
            onChangeFilters={(patch) =>
              patchFilters(patch as Partial<FiltersState>)
            }
          />
        </div>
      </div>

      {loading && <p>Φόρτωση…</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Λίστα τραγουδιών */}
      {!loading && songs.length === 0 ? (
        <p>Δεν βρέθηκαν τραγούδια.</p>
      ) : (
        <div id="songs-list">
          <ul style={{ listStyleType: "none", padding: 0, margin: 0 }}>
            {songs.map((song) => {
              const youtubeUrl = buildYoutubeUrl(song);
              const lyricsPreview = buildLyricsPreview(song);

              const hasViews =
                song.views !== null &&
                song.views !== undefined &&
                !Number.isNaN(song.views);

              const rawScore =
                typeof song.score === "number" && !Number.isNaN(song.score)
                  ? song.score
                  : null;

              const displayScore =
                rawScore !== null && maxScore > 0
                  ? (rawScore / maxScore) * 100
                  : rawScore;

              const hasScore =
                displayScore !== null && typeof displayScore === "number";

              return (
                <li
                  key={song.song_id}
                  className="song-item"
                  style={{ padding: "3px 0" }}
                >
                  <div
                    className="icons-and-title"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      marginBottom: 2,
                    }}
                  >
                    <a
                      href={youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-block",
                        marginRight: 5,
                        verticalAlign: "middle",
                      }}
                      title="YouTube"
                    >
                      <img
                        src={YOUTUBE_ICON_URL}
                        alt="YouTube"
                        style={{
                          width: 25,
                          verticalAlign: "middle",
                          display: "block",
                        }}
                      />
                    </a>

                    <Link
                      className="song-title"
                      href={`/songs/${song.song_id}`}
                      style={{
                        color: "#fff",
                        fontWeight: 700,
                        textDecoration: "none",
                        whiteSpace: "nowrap",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        maxWidth: "650px",
                      }}
                    >
                      {song.chords ? (
                        <img
                          src={GUITAR_ICON_URL}
                          alt="Chords"
                          style={{
                            width: 25,
                            marginRight: 5,
                            verticalAlign: "middle",
                            display: "inline-block",
                          }}
                        />
                      ) : null}
                      {song.partiture ? (
                        <img
                          src={SOL_ICON_URL}
                          alt="Partiture"
                          style={{
                            width: 25,
                            marginRight: 5,
                            verticalAlign: "middle",
                            display: "inline-block",
                          }}
                        />
                      ) : null}
                      {song.title || "(χωρίς τίτλο)"}
                    </Link>
                  </div>

                  {hasViews && (
                    <span
                      className="song-views"
                      style={{
                        display: "inline-block",
                        marginLeft: 8,
                        fontSize: "0.8rem",
                        color: "#ccc",
                        whiteSpace: "nowrap",
                        verticalAlign: "baseline",
                      }}
                      title={`${song.views} προβολές`}
                    >
                      👁 {song.views}
                    </span>
                  )}

                  {hasScore && displayScore !== null && (
                    <span
                      className="song-score"
                      style={{
                        display: "inline-block",
                        marginLeft: 8,
                        fontSize: "0.8rem",
                        color: "#ffd700",
                        whiteSpace: "nowrap",
                        verticalAlign: "baseline",
                      }}
                      title={`Βαθμολογία: ${displayScore.toFixed(1)} / 100`}
                    >
                      ⭐ {displayScore.toFixed(1)}
                    </span>
                  )}

                  <span
                    className="song-lyrics"
                    style={{
                      display: "inline-block",
                      marginLeft: 5,
                      fontStyle: "italic",
                      color: "darkgray",
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                      overflow: "hidden",
                      maxWidth: "700px",
                      verticalAlign: "baseline",
                    }}
                    title={lyricsPreview}
                  >
                    {" "}
                    {lyricsPreview}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* Pagination */}
      <div
        style={{
          marginTop: 16,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          fontSize: "0.9rem",
        }}
      >
        <div>
          Εμφάνιση από <strong>{filters.skip + 1}</strong> έως{" "}
          <strong>{Math.min(filters.skip + filters.take, total)}</strong> από{" "}
          <strong>{total}</strong> τραγούδια.
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {hasPrev && (
            <button
              type="button"
              onClick={() => goToPage(Math.max(filters.skip - filters.take, 0))}
              style={{
                padding: "4px 10px",
                borderRadius: 4,
                border: "1px solid #555",
                backgroundColor: "#000",
                color: "#fff",
                cursor: "pointer",
              }}
            >
              ◀ Προηγούμενα
            </button>
          )}
          {hasNext && (
            <button
              type="button"
              onClick={() => goToPage(filters.skip + filters.take)}
              style={{
                padding: "4px 10px",
                borderRadius: 4,
                border: "1px solid #555",
                backgroundColor: "#000",
                color: "#fff",
                cursor: "pointer",
              }}
            >
              Επόμενα ▶
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
