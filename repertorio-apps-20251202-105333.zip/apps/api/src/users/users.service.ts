// src/users/users.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { UserRole } from "./user-role.enum";

export interface ListUsersOptions {
  search?: string;
  page: number;
  pageSize: number;
  sort: string;
  order: "asc" | "desc";
}

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async listUsers(options: ListUsersOptions) {
    const { search, page, pageSize } = options;

    // -----------------------------
    // ΦΙΛΤΡΟ (where) χωρίς Prisma.UserWhereInput
    // -----------------------------
    const where: any = search
      ? {
          OR: [
            { email: { contains: search, mode: "insensitive" } },
            { displayName: { contains: search, mode: "insensitive" } },
          ],
        }
      : {};

    // -----------------------------
    // ΤΑΞΙΝΟΜΗΣΗ (orderBy) χωρίς Prisma.UserOrderByWithRelationInput
    // -----------------------------
    const allowedSortFields: string[] = [
      "id",
      "email",
      "displayName",
      "createdAt",
      "songsCount",
      "versionsCount",
    ];

    const sortField = allowedSortFields.includes(options.sort)
      ? options.sort
      : "displayName";

    const order: "asc" | "desc" =
      options.order === "desc" ? "desc" : "asc";

    const orderBy: any =
      sortField === "songsCount" || sortField === "versionsCount"
        ? undefined
        : { [sortField]: order };

    // -----------------------------
    // Κύριο query + συνολικός αριθμός
    // -----------------------------
    const [items, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      items,
      total,
      page,
      pageSize,
      pageCount: Math.ceil(total / pageSize),
    };
  }

  async getUserById(id: number) {
    const user = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    return user;
  }

  async updateUser(
    id: number,
    body: { displayName?: string; role?: UserRole },
  ) {
    const user = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    // -----------------------------
    // Data για update χωρίς Prisma.UserUpdateInput
    // -----------------------------
    const data: any = {};

    if (typeof body.displayName === "string") {
      data.displayName = body.displayName.trim();
    }

    if (body.role) {
      data.role = body.role;
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data,
    });

    return updated;
  }
}
