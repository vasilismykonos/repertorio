import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma } from "@prisma/client";

type VersionArtistRoleString =
  | "SINGER_FRONT"
  | "SINGER_BACK"
  | "SOLOIST"
  | "MUSICIAN"
  | "COMPOSER"
  | "LYRICIST";

type ArtistSearchParams = {
  q?: string;
  skip: number;
  take: number;
  roles: VersionArtistRoleString[];
};

@Injectable()
export class ArtistsService {
  constructor(private readonly prisma: PrismaService) {}

  // =========================
  // SEARCH
  // =========================
  async search(params: ArtistSearchParams) {
    const { q, skip, take, roles } = params;

    let artistIdsByRole: number[] | null = null;

    if (roles.length > 0) {
      // Από SongVersionArtist + SongCredit
      const [versionRows, creditRows] = await Promise.all([
        this.prisma.songVersionArtist.findMany({
          where: { role: { in: roles as any } },
          select: { artistId: true },
          distinct: ["artistId"],
        }),
        this.prisma.songCredit.findMany({
          where: { role: { in: roles as any } },
          select: { artistId: true },
          distinct: ["artistId"],
        }),
      ]);

      artistIdsByRole = Array.from(
        new Set([
          ...versionRows.map((r) => r.artistId),
          ...creditRows.map((r) => r.artistId),
        ]),
      );

      if (artistIdsByRole.length === 0) {
        return { total: 0, items: [] };
      }
    }

    const where: Prisma.ArtistWhereInput = {};

    if (q) {
      where.OR = [
        { title: { contains: q, mode: "insensitive" } },
        { firstName: { contains: q, mode: "insensitive" } },
        { lastName: { contains: q, mode: "insensitive" } },
      ];
    }

    if (artistIdsByRole) {
      where.id = { in: artistIdsByRole };
    }

    const [items, total] = await Promise.all([
      this.prisma.artist.findMany({
        where,
        skip,
        take,
        orderBy: { title: "asc" },
        select: {
          id: true,
          title: true,
          firstName: true,
          lastName: true,
        },
      }),
      this.prisma.artist.count({ where }),
    ]);

    return { total, items };
  }

  // =========================
  // DETAIL
  // =========================
  async findOne(id: number) {
    const artist = await this.prisma.artist.findUnique({
      where: { id },
    });

    if (!artist) {
      throw new NotFoundException(`Artist ${id} not found`);
    }

    // Discography (εκτελέσεις)
    const discography = await this.prisma.songVersionArtist.findMany({
      where: { artistId: id },
      include: {
        version: {
          include: {
            song: true,
          },
        },
      },
      orderBy: [{ version: { year: "desc" } }],
    });

    // Composer / Lyricist μέσω SongCredit
    const credits = await this.prisma.songCredit.findMany({
      where: { artistId: id },
      include: { song: true },
      orderBy: { songId: "desc" },
    });

    return {
      id: artist.id,
      title: artist.title,
      firstName: artist.firstName,
      lastName: artist.lastName,

      discography: discography.map((r) => ({
        songId: r.version.song.id,
        songTitle: r.version.song.title,
        versionId: r.versionId,
        year: r.version.year ?? null,
        role: r.role,
      })),

      credits: credits.map((c) => ({
        songId: c.song.id,
        songTitle: c.song.title,
        role: c.role,
      })),
    };
  }

  // =========================
  // UPDATE
  // =========================
  async updateArtist(
    id: number,
    payload: {
      title?: string;
      firstName?: string | null;
      lastName?: string | null;
    },
  ) {
    const exists = await this.prisma.artist.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!exists) {
      throw new NotFoundException(`Artist ${id} not found`);
    }

    await this.prisma.artist.update({
      where: { id },
      data: payload,
    });

    return this.findOne(id);
  }
}
