// apps/api/src/main.ts
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import { Logger } from "@nestjs/common";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Όλα τα endpoints να ξεκινούν από /api/v1
  app.setGlobalPrefix("api/v1");

  // Επιτρέπουμε CORS για frontend app.repertorio.net
  app.enableCors({
    origin: [
      "https://app.repertorio.net",
      "https://repertorio.net",
      "https://www.repertorio.net",
      "http://localhost:3000",
      "http://localhost:3001",
    ],
    credentials: true,
  });

  // ΞΕΧΑΣΕ το 3000 — το Next τρέχει εκεί.
  const port = process.env.API_PORT
    ? Number(process.env.API_PORT)
    : 4000;

  await app.listen(port);
  const logger = new Logger("Bootstrap");
  logger.log(`Nest API is running at http://localhost:${port}/api/v1`);
}

bootstrap();
