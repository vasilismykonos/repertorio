// src/users/users.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma, UserRole } from "@prisma/client";

export type UserListItem = {
  id: number;
  email: string | null;
  username: string | null;
  displayName: string | null;
  role: UserRole;
  createdAt: Date;
  createdSongsCount: number;
  createdVersionsCount: number;
};

export type ListUsersOptions = {
  page?: number;
  pageSize?: number;
  search?: string;
  orderby?: "createdAt" | "displayName" | "username" | "email";
  order?: "asc" | "desc";
};

export type ListUsersResult = {
  items: UserListItem[];
  total: number;
  page: number;
  pageSize: number;
};

type PrismaUserWithCounts = {
  id: number;
  email: string | null;
  username: string | null;
  displayName: string | null;
  role: UserRole;
  createdAt: Date;
  _count: {
    createdSongs: number;
    createdVersions: number;
  };
};

type UpdateUserPayload = {
  displayName?: string | null;
  role?: UserRole;
};

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private mapToUserListItem(user: PrismaUserWithCounts): UserListItem {
    return {
      id: user.id,
      email: user.email,
      username: user.username,
      displayName: user.displayName,
      role: user.role,
      createdAt: user.createdAt,
      createdSongsCount: user._count.createdSongs,
      createdVersionsCount: user._count.createdVersions,
    };
  }

  async listUsers(options: ListUsersOptions): Promise<ListUsersResult> {
    const page = options.page && options.page > 0 ? options.page : 1;
    const pageSize =
      options.pageSize && options.pageSize > 0 && options.pageSize <= 100
        ? options.pageSize
        : 20;

    const where: Prisma.UserWhereInput = options.search
      ? {
          OR: [
            {
              displayName: {
                contains: options.search,
                mode: "insensitive",
              },
            },
            {
              username: {
                contains: options.search,
                mode: "insensitive",
              },
            },
            {
              email: {
                contains: options.search,
                mode: "insensitive",
              },
            },
          ],
        }
      : {};

    const allowedOrderFields: Array<
      "createdAt" | "displayName" | "username" | "email"
    > = ["createdAt", "displayName", "username", "email"];

    const orderByField: "createdAt" | "displayName" | "username" | "email" =
      options.orderby && allowedOrderFields.includes(options.orderby)
        ? options.orderby
        : "createdAt";

    const order: Prisma.SortOrder =
      options.order === "asc" || options.order === "desc"
        ? options.order
        : "desc";

    const [total, users] = await this.prisma.$transaction([
      this.prisma.user.count({ where }),
      this.prisma.user.findMany({
        where,
        orderBy: {
          [orderByField]: order,
        },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          email: true,
          username: true,
          displayName: true,
          role: true,
          createdAt: true,
          _count: {
            select: {
              createdSongs: true,
              createdVersions: true,
            },
          },
        },
      }),
    ]);

    const items = users.map((u) => this.mapToUserListItem(u));

    return {
      items,
      total,
      page,
      pageSize,
    };
  }

  async getUserById(id: number): Promise<UserListItem> {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        username: true,
        displayName: true,
        role: true,
        createdAt: true,
        _count: {
          select: {
            createdSongs: true,
            createdVersions: true,
          },
        },
      },
    });

    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    return this.mapToUserListItem(user);
  }

  async updateUser(
    id: number,
    payload: UpdateUserPayload,
  ): Promise<UserListItem> {
    // Αν δεν υπάρχει τίποτα προς ενημέρωση, απλά διάβασε τον χρήστη
    if (
      payload.displayName === undefined &&
      payload.role === undefined
    ) {
      return this.getUserById(id);
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data: {
        ...(payload.displayName !== undefined && {
          displayName: payload.displayName,
        }),
        ...(payload.role !== undefined && { role: payload.role }),
      },
      select: {
        id: true,
        email: true,
        username: true,
        displayName: true,
        role: true,
        createdAt: true,
        _count: {
          select: {
            createdSongs: true,
            createdVersions: true,
          },
        },
      },
    });

    return this.mapToUserListItem(updated);
  }
}
