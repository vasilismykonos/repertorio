// src/users/users.controller.ts
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
} from "@nestjs/common";
import { UsersService } from "./users.service";
import { UserRole } from "@prisma/client";

type UpdateUserBody = {
  displayName?: string;
  role?: string;
};

@Controller("users")
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  async listUsers(
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
    @Query("search") search?: string,
    @Query("orderby") orderby?: string,
    @Query("order") order?: string,
  ) {
    const page = pageStr ? Number(pageStr) : 1;
    const pageSize = pageSizeStr ? Number(pageSizeStr) : 20;

    const result = await this.usersService.listUsers({
      page: Number.isFinite(page) && page > 0 ? page : 1,
      pageSize:
        Number.isFinite(pageSize) && pageSize > 0 ? pageSize : 20,
      search: search?.trim() || undefined,
      orderby: orderby as
        | "createdAt"
        | "displayName"
        | "username"
        | "email"
        | undefined,
      order: order === "asc" || order === "desc" ? order : undefined,
    });

    return result;
  }

  @Get(":id")
  async getUser(
    @Param("id", ParseIntPipe) id: number,
  ) {
    return this.usersService.getUserById(id);
  }

  @Patch(":id")
  async updateUser(
    @Param("id", ParseIntPipe) id: number,
    @Body() body: UpdateUserBody,
  ) {
    const payload: {
      displayName?: string | null;
      role?: UserRole;
    } = {};

    if (body.displayName !== undefined) {
      const name = String(body.displayName).trim();
      payload.displayName = name.length > 0 ? name : null;
    }

    if (body.role !== undefined) {
      const allowedRoles: UserRole[] = [
        UserRole.ADMIN,
        UserRole.EDITOR,
        UserRole.USER,
      ];

      const value = String(body.role).toUpperCase() as UserRole;

      if (!allowedRoles.includes(value)) {
        throw new BadRequestException(
          `Invalid role: ${body.role}. Allowed: ${allowedRoles.join(", ")}`,
        );
      }

      payload.role = value;
    }

    return this.usersService.updateUser(id, payload);
  }
}
