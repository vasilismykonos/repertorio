// lib/currentUser.ts
import { authOptions } from "./auth";
import { getServerSession } from "next-auth";

/**
 * Τύποι ρόλων όπως τους χρησιμοποιεί το frontend.
 * Αν χρειαστεί, προσαρμόζουμε / προσθέτουμε.
 */
export type UserRole = "ADMIN" | "EDITOR" | "USER";

export type SessionUser = {
  name: string | null;
  email: string | null;
  image?: string | null;
  provider?: string | null;
};

export type BackendUser = {
  id: number;
  email: string;
  name: string | null;
  image: string | null;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
};

export type CurrentUserResponse = {
  isAuthenticated: boolean;
  sessionUser: SessionUser | null;
  backendUser: BackendUser | null;
  isAdmin: boolean;
};

/**
 * Διαβάζει το session (NextAuth) απευθείας στον server,
 * χωρίς να χτυπάει κανένα external API.
 */
export async function getServerSessionUser(): Promise<SessionUser | null> {
  const session = await getServerSession(authOptions);

  if (!session || !session.user) return null;

  return {
    name: session.user.name ?? null,
    email: session.user.email ?? null,
    image: session.user.image ?? null,
    // προαιρετικά: provider αν το έχεις περάσει στο JWT
    provider: (session as any).user?.provider ?? "google",
  };
}

/**
 * ΔΕΝ χρησιμοποιεί πλέον το Nest API (`/api/v1/current-user`).
 * Καλεί το εσωτερικό Next route `/api/current-user`, το οποίο
 * ήδη δουλεύει και μας έδωσε:
 *
 * {
 *   "isAuthenticated": true,
 *   "sessionUser": {...},
 *   "backendUser": null,
 *   "isAdmin": false
 * }
 */
export async function getCurrentUserFromApi(): Promise<CurrentUserResponse> {
  const baseUrl =
    process.env.NEXTAUTH_URL || "https://app.repertorio.net";

  const res = await fetch(`${baseUrl}/api/current-user`, {
    method: "GET",
    // πολύ σημαντικό για server components ώστε να μη γίνει cache
    cache: "no-store",
    // τα cookies θα περάσουν αυτόματα από τον Next server
  });

  if (!res.ok) {
    // Αν κάτι πάει στραβά, κάνουμε gracefull fallback,
    // δεν θέλουμε να σκάει όλο το /users.
    console.error(
      "[getCurrentUserFromApi] Failed to fetch /api/current-user:",
      res.status,
      res.statusText
    );

    return {
      isAuthenticated: false,
      sessionUser: null,
      backendUser: null,
      isAdmin: false,
    };
  }

  const data = (await res.json()) as CurrentUserResponse;

  // Για ασφάλεια: αν το backendUser λείπει, είμαστε σίγουρα όχι admin.
  return {
    isAuthenticated: data.isAuthenticated,
    sessionUser: data.sessionUser,
    backendUser: data.backendUser,
    isAdmin: !!data.isAdmin && !!data.backendUser,
  };
}

