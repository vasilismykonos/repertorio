// app/users/page.tsx
import type { Metadata } from "next";
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi } from "@/lib/currentUser";

export const metadata: Metadata = {
  title: "Χρήστες | Repertorio Next",
};

type UserListItem = {
  id: number;
  email: string | null;
  username: string | null;
  displayName: string | null;
  role: string;
  createdAt: string;
  createdSongsCount: number;
  createdVersionsCount: number;
};

type UsersIndexResponse = {
  items: UserListItem[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

// Προσαρμοσμένο στο Nest API: /api/v1/users
async function fetchUsers(): Promise<UsersIndexResponse> {
  // Το fetchJson ήδη βάζει το NEXT_PUBLIC_API_BASE_URL (https://app.repertorio.net/api/v1)
  return fetchJson<UsersIndexResponse>("/users?search=&page=1&pageSize=50");
}

function roleToGreekLabel(role: string): string {
  switch (role) {
    case "ADMIN":
      return "Διαχειριστής";
    case "EDITOR":
      return "Συντάκτης";
    case "AUTHOR":
      return "Συγγραφέας";
    case "CONTRIBUTOR":
      return "Συνεργάτης";
    case "SUBSCRIBER":
      return "Συνδρομητής";
    case "USER":
    default:
      return "Χρήστης";
  }
}

export default async function UsersPage() {
  // currentUser ως any για να μην μπλέκουμε με types που αλλάζουν
  const currentUser: any = await getCurrentUserFromApi();

  // 1) Αν ΔΕΝ είναι authenticated → ΜΟΝΟ μήνυμα + link, ΟΧΙ redirect
  if (!currentUser?.isAuthenticated) {
    return (
      <section className="users-wrapper">
        <h1 className="users-title">Χρήστες</h1>
        <p className="users-subtitle">
          Πρέπει να συνδεθείτε για να δείτε τη σελίδα χρηστών.
        </p>
        <a href="/api/auth/signin" className="users-login-link">
          Μετάβαση στη σελίδα σύνδεσης
        </a>

        <style
          dangerouslySetInnerHTML={{
            __html: `
.users-wrapper {
  padding: 24px;
}
.users-title {
  font-size: 1.6rem;
  margin-bottom: 8px;
}
.users-subtitle {
  margin-bottom: 12px;
  color: #ccc;
}
.users-login-link {
  display: inline-block;
  padding: 8px 16px;
  border-radius: 4px;
  border: 1px solid #444;
  color: #fff;
  background-color: #2563eb;
  text-decoration: none;
}
.users-login-link:hover {
  background-color: #1d4ed8;
}
          `,
          }}
        />
      </section>
    );
  }

  // 2) Αν είναι authenticated αλλά ΔΕΝ είναι admin → καθαρό μήνυμα, ΧΩΡΙΣ redirect
  if (!currentUser.isAdmin) {
    return (
      <section className="users-wrapper">
        <h1 className="users-title">Χρήστες</h1>
        <p className="users-subtitle">
          Δεν έχετε δικαίωμα πρόσβασης στη σελίδα χρηστών.
        </p>

        <style
          dangerouslySetInnerHTML={{
            __html: `
.users-wrapper {
  padding: 24px;
}
.users-title {
  font-size: 1.6rem;
  margin-bottom: 8px;
}
.users-subtitle {
  margin-bottom: 12px;
  color: #ccc;
}
          `,
          }}
        />
      </section>
    );
  }

  // 3) Είσαι authenticated ΚΑΙ admin → φέρνουμε τη λίστα χρηστών
  const data = await fetchUsers();
  const users = data.items || [];

  return (
    <section className="users-wrapper">
      <h1 className="users-title">Χρήστες</h1>
      <p className="users-subtitle">
        Σύνολο χρηστών: {data.total ?? users.length}
      </p>

      <table className="users-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Όνομα εμφάνισης</th>
            <th>Email</th>
            <th>Ρόλος</th>
            <th>Τραγούδια</th>
            <th>Εκδόσεις</th>
            <th>Δημιουργήθηκε</th>
            <th>Ενέργειες</th>
          </tr>
        </thead>
        <tbody>
          {users.length === 0 && (
            <tr>
              <td colSpan={8} style={{ textAlign: "center", color: "#aaa" }}>
                Δεν βρέθηκαν χρήστες.
              </td>
            </tr>
          )}
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.displayName || u.username || "—"}</td>
              <td>{u.email || "—"}</td>
              <td>{roleToGreekLabel(u.role)}</td>
              <td>{u.createdSongsCount}</td>
              <td>{u.createdVersionsCount}</td>
              <td>
                {u.createdAt
                  ? new Date(u.createdAt).toLocaleDateString("el-GR", {
                      year: "numeric",
                      month: "2-digit",
                      day: "2-digit",
                    })
                  : "—"}
              </td>
              <td>
                <Link href={`/users/${u.id}`} className="users-action-link">
                  Προβολή
                </Link>{" "}
                |{" "}
                <Link
                  href={`/users/${u.id}/edit`}
                  className="users-action-link"
                >
                  Επεξεργασία
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <style
        dangerouslySetInnerHTML={{
          __html: `
.users-wrapper {
  padding: 24px;
}
.users-title {
  font-size: 1.6rem;
  margin-bottom: 8px;
}
.users-subtitle {
  margin-bottom: 16px;
  color: #ccc;
}
.users-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}
.users-table th,
.users-table td {
  border: 1px solid #333;
  padding: 6px 8px;
}
.users-table th {
  background-color: #111;
  text-align: left;
}
.users-table tbody tr:nth-child(even) {
  background-color: #0b0b0b;
}
.users-table tbody tr:nth-child(odd) {
  background-color: #050505;
}
.users-action-link {
  color: #4da3ff;
  text-decoration: none;
}
.users-action-link:hover {
  text-decoration: underline;
}
          `,
        }}
      />
    </section>
  );
}
