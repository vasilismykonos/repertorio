// app/users/[id]/page.tsx
import type { Metadata } from "next";
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi } from "@/lib/currentUser";

// Ίδιος ορισμός ρόλων με το edit page
export type UserRole =
  | "ADMIN"
  | "EDITOR"
  | "AUTHOR"
  | "CONTRIBUTOR"
  | "SUBSCRIBER"
  | "USER";

type UserDetail = {
  id: number;
  email: string | null;
  username: string | null;
  displayName: string | null;
  role: UserRole;
  createdAt: string;
  createdSongsCount: number;
  createdVersionsCount: number;
};

export const metadata: Metadata = {
  title: "Προβολή χρήστη | Repertorio Next",
};

async function fetchUser(id: number): Promise<UserDetail> {
  return fetchJson<UserDetail>(`/users/${id}`);
}

type PageProps = {
  params: { id: string };
};

function roleToGreekLabel(role: UserRole): string {
  switch (role) {
    case "ADMIN":
      return "Διαχειριστής";
    case "EDITOR":
      return "Συντάκτης";
    case "AUTHOR":
      return "Συγγραφέας";
    case "CONTRIBUTOR":
      return "Συνεργάτης";
    case "SUBSCRIBER":
      return "Συνδρομητής";
    case "USER":
    default:
      return "Χρήστης";
  }
}

export default async function UserDetailPage({ params }: PageProps) {
  const id = Number(params.id);
  if (!Number.isFinite(id) || id <= 0) {
    throw new Error("Invalid user id");
  }

  const [user, currentUser] = await Promise.all([
    fetchUser(id),
    getCurrentUserFromApi(),
  ]);

  const isAdmin = currentUser.isAdmin;
  const backendUserId = currentUser.backendUser?.id ?? null;
  const isSelf = backendUserId !== null && backendUserId === user.id;
  const canEdit = isAdmin || isSelf;

  const roleLabel = roleToGreekLabel(user.role);

  return (
    <section className="user-detail-wrapper">
      <h1 className="user-detail-title">
        Χρήστης #{user.id} – {user.displayName || user.username || "Χωρίς όνομα"}
      </h1>

      <p className="user-detail-subtitle">
        Ρόλος: <strong>{roleLabel}</strong>
        {" • "}
        Δημιουργήθηκε στις{" "}
        {new Date(user.createdAt).toLocaleDateString("el-GR", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        })}
      </p>

      <div className="user-detail-grid">
        <div className="user-detail-block">
          <h2>Βασικά στοιχεία</h2>
          <p>
            <strong>Username:</strong>{" "}
            {user.username || <span style={{ color: "#888" }}>—</span>}
          </p>
          <p>
            <strong>Email:</strong>{" "}
            {user.email || <span style={{ color: "#888" }}>—</span>}
          </p>
          <p>
            <strong>Ρόλος:</strong> {roleLabel}
          </p>
        </div>

        <div className="user-detail-block">
          <h2>Συμμετοχή</h2>
          <p>
            <strong>Τραγούδια που έχει δημιουργήσει:</strong>{" "}
            {user.createdSongsCount}
          </p>
          <p>
            <strong>Εκδόσεις που έχει δημιουργήσει:</strong>{" "}
            {user.createdVersionsCount}
          </p>
        </div>
      </div>

      <div className="user-detail-actions">
        <Link href="/users" className="user-detail-back">
          ← Πίσω στη λίστα χρηστών
        </Link>

        {canEdit && (
          <Link href={`/users/${user.id}/edit`} className="user-detail-edit">
            Επεξεργασία χρήστη
          </Link>
        )}
      </div>

      <style
        dangerouslySetInnerHTML={{
          __html: `
.user-detail-wrapper {
  padding: 24px;
}

.user-detail-title {
  font-size: 1.6rem;
  margin-bottom: 8px;
}

.user-detail-subtitle {
  margin-bottom: 20px;
  color: #ccc;
}

.user-detail-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

@media (min-width: 768px) {
  .user-detail-grid {
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  }
}

.user-detail-block {
  border: 1px solid #333;
  border-radius: 8px;
  padding: 16px;
  background-color: #111;
}

.user-detail-block h2 {
  margin-top: 0;
  margin-bottom: 12px;
  font-size: 1.1rem;
}

.user-detail-block p {
  margin: 4px 0;
}

.user-detail-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.user-detail-back,
.user-detail-edit {
  text-decoration: none;
  padding: 8px 16px;
  border-radius: 4px;
  border: 1px solid #444;
}

.user-detail-back {
  color: #4da3ff;
  background-color: transparent;
}

.user-detail-back:hover {
  text-decoration: underline;
}

.user-detail-edit {
  color: #fff;
  background-color: #2563eb;
  border-color: #2563eb;
}

.user-detail-edit:hover {
  background-color: #1d4ed8;
}
          `,
        }}
      />
    </section>
  );
}
