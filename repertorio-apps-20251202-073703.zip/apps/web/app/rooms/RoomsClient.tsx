"use client";

import { useCallback, useEffect, useState } from "react";
import { useRoomsWS } from "../components/RoomsProvider";

type Room = {
  room: string;
  userCount: number;
  hasPassword: boolean;
};

type RoomsClientProps = {
  initialRooms: Room[];
  isLoggedIn: boolean;
  isAdmin: boolean;
  initialCurrentRoom: string | null;
};

type ApiResponse = {
  success: boolean;
  message?: string;
};

export default function RoomsClient({
  initialRooms,
  isLoggedIn,
  isAdmin,
  initialCurrentRoom,
}: RoomsClientProps) {
  // ================================================
  //   ΣΩΣΤΟ: Hooks ΜΕΣΑ σε component function
  // ================================================
  const { switchRoom } = useRoomsWS();

  const [rooms, setRooms] = useState<Room[]>(initialRooms || []);
  const [currentRoom, setCurrentRoomState] = useState<string | null>(
    initialCurrentRoom
  );

  const [createName, setCreateName] = useState("");
  const [createPassword, setCreatePassword] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [statusColor, setStatusColor] = useState<string>("#ccc");

  // =================================================
  // Helper: update currentRoom + localStorage + event
  // =================================================
  const updateCurrentRoom = useCallback((room: string | null) => {
    setCurrentRoomState(room);

    if (typeof window === "undefined") return;

    try {
      if (room && room.trim() !== "") {
        window.localStorage.setItem("rep_current_room", room.trim());
      } else {
        window.localStorage.removeItem("rep_current_room");
      }

      window.dispatchEvent(
        new CustomEvent("rep_current_room_changed", {
          detail: { room: room || null },
        })
      );
    } catch {}
  }, []);

  // Load initial room
  useEffect(() => {
    if (typeof window === "undefined") {
      if (initialCurrentRoom) {
        setCurrentRoomState(initialCurrentRoom);
      }
      return;
    }

    const fromProps = initialCurrentRoom?.trim() || null;
    const fromStorageRaw = window.localStorage.getItem("rep_current_room");
    const fromStorage =
      fromStorageRaw && fromStorageRaw.trim() !== ""
        ? fromStorageRaw.trim()
        : null;

    const effective = fromProps || fromStorage || null;
    if (effective) {
      updateCurrentRoom(effective);
    }
  }, [initialCurrentRoom, updateCurrentRoom]);

  // =================================================
  // Fetch rooms
  // =================================================
  const refreshRooms = useCallback(async () => {
    try {
      const res = await fetch("/api/rooms", { cache: "no-store" });
      if (!res.ok) return;

      const data = (await res.json()) as Room[];
      if (Array.isArray(data)) {
        setRooms(data);
      } else {
        setRooms([]);
      }
    } catch (err) {
      console.error("refreshRooms error:", err);
    }
  }, []);

  useEffect(() => {
    refreshRooms();
    const id = setInterval(refreshRooms, 10000);
    return () => clearInterval(id);
  }, [refreshRooms]);

  // =================================================
  // Status helper
  // =================================================
  const showStatus = (msg: string, color: string = "#ccc") => {
    setStatusMessage(msg);
    setStatusColor(color);
  };

  // =================================================
  // Create room
  // =================================================
  const handleCreateRoom = async () => {
    if (!isLoggedIn) {
      alert("Πρέπει να έχεις κάνει login για να δημιουργήσεις room.");
      return;
    }

    const room = createName.trim();
    const password = createPassword.trim();

    if (!room) {
      showStatus("⚠️ Γράψε όνομα για το νέο room.", "#f1c40f");
      return;
    }
    if (/\s/.test(room)) {
      showStatus("⚠️ Το όνομα room δεν πρέπει να έχει κενά.", "#f1c40f");
      return;
    }

    setLoading(true);
    showStatus("⏳ Δημιουργία room...");

    try {
      const res = await fetch("/api/rooms/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, password }),
      });

      const json = (await res.json()) as ApiResponse;

      if (!res.ok || !json.success) {
        showStatus(
          "❌ Δεν ήταν δυνατή η δημιουργία room: " +
            (json.message || "Άγνωστο σφάλμα."),
          "#e57373"
        );
        return;
      }

      updateCurrentRoom(room);
      switchRoom(room, password);

      setCreateName("");
      setCreatePassword("");

      showStatus("✅ Το room δημιουργήθηκε.", "#81c784");
      refreshRooms();
    } catch (err: any) {
      showStatus("❌ Σφάλμα επικοινωνίας.", "#e57373");
    } finally {
      setLoading(false);
    }
  };

  // =================================================
  // Connect room
  // =================================================
  const handleConnectRoom = async (room: string, hasPassword: boolean) => {
    if (!isLoggedIn) {
      alert("Πρέπει να έχεις κάνει login.");
      return;
    }

    let password = "";
    if (hasPassword) {
      password =
        window.prompt(`Το room "${room}" είναι κλειδωμένο.\nΔώσε κωδικό:`) ||
        "";
    }

    setLoading(true);
    showStatus("⏳ Σύνδεση στο room...");

    updateCurrentRoom(room);
    switchRoom(room, password);

    showStatus("✅ Συνδέθηκες στο room.", "#81c784");
    refreshRooms();
    setLoading(false);
  };

  // =================================================
  // Disconnect
  // =================================================
  const handleDisconnect = async () => {
    if (!currentRoom) return;

    setLoading(true);
    showStatus("⏳ Αποσύνδεση...");

    updateCurrentRoom(null);
    switchRoom(null, "");

    showStatus("✅ Αποσυνδέθηκες.", "#81c784");
    refreshRooms();
    setLoading(false);
  };

  // =================================================
  // Filter
  // =================================================
  const filteredRooms = rooms.filter((r) =>
    r.room.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // =================================================
  // UI
  // =================================================
  return (
    <div style={{ color: "#fff" }}>
      <h1>Rooms</h1>

      {/* CREATE */}
      <section style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 18 }}>Δημιουργία νέου room</h2>

        <input
          type="text"
          placeholder="Όνομα"
          value={createName}
          onChange={(e) => setCreateName(e.target.value)}
        />
        <input
          type="password"
          placeholder="Κωδικός (προαιρετικό)"
          value={createPassword}
          onChange={(e) => setCreatePassword(e.target.value)}
        />
        <button onClick={handleCreateRoom} disabled={loading}>
          + Room
        </button>

        {statusMessage && (
          <div style={{ color: statusColor, marginTop: 8 }}>
            {statusMessage}
          </div>
        )}
      </section>

      {/* CURRENT ROOM */}
      <section style={{ marginBottom: 16 }}>
        {currentRoom ? (
          <div>
            Τρέχον room: <b>{currentRoom}</b>
            <button
              onClick={handleDisconnect}
              disabled={loading}
              style={{ marginLeft: 8 }}
            >
              Αποσύνδεση
            </button>
          </div>
        ) : (
          <div>Δεν είσαι συνδεδεμένος.</div>
        )}

        <input
          type="text"
          placeholder="Αναζήτηση..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ marginTop: 8 }}
        />
      </section>

      {/* ROOM LIST */}
      <section>
        {filteredRooms.length === 0 ? (
          <div>Δεν υπάρχουν διαθέσιμα rooms.</div>
        ) : (
          filteredRooms.map((room) => (
            <div
              key={room.room}
              style={{
                background: "#111",
                padding: 8,
                marginBottom: 6,
                borderRadius: 6,
              }}
            >
              <div>
                <b>{room.room}</b>{" "}
                {room.hasPassword && <span style={{ fontSize: 12 }}>🔒</span>}
              </div>
              <div style={{ fontSize: 12 }}>Χρήστες: {room.userCount}</div>
              <button
                onClick={() => handleConnectRoom(room.room, room.hasPassword)}
                disabled={loading}
                style={{
                  marginTop: 6,
                  background: currentRoom === room.room ? "#2e7d32" : "#333",
                  color: "#fff",
                }}
              >
                {currentRoom === room.room ? "Συνδεδεμένο" : "Σύνδεση"}
              </button>
            </div>
          ))
        )}
      </section>
    </div>
  );
}
