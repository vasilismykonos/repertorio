"use client";

import { ReactNode } from "react";
import { SessionProvider } from "next-auth/react";
import { PwaProvider } from "./PwaProvider";
import { RoomsProvider } from "./components/RoomsProvider";

type Props = {
  children: ReactNode;
};

export function Providers({ children }: Props) {
  return (
    <SessionProvider>
      {/* PWA side-effects (service worker κ.λπ.) */}
      <PwaProvider />
      {/* Rooms WebSocket context για όλο το app */}
      <RoomsProvider>{children}</RoomsProvider>
    </SessionProvider>
  );
}

