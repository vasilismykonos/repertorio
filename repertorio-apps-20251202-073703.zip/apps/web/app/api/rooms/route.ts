// apps/web/app/api/rooms/route.ts

export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";

/**
 * Frontend → /api/rooms → εδώ → ROOMS_HTTP_BASE_URL/get-rooms
 */
export async function GET() {
  const base =
    process.env.ROOMS_HTTP_BASE_URL || "http://127.0.0.1:4455";

  try {
    const res = await fetch(`${base}/get-rooms`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
    });

    if (!res.ok) {
      console.error("[GET /api/rooms] rooms-server HTTP", res.status);
      // Δεν θέλουμε 500 στο frontend – γυρνάμε απλά [] για ασφάλεια
      return NextResponse.json([], { status: 200 });
    }

    const json = await res.json();
    return NextResponse.json(json, { status: 200 });
  } catch (err) {
    console.error("[GET /api/rooms] Error:", err);
    return NextResponse.json([], { status: 200 });
  }
}
