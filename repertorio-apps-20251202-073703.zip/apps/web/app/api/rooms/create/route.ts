// apps/web/app/api/rooms/create/route.ts
import { NextRequest, NextResponse } from "next/server";

type ApiResponse = {
  success: boolean;
  message?: string;
};

function getRoomsBaseUrl(): string {
  const base =
    process.env.ROOMS_HTTP_BASE_URL ||
    process.env.NEXT_PUBLIC_ROOMS_HTTP_BASE_URL ||
    "http://localhost:4455";

  return base.replace(/\/+$/, "");
}

/**
 * Δημιουργεί ένα νέο room στον Node rooms-server
 * (POST /create-room στη θύρα 4455).
 */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      room?: unknown;
      password?: unknown;
    };

    const room =
      typeof body.room === "string" ? body.room.trim() : String(body.room || "");
    const password =
      typeof body.password === "string"
        ? body.password
        : String(body.password || "");

    if (!room) {
      return NextResponse.json(
        {
          success: false,
          message: "Απαιτείται όνομα room χωρίς κενά.",
        } satisfies ApiResponse,
        { status: 400 }
      );
    }

    if (/\s/.test(room)) {
      return NextResponse.json(
        {
          success: false,
          message: "Το όνομα room δεν πρέπει να περιέχει κενά.",
        } satisfies ApiResponse,
        { status: 400 }
      );
    }

    const baseUrl = getRoomsBaseUrl();

    const upstream = await fetch(`${baseUrl}/create-room`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room, password }),
    });

    let upstreamJson: any = null;
    try {
      upstreamJson = await upstream.json();
    } catch {
      // Μπορεί να μην υπάρχει body – το αγνοούμε.
    }

    if (!upstream.ok) {
      const msgFromServer =
        upstreamJson && typeof upstreamJson.message === "string"
          ? upstreamJson.message
          : null;

      const message =
        msgFromServer ||
        `Αποτυχία δημιουργίας room (HTTP ${upstream.status}).`;

      return NextResponse.json(
        {
          success: false,
          message,
        } satisfies ApiResponse,
        { status: upstream.status === 400 ? 400 : 500 }
      );
    }

    return NextResponse.json(
      {
        success: true,
        message:
          (upstreamJson && upstreamJson.message) ||
          "Το room δημιουργήθηκε.",
      } satisfies ApiResponse
    );
  } catch (err) {
    console.error("[POST /api/rooms/create] Σφάλμα:", err);
    return NextResponse.json(
      {
        success: false,
        message: "Αποτυχία επικοινωνίας με rooms server.",
      } satisfies ApiResponse,
      { status: 500 }
    );
  }
}
