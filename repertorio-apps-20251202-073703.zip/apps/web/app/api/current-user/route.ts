import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

/**
 * Αναγκαστικά dynamic route – για να επιτρέπονται headers / session κ.λπ.
 */
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    // Αν δεν υπάρχει session, απλά γυρνάμε "όχι συνδεδεμένος"
    if (!session || !session.user || !session.user.email) {
      return NextResponse.json(
        {
          isAuthenticated: false,
          sessionUser: null,
          backendUser: null,
          isAdmin: false,
        },
        { status: 200 }
      );
    }

    const email = session.user.email;

    // ------------------------------
    // Βάση API – πατάει στο .env
    // ------------------------------
    const apiBaseRaw =
      process.env.NEXT_PUBLIC_API_BASE_URL ||
      process.env.API_BASE_URL ||
      "https://api.repertorio.net";

    // Καθαρίζουμε τυχόν trailing slash
    const apiBase = apiBaseRaw.replace(/\/+$/, "");

    // Αν το apiBase ΤΕΛΕΙΩΝΕΙ ήδη σε /api/v1,
    // τότε ο endpoint path είναι μόνο /users
    // αλλιώς είναι /api/v1/users
    const usersPath = apiBase.endsWith("/api/v1")
      ? "/users"
      : "/api/v1/users";

    const url =
      apiBase +
      usersPath +
      `?search=${encodeURIComponent(email)}&page=1&pageSize=1`;

    let backendUser: any = null;
    let isAdmin = false;

    // Προσπαθούμε να φέρουμε τον χρήστη από το Nest API,
    // αλλά αν κάτι πάει στραβά, ΔΕΝ ρίχνουμε 500.
    try {
      const res = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "x-internal-from": "next-current-user",
        },
        cache: "no-store",
      });

      if (res.ok) {
        const data = await res.json();

        // Προσαρμοζόμαστε είτε σε { items: [...] } είτε σε απλό []
        const first =
          Array.isArray((data as any).items) && (data as any).items.length > 0
            ? (data as any).items[0]
            : Array.isArray(data) && data.length > 0
            ? data[0]
            : null;

        if (first) {
          backendUser = first;
          // Admin flag από role ή isAdmin
          const role = (first as any).role;
          isAdmin =
            role === "ADMIN" ||
            role === "SUPER_ADMIN" ||
            (first as any).isAdmin === true;
        }
      } else {
        const text = await res.text().catch(() => "");
        console.error(
          "[/api/current-user] backend users request failed",
          res.status,
          text
        );
      }
    } catch (err) {
      console.error("[/api/current-user] backend users request error", err);
    }

    // ΠΑΝΤΑ 200 αν υπάρχει session
    return NextResponse.json(
      {
        isAuthenticated: true,
        sessionUser: session.user,
        backendUser,
        isAdmin,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("[/api/current-user] fatal error", err);
    return NextResponse.json(
      { error: "Internal error /api/current-user" },
      { status: 500 }
    );
  }
}

