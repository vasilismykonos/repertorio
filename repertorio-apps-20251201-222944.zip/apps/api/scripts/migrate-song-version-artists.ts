// scripts/migrate-song-version-artists.ts
// Γέμισμα του πίνακα SongVersionArtist από την παλιά MySQL
// χρησιμοποιώντας τα songs, songs_versions και artists.
//
// ΔΕΝ πειράζει Song / SongVersion.
// Χρησιμοποιεί mapping:
//   - Song.legacySongId  <->  songs.Song_ID
//   - SongVersion (songId, year, youtubeSearch) <-> songs_versions
//
// Ρόλοι που γεμίζουμε (VersionArtistRole):
//   - COMPOSER      (από songs.Composer -> artists.Title)
//   - SINGER_FRONT  (από songs_versions.Singer_Front -> artists.Title)
//   - SINGER_BACK   (από songs_versions.Singer_Back -> artists.Title)
//   - SOLOIST       (από songs_versions.Solist -> artists.Title)

import "dotenv/config";
import { PrismaClient, VersionArtistRole } from "@prisma/client";
import mysql from "mysql2/promise";

const prisma = new PrismaClient();

type VersionKey = string;

function makeVersionKey(
  songId: number,
  year: number | null,
  youtubeSearch: string | null,
): VersionKey {
  return `${songId}::${year ?? "null"}::${youtubeSearch ?? ""}`;
}

function parseIdList(raw: any): number[] {
  if (raw === null || raw === undefined) return [];
  const s = String(raw).trim();
  if (!s) return [];
  return s
    .split(",")
    .map((part) => part.trim())
    .filter((part) => part.length > 0)
    .map((part) => {
      const n = Number(part);
      return Number.isFinite(n) ? n : NaN;
    })
    .filter((n) => !Number.isNaN(n));
}

async function main() {
  console.log("[*] Έναρξη migrate-song-version-artists.ts");

  const {
    OLD_DB_HOST,
    OLD_DB_PORT,
    OLD_DB_USER,
    OLD_DB_PASSWORD,
    OLD_DB_NAME,
  } = process.env;

  if (!OLD_DB_HOST || !OLD_DB_USER || !OLD_DB_NAME) {
    throw new Error(
      "Λείπουν κάποια από τα OLD_DB_* στο .env (OLD_DB_HOST, OLD_DB_USER, OLD_DB_NAME)",
    );
  }

  // 1) Σύνδεση στην παλιά MySQL
  console.log("[*] Σύνδεση στην παλιά MySQL...");
  const connection = await mysql.createConnection({
    host: OLD_DB_HOST,
    port: Number(OLD_DB_PORT || 3306),
    user: OLD_DB_USER,
    password: OLD_DB_PASSWORD,
    database: OLD_DB_NAME,
    charset: "utf8mb4_general_ci",
  });

  // 2) Φόρτωση artists από MySQL: Artist_ID -> Title
  console.log("[*] Φόρτωση artists από MySQL (Artist_ID -> Title)...");
  const [artistRows] = await connection.query<any[]>(
    `
    SELECT Artist_ID, Title
    FROM artists
  `,
  );

  const mysqlArtistIdToTitle = new Map<number, string>();
  for (const row of artistRows) {
    const id = Number(row.Artist_ID);
    if (!Number.isFinite(id)) continue;
    const rawTitle = row.Title ? String(row.Title).trim() : "";
    if (!rawTitle) continue;
    mysqlArtistIdToTitle.set(id, rawTitle);
  }
  console.log(
    `[*] Χαρτογραφήθηκαν ${mysqlArtistIdToTitle.size} MySQL artists (Artist_ID -> Title).`,
  );

  // 3) Φόρτωση composer/lyricist IDs από songs
  console.log("[*] Φόρτωση composer/lyricist από songs...");
  const [songRows] = await connection.query<any[]>(
    `
    SELECT
      s.Song_ID,
      s.Composer   AS ComposerId,
      s.Lyricist   AS LyricistId
    FROM songs s
  `,
  );

  const songIdToComposerTitle = new Map<number, string>();
  const songIdToLyricistTitle = new Map<number, string>();

  for (const row of songRows) {
    const songIdOld = Number(row.Song_ID);
    if (!Number.isFinite(songIdOld)) continue;

    const composerId =
      row.ComposerId !== null && row.ComposerId !== undefined
        ? Number(row.ComposerId)
        : null;
    const lyricistId =
      row.LyricistId !== null && row.LyricistId !== undefined
        ? Number(row.LyricistId)
        : null;

    if (composerId && mysqlArtistIdToTitle.has(composerId)) {
      songIdToComposerTitle.set(songIdOld, mysqlArtistIdToTitle.get(composerId)!);
    }

    if (lyricistId && mysqlArtistIdToTitle.has(lyricistId)) {
      songIdToLyricistTitle.set(songIdOld, mysqlArtistIdToTitle.get(lyricistId)!);
    }
  }

  console.log(
    `[*] Χαρτογραφήθηκαν composer titles για ${songIdToComposerTitle.size} τραγούδια.`,
  );
  console.log(
    `[*] Χαρτογραφήθηκαν lyricist titles για ${songIdToLyricistTitle.size} τραγούδια (δεν θα μπουν ακόμα σε VersionArtistRole γιατί δεν υπάρχει LYRICIST enum).`,
  );

  // 4) Φόρτωση όλων των songs_versions από MySQL
  console.log("[*] Φόρτωση songs_versions από MySQL...");
  const [versionRows] = await connection.query<any[]>(
    `
    SELECT
      v.Version_ID,
      v.Song_ID,
      v.Year,
      v.Singer_Front,
      v.Singer_Back,
      v.Solist,
      v.Youtube_Search
    FROM songs_versions v
    ORDER BY v.Song_ID ASC, v.Version_ID ASC
  `,
  );

  console.log(
    `[*] Βρέθηκαν ${versionRows.length} rows σε songs_versions στην παλιά βάση.`,
  );

  // 5) Φόρτωση Songs & SongVersions από PostgreSQL
  console.log("[*] Φόρτωση Song (id, legacySongId) από PostgreSQL...");
  const songs = await prisma.song.findMany({
    select: { id: true, legacySongId: true },
  });

  const legacySongIdToSongId = new Map<number, number>();
  for (const s of songs) {
    if (s.legacySongId !== null && s.legacySongId !== undefined) {
      legacySongIdToSongId.set(s.legacySongId, s.id);
    }
  }
  console.log(
    `[*] Χαρτογραφήθηκαν ${legacySongIdToSongId.size} Song.legacySongId -> Song.id.`,
  );

  console.log("[*] Φόρτωση SongVersion από PostgreSQL...");
  const versions = await prisma.songVersion.findMany({
    select: { id: true, songId: true, year: true, youtubeSearch: true },
  });

  const versionKeyToId = new Map<VersionKey, number>();
  for (const v of versions) {
    const key = makeVersionKey(v.songId, v.year, v.youtubeSearch);
    if (!versionKeyToId.has(key)) {
      versionKeyToId.set(key, v.id);
    } else {
      // Αν βρούμε διπλό key, το κρατάμε ως warning, αλλά δεν σταματάμε.
      console.warn(
        `[WARN] Διπλό SongVersion key για songId=${v.songId}, year=${v.year}, youtubeSearch=${v.youtubeSearch}`,
      );
    }
  }
  console.log(
    `[*] Δημιουργήθηκε map για ${versionKeyToId.size} SongVersion records.`,
  );

  // 6) Φόρτωση καλλιτεχνών από PostgreSQL (Artist.title -> id)
  console.log("[*] Φόρτωση Artist από PostgreSQL...");
  const prismaArtists = await prisma.artist.findMany({
    select: { id: true, title: true },
  });

  const artistTitleToId = new Map<string, number>();
  for (const a of prismaArtists) {
    if (!a.title) continue;
    const t = a.title.trim();
    if (!t) continue;
    if (!artistTitleToId.has(t)) {
      artistTitleToId.set(t, a.id);
    }
  }
  console.log(
    `[*] Χαρτογραφήθηκαν ${artistTitleToId.size} Artist.title -> Artist.id στο PostgreSQL.`,
  );

  // 7) Δημιουργία entries για SongVersionArtist
  const entries: {
    versionId: number;
    artistId: number;
    role: VersionArtistRole;
    order: number;
  }[] = [];

  let processed = 0;
  let skippedNoSong = 0;
  let skippedNoVersion = 0;

  console.log("[*] Ξεκινάμε επεξεργασία rows από songs_versions...");

  for (const row of versionRows) {
    const versionIdOld = Number(row.Version_ID);
    const songIdOld = Number(row.Song_ID);

    if (!Number.isFinite(songIdOld)) {
      skippedNoSong++;
      continue;
    }

    const songIdNew = legacySongIdToSongId.get(songIdOld);
    if (!songIdNew) {
      console.warn(
        `[WARN] Δεν βρέθηκε Song (Postgres) για Song_ID=${songIdOld} (Version_ID=${versionIdOld})`,
      );
      skippedNoSong++;
      continue;
    }

    let year: number | null = null;
    if (row.Year !== null && row.Year !== undefined) {
      const yearNum = Number(row.Year);
      if (Number.isFinite(yearNum)) {
        year = yearNum;
      }
    }

    const youtubeSearch = row.Youtube_Search
      ? String(row.Youtube_Search).trim()
      : null;

    const versionKey = makeVersionKey(songIdNew, year, youtubeSearch);
    const versionIdNew = versionKeyToId.get(versionKey);

    if (!versionIdNew) {
      console.warn(
        `[WARN] Δεν βρέθηκε SongVersion (Postgres) για Song_ID=${songIdOld}, Version_ID=${versionIdOld}, year=${year}, youtubeSearch=${youtubeSearch}`,
      );
      skippedNoVersion++;
      continue;
    }

    // 7.1 COMPOSER (ίδιος για όλα τα versions του song)
    const composerTitle = songIdToComposerTitle.get(songIdOld);
    if (composerTitle) {
      const artistId = artistTitleToId.get(composerTitle);
      if (artistId) {
        entries.push({
          versionId: versionIdNew,
          artistId,
          role: VersionArtistRole.COMPOSER,
          order: 0,
        });
      } else {
        console.warn(
          `[WARN] Δεν βρέθηκε Artist (Postgres) για composerTitle="${composerTitle}" (Song_ID=${songIdOld})`,
        );
      }
    }

    // 7.2 SINGER_FRONT
    const frontIds = parseIdList(row.Singer_Front);
    frontIds.forEach((aid, index) => {
      const t = mysqlArtistIdToTitle.get(aid);
      if (!t) return;
      const artistId = artistTitleToId.get(t);
      if (!artistId) {
        console.warn(
          `[WARN] Δεν βρέθηκε Artist (Postgres) για SINGER_FRONT title="${t}" (Song_ID=${songIdOld}, Version_ID=${versionIdOld})`,
        );
        return;
      }
      entries.push({
        versionId: versionIdNew,
        artistId,
        role: VersionArtistRole.SINGER_FRONT,
        order: index,
      });
    });

    // 7.3 SINGER_BACK
    const backIds = parseIdList(row.Singer_Back);
    backIds.forEach((aid, index) => {
      const t = mysqlArtistIdToTitle.get(aid);
      if (!t) return;
      const artistId = artistTitleToId.get(t);
      if (!artistId) {
        console.warn(
          `[WARN] Δεν βρέθηκε Artist (Postgres) για SINGER_BACK title="${t}" (Song_ID=${songIdOld}, Version_ID=${versionIdOld})`,
        );
        return;
      }
      entries.push({
        versionId: versionIdNew,
        artistId,
        role: VersionArtistRole.SINGER_BACK,
        order: index,
      });
    });

    // 7.4 SOLOIST
    const soloIds = parseIdList(row.Solist);
    soloIds.forEach((aid, index) => {
      const t = mysqlArtistIdToTitle.get(aid);
      if (!t) return;
      const artistId = artistTitleToId.get(t);
      if (!artistId) {
        console.warn(
          `[WARN] Δεν βρέθηκε Artist (Postgres) για SOLOIST title="${t}" (Song_ID=${songIdOld}, Version_ID=${versionIdOld})`,
        );
        return;
      }
      entries.push({
        versionId: versionIdNew,
        artistId,
        role: VersionArtistRole.SOLOIST,
        order: index,
      });
    });

    processed++;
    if (processed % 200 === 0) {
      console.log(
        `[*] Επεξεργασμένα versions: ${processed} / ${versionRows.length} (τρέχον entries=${entries.length})`,
      );
    }
  }

  console.log(
    `[*] Τέλος επεξεργασίας MySQL rows. processed=${processed}, skippedNoSong=${skippedNoSong}, skippedNoVersion=${skippedNoVersion}`,
  );
  console.log(`[*] Συνολικά entries για SongVersionArtist: ${entries.length}`);

  // 8) Εισαγωγή στο PostgreSQL με createMany + skipDuplicates
  if (entries.length > 0) {
    console.log("[*] Εισαγωγή SongVersionArtist σε batches...");
    const batchSize = 1000;
    for (let i = 0; i < entries.length; i += batchSize) {
      const batch = entries.slice(i, i + batchSize);
      await prisma.songVersionArtist.createMany({
        data: batch,
        skipDuplicates: true,
      });
      console.log(
        `[*] Εισήχθη batch ${i}–${i + batch.length} / ${entries.length}`,
      );
    }
  }

  await connection.end();

  console.log("[OK] migrate-song-version-artists.ts ολοκληρώθηκε.");
}

main()
  .catch((err) => {
    console.error("[FATAL] Σοβαρό σφάλμα στο migrate-song-version-artists.ts:", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

