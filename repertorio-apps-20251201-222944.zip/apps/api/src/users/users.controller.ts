import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
} from "@nestjs/common";
import { UsersService } from "./users.service";
import { UserRole } from "@prisma/client";

@Controller("users")
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  async listUsers(
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
    @Query("search") search?: string,
    @Query("orderby") orderby?: string,
    @Query("order") order?: string,
  ) {
    const pageNumber = Number(page ?? "1");
    const pageSizeNumber = Number(pageSize ?? "10");

    const safePage =
      Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber : 1;
    const safePageSize =
      Number.isFinite(pageSizeNumber) && pageSizeNumber > 0
        ? pageSizeNumber
        : 10;

    const allowedOrderBy = [
      "displayName",
      "username",
      "email",
      "createdAt",
    ] as const;
    const defaultOrderBy: (typeof allowedOrderBy)[number] = "displayName";
    const safeOrderBy = (allowedOrderBy as readonly string[]).includes(
      orderby ?? "",
    )
      ? (orderby as (typeof allowedOrderBy)[number])
      : defaultOrderBy;

    const safeOrder = order === "desc" ? "desc" : "asc";

    return this.usersService.listUsers({
      page: safePage,
      pageSize: safePageSize,
      search: (search ?? "").trim(),
      orderby: safeOrderBy,
      order: safeOrder,
    });
  }

  @Get(":id")
  async getUserById(@Param("id", ParseIntPipe) id: number) {
    return this.usersService.findById(id);
  }

  @Patch(":id")
  async updateUser(
    @Param("id", ParseIntPipe) id: number,
    @Body()
    body: {
      email?: string | null;
      username?: string | null;
      displayName?: string | null;
      role?: UserRole | string;
    },
  ) {
    const payload: {
      email?: string | null;
      username?: string | null;
      displayName?: string | null;
      role?: UserRole;
    } = {};

    if (Object.prototype.hasOwnProperty.call(body, "email")) {
      payload.email =
        body.email === null || body.email === "" ? null : String(body.email);
    }

    if (Object.prototype.hasOwnProperty.call(body, "username")) {
      payload.username =
        body.username === null || body.username === ""
          ? null
          : String(body.username);
    }

    if (Object.prototype.hasOwnProperty.call(body, "displayName")) {
      const v =
        body.displayName === undefined ? undefined : String(body.displayName);
      if (!v || !v.trim()) {
        throw new BadRequestException("displayName is required");
      }
      payload.displayName = v.trim();
    }

    if (Object.prototype.hasOwnProperty.call(body, "role")) {
      const allowedRoles: UserRole[] = [
        UserRole.ADMIN,
        UserRole.EDITOR,
        UserRole.AUTHOR,
        UserRole.CONTRIBUTOR,
        UserRole.SUBSCRIBER,
        UserRole.USER,
      ];
      const value = String(body.role).toUpperCase() as UserRole;
      if (!allowedRoles.includes(value)) {
        throw new BadRequestException(
          `Invalid role: ${body.role}. Allowed: ${allowedRoles.join(", ")}`,
        );
      }
      payload.role = value;
    }

    return this.usersService.updateUser(id, payload);
  }
}
