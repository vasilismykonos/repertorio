import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma, UserRole } from "@prisma/client";

export type UserListItem = {
  id: number;
  email: string | null;
  username: string | null;
  displayName: string | null;
  role: UserRole;
  createdAt: Date;
  createdSongsCount: number;
  createdVersionsCount: number;
};

export type ListUsersOptions = {
  page: number;
  pageSize: number;
  search: string;
  orderby: "displayName" | "username" | "email" | "createdAt";
  order: "asc" | "desc";
};

export type ListUsersResult = {
  items: UserListItem[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

type UpdateUserPayload = {
  email?: string | null;
  username?: string | null;
  displayName?: string | null;
  role?: UserRole;
};

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private mapToUserListItem(u: {
    id: number;
    email: string | null;
    username: string | null;
    displayName: string | null;
    role: UserRole;
    createdAt: Date;
    _count: {
      createdSongs: number;
      createdVersions: number;
    };
  }): UserListItem {
    return {
      id: u.id,
      email: u.email,
      username: u.username,
      displayName: u.displayName,
      role: u.role,
      createdAt: u.createdAt,
      createdSongsCount: u._count?.createdSongs ?? 0,
      createdVersionsCount: u._count?.createdVersions ?? 0,
    };
  }

  async listUsers(options: ListUsersOptions): Promise<ListUsersResult> {
    const { page, pageSize, search, orderby, order } = options;

    const take = Math.max(1, Math.min(pageSize, 100));
    const skip = (Math.max(page, 1) - 1) * take;

    const where: Prisma.UserWhereInput = search
      ? {
          OR: [
            { displayName: { contains: search, mode: "insensitive" } },
            { username: { contains: search, mode: "insensitive" } },
            { email: { contains: search, mode: "insensitive" } },
          ],
        }
      : {};

    const orderByFieldMap: Record<
      ListUsersOptions["orderby"],
      keyof Prisma.UserOrderByWithRelationInput
    > = {
      displayName: "displayName",
      username: "username",
      email: "email",
      createdAt: "createdAt",
    };

    const orderByField = orderByFieldMap[orderby] ?? "displayName";
    const sortOrder: Prisma.SortOrder = order === "desc" ? "desc" : "asc";

    const [rows, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        orderBy: { [orderByField]: sortOrder },
        skip,
        take,
        select: {
          id: true,
          email: true,
          username: true,
          displayName: true,
          role: true,
          createdAt: true,
          _count: {
            select: {
              createdSongs: true,
              createdVersions: true,
            },
          },
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    const totalPages = total === 0 ? 1 : Math.ceil(total / take);

    const items: UserListItem[] = rows.map((u) => this.mapToUserListItem(u));

    return {
      items,
      total,
      page,
      pageSize: take,
      totalPages,
    };
  }

  async findById(id: number): Promise<UserListItem> {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        username: true,
        displayName: true,
        role: true,
        createdAt: true,
        _count: {
          select: {
            createdSongs: true,
            createdVersions: true,
          },
        },
      },
    });

    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    return this.mapToUserListItem(user);
  }

  async updateUser(id: number, payload: UpdateUserPayload): Promise<UserListItem> {
    const data: Prisma.UserUpdateInput = {};

    if (Object.prototype.hasOwnProperty.call(payload, "email")) {
      data.email = payload.email ?? null;
    }
    if (Object.prototype.hasOwnProperty.call(payload, "username")) {
      data.username = payload.username ?? null;
    }
    if (Object.prototype.hasOwnProperty.call(payload, "displayName")) {
      data.displayName = payload.displayName ?? null;
    }
    if (Object.prototype.hasOwnProperty.call(payload, "role")) {
      data.role = payload.role!;
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data,
      select: {
        id: true,
        email: true,
        username: true,
        displayName: true,
        role: true,
        createdAt: true,
        _count: {
          select: {
            createdSongs: true,
            createdVersions: true,
          },
        },
      },
    });

    return this.mapToUserListItem(updated);
  }
}
