export const helloShared = () => "Hello from @repertorio/shared";
