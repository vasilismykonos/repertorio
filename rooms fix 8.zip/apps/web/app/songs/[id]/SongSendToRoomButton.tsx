// apps/web/app/songs/[id]/SongSendToRoomButton.tsx
"use client";

import { useState } from "react";
import { useRooms } from "@/app/components/RoomsProvider";

type SongSendToRoomButtonProps = {
  songId: number;
  title: string;
};

export default function SongSendToRoomButton({
  songId,
  title,
}: SongSendToRoomButtonProps) {
  const { wsConnected, currentRoom, sendSongToRoom } = useRooms();
  const [sending, setSending] = useState(false);

  const disabled = !wsConnected || !currentRoom || sending;

  const handleClick = () => {
    if (disabled) return;

    const url =
      typeof window !== "undefined"
        ? window.location.href
        : `https://app.repertorio.net/songs/${songId}`;

    setSending(true);
    try {
      sendSongToRoom({ songId, title, url });
    } finally {
      // μικρό cooldown για να μην γίνεται spam
      setTimeout(() => setSending(false), 500);
    }
  };

  const titleAttr = currentRoom
    ? `Στείλε αυτό το τραγούδι στους χρήστες του room "${currentRoom}"`
    : "Δεν είσαι συνδεδεμένος σε room";

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled}
      title={titleAttr}
      style={{
        padding: "6px 10px",
        borderRadius: 6,
        border: "1px solid #2b7",
        background: disabled ? "#264" : "#2b7",
        color: "#fff",
        textDecoration: "none",
        fontWeight: 600,
        opacity: disabled ? 0.6 : 1,
        cursor: disabled ? "default" : "pointer",
      }}
    >
      📡 Αποστολή στο Room
    </button>
  );
}
