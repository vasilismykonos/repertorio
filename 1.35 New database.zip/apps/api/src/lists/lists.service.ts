// src/lists/lists.service.ts
import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

type UserContext = {
  legacyUserId: number | null;
  isAdmin: boolean;
};

@Injectable()
export class ListsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Βοηθητικό: βρίσκει τον χρήστη και επιστρέφει legacyUserId + αν είναι admin.
   * Προσοχή: στο νέο canonical schema χρησιμοποιούμε legacyUserId (WP users.ID),
   * όχι wpId.
   */
  private async getUserContext(userId: number): Promise<UserContext> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, legacyUserId: true, role: true },
    });

    if (!user) throw new NotFoundException("User not found");

    const legacyUserId = user.legacyUserId ?? null;
    const isAdmin = user.role === "ADMIN";

    return { legacyUserId, isAdmin };
  }

  /**
   * ACL:
   * - Admin → όλα
   * - Αν δεν έχουμε legacyUserId (σπάνιο) → όλα (πρακτικά guest συμπεριφορά)
   * - Αλλιώς:
   *   ownerWpId = legacyUserId OR viewWpIds contains legacyUserId OR editWpIds contains legacyUserId
   *
   * Σημείωση: κρατάμε τα πεδία ownerWpId/viewWpIds/editWpIds ως έχουν (ιστορικά),
   * αλλά το "wp" εδώ σημαίνει legacy wp_users.ID, δηλαδή legacyUserId.
   */
  private buildAclWhere(legacyUserId: number | null, isAdmin: boolean): any {
    if (isAdmin || legacyUserId == null) {
      return {}; // βλέπει όλα
    }

    const idStr = String(legacyUserId);

    return {
      OR: [
        { ownerWpId: legacyUserId },
        { viewWpIds: { contains: idStr } },
        { editWpIds: { contains: idStr } },
      ],
    };
  }

  async listAllForUser(userId: number) {
    const { legacyUserId, isAdmin } = await this.getUserContext(userId);
    const aclWhere = this.buildAclWhere(legacyUserId, isAdmin);

    const lists = await this.prisma.list.findMany({
      where: aclWhere,
      include: {
        group: true,
        _count: { select: { items: true } },
      },
      orderBy: [{ marked: "desc" }, { updatedAt: "desc" }, { id: "desc" }],
    });

    return lists.map((l) => ({
      id: l.id,
      legacyId: l.legacyId,
      title: l.title,
      marked: l.marked,
      groupId: l.groupId,
      groupTitle: l.group?.title ?? null,
      itemsCount: (l as any)._count?.items ?? 0,
      ownerWpId: l.ownerWpId,
      viewWpIds: l.viewWpIds,
      editWpIds: l.editWpIds,
      createdAt: l.createdAt,
      updatedAt: l.updatedAt,
    }));
  }

  async getOneForUser(userId: number, listId: number) {
    const { legacyUserId, isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      include: {
        group: true,
        items: {
          include: {
            song: true,
          },
          orderBy: [{ sortId: "asc" }, { id: "asc" }],
        },
      },
    });

    if (!list) throw new NotFoundException("List not found");

    if (!isAdmin && legacyUserId != null) {
      const idStr = String(legacyUserId);
      const canView =
        list.ownerWpId === legacyUserId ||
        (list.viewWpIds && list.viewWpIds.includes(idStr)) ||
        (list.editWpIds && list.editWpIds.includes(idStr));

      if (!canView) throw new ForbiddenException("You do not have access to this list");
    }

    return {
      id: list.id,
      legacyId: list.legacyId,
      title: list.title,
      marked: list.marked,
      group: list.group
        ? {
            id: list.group.id,
            legacyId: list.group.legacyId,
            title: list.group.title,
            fullTitle: list.group.fullTitle,
          }
        : null,
      ownerWpId: list.ownerWpId,
      viewWpIds: list.viewWpIds,
      editWpIds: list.editWpIds,
      createdAt: list.createdAt,
      updatedAt: list.updatedAt,
      items: list.items.map((it) => ({
        id: it.id,
        legacyId: it.legacyId,
        sortId: it.sortId,
        title: it.title,
        notes: it.notes,
        transport: it.transport,
        chords: it.chords,
        lyrics: it.lyrics,
        songId: it.songId,
        song:
          it.song == null
            ? null
            : {
                id: it.song.id,
                legacySongId: it.song.legacySongId,
                slug: it.song.slug,
                title: it.song.title,
              },
      })),
    };
  }

  /**
   * Μark/unmark list
   * - Admin: OK
   * - Αλλιώς: μόνο owner ή edit permission
   */
  async setMarked(userId: number, listId: number, marked: boolean) {
    const { legacyUserId, isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      select: { id: true, ownerWpId: true, editWpIds: true },
    });

    if (!list) throw new NotFoundException("List not found");

    if (!isAdmin) {
      if (legacyUserId == null) throw new ForbiddenException("No user legacy id");

      const idStr = String(legacyUserId);
      const canEdit =
        list.ownerWpId === legacyUserId ||
        (list.editWpIds && list.editWpIds.includes(idStr));

      if (!canEdit) throw new ForbiddenException("You do not have edit access to this list");
    }

    return await this.prisma.list.update({
      where: { id: listId },
      data: { marked },
      select: { id: true, marked: true, updatedAt: true },
    });
  }

  /**
   * Update title
   * - Admin: OK
   * - Αλλιώς: μόνο owner ή edit permission
   */
  async rename(userId: number, listId: number, newTitle: string) {
    const title = (newTitle ?? "").trim();
    if (!title) throw new BadRequestException("Title is required");

    const { legacyUserId, isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      select: { id: true, ownerWpId: true, editWpIds: true },
    });

    if (!list) throw new NotFoundException("List not found");

    if (!isAdmin) {
      if (legacyUserId == null) throw new ForbiddenException("No user legacy id");

      const idStr = String(legacyUserId);
      const canEdit =
        list.ownerWpId === legacyUserId ||
        (list.editWpIds && list.editWpIds.includes(idStr));

      if (!canEdit) throw new ForbiddenException("You do not have edit access to this list");
    }

    return await this.prisma.list.update({
      where: { id: listId },
      data: { title },
      select: { id: true, title: true, updatedAt: true },
    });
  }
}
