// apps/api/src/songs/songs.module.ts
import { Module } from "@nestjs/common";
import { SongsService } from "./songs.service";
import { SongsController } from "./songs.controller";
import { ElasticSongsController } from "./elastic-songs.controller";
import { SongsSearchController } from "./songs-search.controller";
import { SongsSearchService } from "./songs-search.service";
import { PrismaService } from "../prisma/prisma.service";

@Module({
  controllers: [SongsSearchController, ElasticSongsController, SongsController],
  providers: [SongsService, SongsSearchService, PrismaService],
})
export class SongsModule {}
