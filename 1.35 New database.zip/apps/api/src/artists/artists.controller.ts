// apps/api/src/artists/artists.controller.ts
import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
} from "@nestjs/common";
import { ArtistsService } from "./artists.service";

// Δεν εισάγουμε enum από Prisma γιατί στο δικό σου client ΔΕΝ υπάρχει.
// Τα κρατάμε ως strings και στο service κάνουμε cast όταν περνάμε σε Prisma.
type VersionArtistRoleString =
  | "SINGER_FRONT"
  | "SINGER_BACK"
  | "SOLOIST"
  | "MUSICIAN"
  | "COMPOSER"
  | "LYRICIST";

type UpdateArtistBody = {
  title?: string;
  firstName?: string | null;
  lastName?: string | null;
  sex?: string | null;
  bornYear?: number | null;
  dieYear?: number | null;
  imageUrl?: string | null;
  biography?: string | null;
  wikiUrl?: string | null;
};

@Controller("artists")
export class ArtistsController {
  constructor(private readonly artistsService: ArtistsService) {}

  /**
   * Αναζήτηση καλλιτεχνών (λίστα)
   * GET /artists/search?q=&skip=&take=&roles=SINGER_FRONT,SOLOIST
   */
  @Get("search")
  async searchArtists(
    @Query("q") q?: string,
    @Query("skip") skipStr?: string,
    @Query("take") takeStr?: string,
    @Query("roles") rolesStr?: string,
  ) {
    const skipNum = Number(skipStr);
    const takeNum = Number(takeStr);

    const skip = Number.isFinite(skipNum) && skipNum >= 0 ? skipNum : 0;
    let take = Number.isFinite(takeNum) && takeNum > 0 ? takeNum : 50;
    if (take > 200) take = 200;

    const roles = (rolesStr ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean) as VersionArtistRoleString[];

    return this.artistsService.search({
      q: q?.trim() || undefined,
      skip,
      take,
      roles,
    });
  }

  /**
   * Λεπτομέρεια καλλιτέχνη (για /artists/:id)
   */
  @Get(":id")
  async getArtistById(@Param("id", ParseIntPipe) id: number) {
    return this.artistsService.findOne(id);
  }

  /**
   * Ενημέρωση καλλιτέχνη
   */
  @Patch(":id")
  async updateArtist(
    @Param("id", ParseIntPipe) id: number,
    @Body() body: UpdateArtistBody,
  ) {
    return this.artistsService.updateArtist(id, body);
  }
}
