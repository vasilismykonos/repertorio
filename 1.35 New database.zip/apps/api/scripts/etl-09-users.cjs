#!/usr/bin/env node
"use strict";

require("dotenv/config");
const { PrismaClient } = require("@prisma/client");
const { Client } = require("pg");

function toNullIfEmpty(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

function toBoolOrNull(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === "boolean") return v;
  const s = String(v).trim().toLowerCase();
  if (s === "1" || s === "true" || s === "t" || s === "yes" || s === "y") return true;
  if (s === "0" || s === "false" || s === "f" || s === "no" || s === "n") return false;
  return null;
}

function toIntOrNull(v) {
  if (v === undefined || v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : null;
}

async function main() {
  console.log("ETL 09: users legacy -> app");

  const prisma = new PrismaClient();
  const pg = new Client({
    connectionString: process.env.DATABASE_URL,
  });

  await pg.connect();

  // Φέρνουμε όλους τους legacy users (από schema legacy, table legacy_users)
  const res = await pg.query(`
    SELECT
      "ID",
      "user_login",
      "user_email",
      "display_name",
      "User_Room",
      "Rooms",
      "Redirect_Field",
      "Hide_Chords",
      "current_url",
      "Dark_Mode",
      "Devices",
      "FontSize",
      "View_Other_User_Chords",
      "Hide_Info"
    FROM legacy."legacy_users"
    ORDER BY "ID" ASC
  `);

  console.log("legacy users:", res.rowCount);

  let upserted = 0;
  let skippedNoKey = 0;

  for (const r of res.rows) {
    const legacyUserId = toIntOrNull(r.ID);
    if (!legacyUserId) {
      skippedNoKey++;
      continue;
    }

    // Στο τρέχον σου schema, User έχει μόνο: email, username, displayName, role, legacyUserId
    // Δεν αποθηκεύουμε τα extra WP prefs τώρα (αν τα θες, τα προσθέτουμε μετά στο schema).
    const username = toNullIfEmpty(r.user_login);
    const email = toNullIfEmpty(r.user_email);
    const displayName = toNullIfEmpty(r.display_name);

    await prisma.user.upsert({
      where: { legacyUserId },
      create: {
        legacyUserId,
        username,
        email,
        displayName,
        // role default USER
      },
      update: {
        username,
        email,
        displayName,
      },
    });

    upserted++;
    if (upserted % 50 === 0) {
      console.log(`...upserted ${upserted}/${res.rowCount}`);
    }
  }

  await prisma.$disconnect();
  await pg.end();

  console.log("DONE users:", upserted);
  console.log("Skipped (missing legacy ID):", skippedNoKey);
}

main().catch((err) => {
  console.error("ETL 09 failed:", err);
  process.exitCode = 1;
});
