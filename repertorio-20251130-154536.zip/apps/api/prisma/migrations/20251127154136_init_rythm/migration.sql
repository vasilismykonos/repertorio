-- CreateTable
CREATE TABLE "Rythm" (
    "id" SERIAL NOT NULL,
    "title" TEXT NOT NULL,

    CONSTRAINT "Rythm_pkey" PRIMARY KEY ("id")
);
