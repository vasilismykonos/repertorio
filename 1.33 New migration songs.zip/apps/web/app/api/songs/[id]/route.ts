// app/api/songs/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { fetchJson } from "@/lib/api";

// Απλός τύπος για την απόκριση του Nest API
type ApiSongResponse = {
  id: number;
  title: string;
};

function buildRedirectHtml(targetPath: string): string {
  const safePath = targetPath.startsWith("/") ? targetPath : `/${targetPath}`;

  return `<!DOCTYPE html>
<html lang="el">
  <head>
    <meta charset="utf-8" />
    <title>Μεταφορά...</title>
    <meta http-equiv="refresh" content="0; url=${safePath}" />
  </head>
  <body>
    <p>Μεταφορά... Αν δεν γίνει αυτόματα, πατήστε
      <a href="${safePath}">εδώ</a>.
    </p>
    <script>
      window.location.href = "${safePath}";
    </script>
  </body>
</html>`;
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  const rawId = params.id;
  let idNum = Number(rawId);

  if (!Number.isFinite(idNum) || idNum <= 0) {
    const html = buildRedirectHtml("/songs");
    return new NextResponse(html, {
      status: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  let ok = true;

  try {
    const formData = await req.formData();

    const title = formData.get("title");
    const firstLyrics = formData.get("firstLyrics");
    const lyrics = formData.get("lyrics");
    const characteristics = formData.get("characteristics");
    const originalKey = formData.get("originalKey");
    const chords = formData.get("chords");
    const status = formData.get("status");
    const categoryId = formData.get("categoryId");
    const rythmId = formData.get("rythmId");
    const makamId = formData.get("makamId");

    const body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      chords?: string | null;
      status?: string;
      categoryId?: number | null;
      rythmId?: number | null;
      makamId?: number | null;
    } = {};

    if (title !== null) {
      body.title = String(title);
    }

    if (firstLyrics !== null) {
      const v = String(firstLyrics);
      body.firstLyrics = v === "" ? null : v;
    }

    if (lyrics !== null) {
      const v = String(lyrics);
      body.lyrics = v === "" ? null : v;
    }

    if (characteristics !== null) {
      const v = String(characteristics);
      body.characteristics = v === "" ? null : v;
    }

    if (originalKey !== null) {
      const v = String(originalKey);
      body.originalKey = v === "" ? null : v;
    }

    if (chords !== null) {
      const v = String(chords);
      body.chords = v === "" ? null : v;
    }

    if (status !== null) {
      body.status = String(status);
    }

    if (categoryId !== null) {
      const v = String(categoryId);
      if (v === "") {
        body.categoryId = null;
      } else {
        const n = Number(v);
        if (Number.isFinite(n) && n > 0) {
          body.categoryId = n;
        }
      }
    }

    if (rythmId !== null) {
      const v = String(rythmId);
      if (v === "") {
        body.rythmId = null;
      } else {
        const n = Number(v);
        if (Number.isFinite(n) && n > 0) {
          body.rythmId = n;
        }
      }
    }

    if (makamId !== null) {
      const v = String(makamId);
      if (v === "") {
        body.makamId = null;
      } else {
        const n = Number(v);
        if (Number.isFinite(n) && n > 0) {
          body.makamId = n;
        }
      }
    }

    // Κλήση προς Nest API: PATCH /songs/:id
    await fetchJson<ApiSongResponse>(`/songs/${idNum}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  } catch (err) {
    ok = false;
    console.error("Update song failed for id=", rawId, err);
  }

  const targetPath = ok ? `/songs/${idNum}` : `/songs/${idNum}?error=1`;
  const html = buildRedirectHtml(targetPath);

  return new NextResponse(html, {
    status: 200,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
}
