// app/songs/[id]/edit/page.tsx
import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi, type UserRole } from "@/lib/currentUser";

export const dynamic = "force-dynamic";

type SongForEdit = {
  id: number;
  title: string;
  firstLyrics: string | null;
  lyrics: string | null;
  characteristics: string | null;
  originalKey: string | null;
  chords: string | null;
  status: string | null;
  categoryId?: number | null;
  rythmId?: number | null;
  makamId?: number | null;
};

type CategoryOption = {
  id: number;
  title: string;
};

type RythmOption = {
  id: number;
  title: string;
};

async function fetchSong(id: number): Promise<SongForEdit> {
  return await fetchJson<SongForEdit>(`/songs/${id}?noIncrement=1`);
}

async function fetchCategories(): Promise<CategoryOption[]> {
  const items = await fetchJson<any[]>(`/categories`);
  return items.map((c) => ({
    id: c.id as number,
    title: String(c.title ?? ""),
  }));
}

async function fetchRythms(): Promise<RythmOption[]> {
  const items = await fetchJson<any[]>(`/rythms`);
  return items.map((r) => ({
    id: r.id as number,
    title: String(r.title ?? ""),
  }));
}

export const metadata: Metadata = {
  title: "Επεξεργασία τραγουδιού | Repertorio Next",
  description: "Φόρμα επεξεργασίας τραγουδιού.",
};

type SongEditPageProps = {
  params: {
    id: string;
  };
};

const EDIT_ROLES: UserRole[] = ["ADMIN", "EDITOR", "AUTHOR"];

export default async function SongEditPage({ params }: SongEditPageProps) {
  const songId = Number(params.id);
  if (!Number.isFinite(songId) || songId <= 0) {
    redirect("/songs");
  }

  const [song, currentUser, categories, rythms] = await Promise.all([
    fetchSong(songId),
    getCurrentUserFromApi(),
    fetchCategories(),
    fetchRythms(),
  ]);

  if (!currentUser) {
    redirect(`/songs/${songId}`);
  }

  const canEdit = EDIT_ROLES.includes(currentUser.role);
  if (!canEdit) {
    redirect(`/songs/${songId}`);
  }

  const statusValue = song.status ?? "DRAFT";

  return (
    <main className="song-edit-page">
      <section className="song-edit-wrapper">
        <header className="song-edit-header">
          <p className="song-edit-breadcrumb">
            <Link href="/songs" className="song-edit-breadcrumb-link">
              Τραγούδια
            </Link>
            <span className="song-edit-breadcrumb-separator">/</span>
            <Link
              href={`/songs/${song.id}`}
              className="song-edit-breadcrumb-link"
            >
              #{song.id}
            </Link>
            <span className="song-edit-breadcrumb-separator">/</span>
            <span className="song-edit-breadcrumb-current">Επεξεργασία</span>
          </p>

          <h1 className="song-edit-title">
            Επεξεργασία τραγουδιού #{song.id}
          </h1>

          <p className="song-edit-subtitle">
            Τρέχων τίτλος:&nbsp;
            <strong>{song.title}</strong>
          </p>
        </header>

        <form
          method="POST"
          action={`/api/songs/${song.id}`}
          className="song-edit-form"
        >
          {/* Βασικές πληροφορίες */}
          <div className="song-edit-section">
            <h2 className="song-edit-section-title">Βασικές πληροφορίες</h2>

            <div className="song-edit-field">
              <label htmlFor="title">Τίτλος *</label>
              <input
                type="text"
                id="title"
                name="title"
                defaultValue={song.title}
                required
              />
            </div>

            <div className="song-edit-field">
              <label htmlFor="firstLyrics">Πρώτοι στίχοι</label>
              <input
                type="text"
                id="firstLyrics"
                name="firstLyrics"
                placeholder="Π.χ. Ρε συ Νότη πρασσαντζήπάμ..."
                defaultValue={song.firstLyrics ?? ""}
              />
            </div>

            <div className="song-edit-field">
              <label htmlFor="lyrics">Στίχοι (πλήρες κείμενο)</label>
              <textarea
                id="lyrics"
                name="lyrics"
                rows={10}
                placeholder="Εισαγωγή, κουπλέ, ρεφρέν..."
                defaultValue={song.lyrics ?? ""}
              />
            </div>
          </div>

          {/* Συγχορδίες & χαρακτηριστικά */}
          <div className="song-edit-section">
            <h2 className="song-edit-section-title">
              Συγχορδίες &amp; χαρακτηριστικά
            </h2>

            <div className="song-edit-field">
              <label htmlFor="chords">Συγχορδίες (raw σημειογραφία)</label>
              <textarea
                id="chords"
                name="chords"
                rows={8}
                placeholder="Γράψε εδώ τη σημειογραφία σου..."
                defaultValue={song.chords ?? ""}
              />
            </div>

            <div className="song-edit-field">
              <label htmlFor="characteristics">Χαρακτηριστικά</label>
              <input
                type="text"
                id="characteristics"
                name="characteristics"
                placeholder="Π.χ. Ρεμπέτικο, Προπολεμικό, Οργανικό..."
                defaultValue={song.characteristics ?? ""}
              />
            </div>
          </div>

          {/* Τεχνικά στοιχεία / Μεταδεδομένα */}
          <div className="song-edit-section song-edit-grid">
            <div className="song-edit-field">
              <label htmlFor="originalKey">Αρχικός τόνος</label>
              <input
                type="text"
                id="originalKey"
                name="originalKey"
                placeholder="Π.χ. Ρε-"
                defaultValue={song.originalKey ?? ""}
              />
            </div>

            <div className="song-edit-field">
              <label htmlFor="status">Κατάσταση</label>
              <select id="status" name="status" defaultValue={statusValue}>
                <option value="DRAFT">Πρόχειρο</option>
                <option value="PENDING_APPROVAL">Για έγκριση</option>
                <option value="PUBLISHED">Δημοσιευμένο</option>
                <option value="ARCHIVED">Αρχειοθετημένο</option>
              </select>
            </div>

            <div className="song-edit-field">
              <label htmlFor="categoryId">Κατηγορία</label>
              <select
                id="categoryId"
                name="categoryId"
                defaultValue={
                  typeof song.categoryId === "number"
                    ? String(song.categoryId)
                    : ""
                }
              >
                <option value="">(Χωρίς κατηγορία)</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>

            <div className="song-edit-field">
              <label htmlFor="rythmId">Ρυθμός</label>
              <select
                id="rythmId"
                name="rythmId"
                defaultValue={
                  typeof song.rythmId === "number" ? String(song.rythmId) : ""
                }
              >
                <option value="">(Χωρίς ρυθμό)</option>
                {rythms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <footer className="song-edit-actions">
            <button type="submit" className="song-edit-submit">
              Αποθήκευση αλλαγών
            </button>

            <Link href={`/songs/${song.id}`} className="song-edit-cancel">
              Άκυρο
            </Link>
          </footer>
        </form>
      </section>
    </main>
  );
}
