// app/songs/[id]/page.tsx
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi } from "@/lib/currentUser";

import SongChordsClient from "./SongChordsClient";
import SongInfoToggle from "./SongInfoToggle";
import ScorePlayerClient from "./score/ScorePlayerClient";
import SongSendToRoomButton from "./SongSendToRoomButton";

export const dynamic = "force-dynamic";

type SongVersion = {
  id: number;
  year: number | null;
  singerFront: string | null;
  singerBack: string | null;
  solist: string | null;
  youtubeSearch: string | null;

  singerFrontId?: number | null;
  singerBackId?: number | null;
  solistId?: number | null;
};

type SongDetail = {
  id: number;
  title: string;
  firstLyrics: string | null;
  lyrics: string | null;
  characteristics: string | null;
  originalKey: string | null;
  chords: string | null;
  status: string | null;
  categoryId?: number | null;
  rythmId?: number | null;
  makamId?: number | null;

  categoryTitle: string | null;
  composerName: string | null;
  lyricistName: string | null;
  rythmTitle: string | null;
  basedOnSongId: number | null;
  basedOnSongTitle: string | null;
  views: number;

  createdByUserId?: number | null;

  versions: SongVersion[];
};

type SongPageProps = {
  params: {
    id: string;
  };
};

// Βοηθητικό slug (σαν sanitize_title)
function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

// Πρώτες 5 λέξεις για YouTube search
function getFirstWordsForYoutube(
  firstLyrics: string | null,
  lyrics: string | null,
): string {
  const source = firstLyrics || lyrics || "";
  if (!source.trim()) return "";
  const words = source.trim().split(/\s+/).slice(0, 5);
  return words.join(" ");
}

// Normalisation ΔΙΣΚΟΓΡΑΦΙΑΣ – δέχεται τόσο camelCase όσο και snake_case
function normalizeVersions(raw: any): SongVersion[] | null {
  if (!raw || !Array.isArray(raw) || raw.length === 0) {
    return null;
  }

  return raw.map((v: any, idx: number) => ({
    id:
      v.id ??
      v.versionId ??
      v.version_id ??
      idx, // fallback αν δεν έρθει id
    year: v.year ?? v.Year ?? v.releaseYear ?? v.release_year ?? null,
    singerFront:
      v.singerFront ??
      v.singer_front ??
      v.singerfront ??
      v.singer_front_name ??
      null,
    singerBack:
      v.singerBack ??
      v.singer_back ??
      v.singerback ??
      v.singer_back_name ??
      null,
    solist:
      v.solist ??
      v.soloist ??
      v.solist_name ??
      v.soloist_name ??
      null,
    youtubeSearch:
      v.youtubeSearch ??
      v.youtube_search ??
      v.youtubeQuery ??
      v.youtube_query ??
      null,

    singerFrontId:
      v.singerFrontId ?? v.singer_front_id ?? v.singerfront_id ?? null,
    singerBackId:
      v.singerBackId ?? v.singer_back_id ?? v.singerback_id ?? null,
    solistId: v.solistId ?? v.soloistId ?? v.solist_id ?? v.soloist_id ?? null,
  }));
}

// Schema.org MusicComposition (αντίστοιχο generate_song_schema)
function renderSongSchema(song: SongDetail) {
  const schema = {
    "@context": "https://schema.org",
    "@type": "MusicComposition",
    name: song.title,
    composer: song.composerName
      ? {
          "@type": "Person",
          name: song.composerName,
        }
      : undefined,
    lyricist: song.lyricistName
      ? {
          "@type": "Person",
          name: song.lyricistName,
        }
      : undefined,
    genre: song.categoryTitle || undefined,
    inLanguage: "el",
    lyrics:
      song.lyrics && song.lyrics.trim() !== ""
        ? song.lyrics
        : "Χωρίς διαθέσιμους στίχους",
    isAccessibleForFree: true,
    url: `https://repertorio.net/songs/song/${song.id}-${slugify(
      song.title,
    )}/`,
  };

  const json = JSON.stringify(schema, null, 2);
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: json }}
    />
  );
}

// Δυναμικός τίτλος σελίδας (σαν το παλιό wp_title / meta)
export async function generateMetadata({ params }: SongPageProps) {
  const songId = Number(params.id);
  if (!songId || Number.isNaN(songId)) {
    return {
      title: "Μη έγκυρο τραγούδι | Repertorio Next",
    };
  }

  let song: any = null;

  try {
    // noIncrement=1 → ΔΕΝ αυξάνουμε views από το metadata fetch
    song = await fetchJson<any>(`/songs/${songId}?noIncrement=1`);
  } catch {
    // Αν αποτύχει το fetch, επιστρέφουμε generic metadata
  }

  if (!song) {
    return {
      title: "Τραγούδι | Repertorio Next",
    };
  }

  const title: string = song.title ?? "Τραγούδι";

  const composerName: string | undefined =
    song.composerName ?? song.composer_name ?? undefined;

  const parts = [title];
  if (composerName) {
    parts.push(composerName);
  }
  const baseTitle = parts.join(" - ");

  const firstLyrics: string | undefined =
    song.firstLyrics ?? song.first_lyrics ?? undefined;
  const lyrics: string | undefined = song.lyrics ?? undefined;

  return {
    title: `${baseTitle} | Repertorio Next`,
    description: firstLyrics || lyrics || undefined,
    alternates: {
      canonical: `https://repertorio.net/songs/song/${songId}-${slugify(
        title,
      )}/`,
    },
  };
}

export default async function SongPage({ params }: SongPageProps) {
  const songId = Number(params.id);

  if (!songId || Number.isNaN(songId)) {
    return (
      <section
        style={{
          padding: "24px 16px",
          maxWidth: 900,
          margin: "0 auto",
        }}
      >
        <p>Μη έγκυρο ID τραγουδιού.</p>
      </section>
    );
  }

  // ------- ΦΟΡΤΩΣΗ ΤΡΑΓΟΥΔΙΟΥ ΑΠΟ API --------
  let rawSong: any;
  try {
    // Εδώ ΘΕΛΟΥΜΕ να αυξηθεί ο μετρητής views
    rawSong = await fetchJson<any>(`/songs/${songId}`);
  } catch (e) {
    return (
      <section
        style={{
          padding: "24px 16px",
          maxWidth: 900,
          margin: "0 auto",
        }}
      >
        <p>Σφάλμα κατά την φόρτωση του τραγουδιού.</p>
      </section>
    );
  }

  // ------- NORMALISATION SONG + VERSIONS --------
  const normalizedVersions = normalizeVersions(rawSong.versions);

  const song: SongDetail = {
    id: rawSong.id,
    title: rawSong.title,
    firstLyrics: rawSong.firstLyrics ?? rawSong.first_lyrics ?? null,
    lyrics: rawSong.lyrics ?? null,
    characteristics: rawSong.characteristics ?? null,
    originalKey: rawSong.originalKey ?? rawSong.original_key ?? null,
    chords: rawSong.chords ?? null,
    status: rawSong.status ?? null,

    categoryId:
      rawSong.categoryId ?? rawSong.category_id ?? null,
    rythmId:
      rawSong.rythmId ??
      rawSong.rythm_id ??
      rawSong.rhythmId ??
      rawSong.rhythm_id ??
      null,
    makamId: rawSong.makamId ?? rawSong.makam_id ?? null,

    categoryTitle: rawSong.categoryTitle ?? rawSong.category_title ?? null,
    composerName: rawSong.composerName ?? rawSong.composer_name ?? null,
    lyricistName: rawSong.lyricistName ?? rawSong.lyricist_name ?? null,
    rythmTitle:
      rawSong.rythmTitle ??
      rawSong.rythm_title ??
      rawSong.rhythmTitle ??
      rawSong.rhythm_title ??
      null,
    basedOnSongId:
      rawSong.basedOnSongId ?? rawSong.based_on_song_id ?? null,
    basedOnSongTitle:
      rawSong.basedOnSongTitle ?? rawSong.based_on_song_title ?? null,
    views: rawSong.views ?? 0,

    createdByUserId:
      rawSong.createdByUserId ?? rawSong.created_by_user_id ?? null,

    versions: normalizedVersions ?? [],
  };

  // ------- ΦΟΡΤΩΣΗ ΤΡΕΧΟΝΤΟΣ ΧΡΗΣΤΗ ΓΙΑ ΔΙΚΑΙΩΜΑ ΕΠΕΞΕΡΓΑΣΙΑΣ --------
  let currentUser: any = null;
  try {
    currentUser = await getCurrentUserFromApi();
  } catch {
    currentUser = null;
  }

  const isAdmin =
    currentUser &&
    (currentUser.role === "ADMIN" || currentUser.role === "SUPER_ADMIN");

  const isOwner =
    currentUser &&
    typeof currentUser.id === "number" &&
    song.createdByUserId != null &&
    currentUser.id === song.createdByUserId;

  const canEdit = Boolean(isAdmin || isOwner);

  // Λογική "Οργανικό" / "Χωρίς στίχους" όπως στο παλιό PHP
  const isOrganic =
    song.characteristics
      ?.split(",")
      .some((c) => c.trim() === "Οργανικό") ?? false;

  let finalLyrics: string;
  if (isOrganic) {
    finalLyrics = "(Οργανικό)";
  } else if (!song.lyrics || song.lyrics.trim() === "") {
    finalLyrics = "(Χωρίς διαθέσιμους στίχους)";
  } else {
    finalLyrics = song.lyrics;
  }

  const firstWords = getFirstWordsForYoutube(
    song.firstLyrics,
    song.lyrics,
  );
  const youtubeSearchQuery = `${song.title} ${firstWords}`.trim();
  const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(
    youtubeSearchQuery,
  )}&app=revanced`;

  // Διαδρομή αρχείου παρτιτούρας (όπως την έχεις ρυθμίσει)
  const scoreFileUrl = `/scores/${song.id}.mxl`;

  return (
    <section
      style={{
        padding: "24px 16px",
        maxWidth: 900,
        margin: "0 auto",
      }}
    >
      {/* Κουμπιά πάνω δεξιά – Παρτιτούρα / YouTube / Αποστολή στο Room / Επεξεργασία */}
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          gap: 8,
          marginBottom: 16,
        }}
      >
        {/* Κουμπί Επεξεργασία (μόνο αν έχει δικαίωμα) */}
        {canEdit && (
          <Link
            href={`/songs/${song.id}/edit`}
            style={{
              padding: "6px 10px",
              borderRadius: 6,
              border: "1px solid #555",
              background: "#222",
              color: "#fff",
              textDecoration: "none",
              fontWeight: 600,
            }}
            title="Επεξεργασία τραγουδιού"
          >
            ✏️ Επεξεργασία
          </Link>
        )}

        {/* Κουμπί αποστολής στους χρήστες του room */}
        <SongSendToRoomButton songId={song.id} title={song.title} />

        {/* Link για full-screen παρτιτούρα */}
        <a
          href={`/songs/${song.id}/score`}
          target="_blank"
          rel="noreferrer"
          style={{
            padding: "6px 10px",
            borderRadius: 6,
            border: "1px solid #333",
            background: "#111",
            color: "#fff",
            textDecoration: "none",
            fontWeight: 600,
          }}
          title="Προβολή παρτιτούρας σε νέο παράθυρο"
        >
          📄 Παρτιτούρα
        </a>

        {/* YouTube button (όπως το παλιό youtubetbutton) */}
        <a
          href={youtubeUrl}
          target="_blank"
          rel="noreferrer"
          style={{
            padding: "6px 10px",
            borderRadius: 6,
            border: "1px solid #c00",
            background: "#c00",
            color: "#fff",
            textDecoration: "none",
            fontWeight: 600,
          }}
          title="Αναζήτηση στο YouTube"
        >
          ▶ YouTube
        </a>
      </div>

      {/* Τίτλος τραγουδιού */}
      <header style={{ marginBottom: 16 }}>
        <h1 style={{ fontSize: "1.8rem", fontWeight: 700, marginBottom: 8 }}>
          {song.title}
        </h1>
      </header>

      {/* Διαχωριστική γραμμή */}
      <div
        style={{
          height: 1,
          background: "linear-gradient(to right, #444, transparent)",
          marginBottom: 16,
        }}
      />

      {/* INFO + Δισκογραφία */}
      <SongInfoToggle
        categoryTitle={song.categoryTitle}
        composerName={song.composerName}
        lyricistName={song.lyricistName}
        rythmTitle={song.rythmTitle}
        basedOnSongTitle={song.basedOnSongTitle}
        basedOnSongId={song.basedOnSongId}
        characteristics={song.characteristics}
        views={song.views}
        status={song.status}
        versions={song.versions}
      />

      {/* Συγχορδίες */}
      {song.chords && song.chords.trim() !== "" && (
        <SongChordsClient chords={song.chords} originalKey={song.originalKey} />
      )}

      {/* Στίχοι */}
      <section style={{ marginTop: 24, marginBottom: 32 }}>
        <pre
          style={{
            whiteSpace: "pre-wrap",
            backgroundColor: "#111",
            padding: "16px",
            borderRadius: 8,
            border: "1px solid #333",
            lineHeight: 1.6,
            fontFamily: "inherit",
            fontSize: "1rem",
          }}
        >
          {finalLyrics}
        </pre>
      </section>

      {/* Παρτιτούρα */}
      <section id="score-section" style={{ marginTop: 32 }}>
        <h2
          style={{
            fontSize: "1.2rem",
            fontWeight: 600,
            marginBottom: 12,
          }}
        >
          Παρτιτούρα
        </h2>

        <ScorePlayerClient fileUrl={scoreFileUrl} title={song.title} />
      </section>

      {/* Schema.org JSON-LD */}
      {renderSongSchema(song)}
    </section>
  );
}
