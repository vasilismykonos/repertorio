import { PrismaClient } from "@prisma/client";
import mysql from "mysql2/promise";

const prisma = new PrismaClient();

const MYSQL_CONFIG = {
  host: "127.0.0.1",
  user: "root",
  password: process.env.MYSQL_PASSWORD || "",
  database: "repertorio.net",
};

async function main() {
  if (!MYSQL_CONFIG.password) {
    throw new Error("Missing MYSQL_PASSWORD env var");
  }

  const mysqlConn = await mysql.createConnection(MYSQL_CONFIG);

  try {
    const [mysqlRows]: any[] = await mysqlConn.query(
      `SELECT Song_ID FROM songs ORDER BY Song_ID ASC`
    );

    const pgRows = await prisma.song.findMany({
      orderBy: { id: "asc" },
      select: { id: true },
    });

    if (mysqlRows.length !== pgRows.length) {
      throw new Error(`Count mismatch: MySQL=${mysqlRows.length}, Postgres=${pgRows.length}`);
    }

    console.log(`Mapping ${pgRows.length} songs (Postgres id -> MySQL Song_ID)...`);

    const BATCH = 500;
    for (let i = 0; i < pgRows.length; i += BATCH) {
      const ops = [];
      for (let j = i; j < i + BATCH && j < pgRows.length; j++) {
        ops.push(
          prisma.song.update({
            where: { id: pgRows[j].id },
            data: { legacySongId: mysqlRows[j].Song_ID },
          })
        );
      }
      await prisma.$transaction(ops);
      console.log(`Updated ${Math.min(i + BATCH, pgRows.length)} / ${pgRows.length}`);
    }

    console.log("Done.");
  } finally {
    await prisma.$disconnect();
    await mysqlConn.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

