// apps/api/src/artists/artists.controller.ts
import {
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Query,
  Patch,
  Body,
} from "@nestjs/common";
import { ArtistsService } from "./artists.service";
import { VersionArtistRole } from "@prisma/client";

type UpdateArtistBody = {
  title?: string;
  firstName?: string | null;
  lastName?: string | null;
  sex?: string | null;
  bornYear?: number | null;
  dieYear?: number | null;
  imageUrl?: string | null;
  biography?: string | null;
  wikiUrl?: string | null;
};

@Controller("artists")
export class ArtistsController {
  constructor(private readonly artistsService: ArtistsService) {}

  @Get()
  async searchArtists(
    @Query("q") q?: string,
    @Query("skip") skipStr?: string,
    @Query("take") takeStr?: string,
    @Query("role") roleQuery?: string | string[],
  ) {
    let skip = parseInt(skipStr ?? "0", 10);
    if (Number.isNaN(skip) || skip < 0) skip = 0;

    let take = parseInt(takeStr ?? "50", 10);
    if (Number.isNaN(take) || take <= 0) take = 50;
    if (take > 200) take = 200;

    // role μπορεί να είναι είτε string είτε string[]
    const roleStrings: string[] = Array.isArray(roleQuery)
      ? roleQuery
      : roleQuery
      ? [roleQuery]
      : [];

    // Κρατάμε μόνο έγκυρα enums VersionArtistRole
    const roles: VersionArtistRole[] = roleStrings
      .map((r) => r.trim())
      .filter(Boolean)
      .map((r) => r as VersionArtistRole);

    return this.artistsService.search({
      q: q?.trim() || undefined,
      skip,
      take,
      roles,
    });
  }

  @Get(":id")
  async getArtistById(@Param("id", ParseIntPipe) id: number) {
    return this.artistsService.findOne(id);
  }

  @Patch(":id")
  async updateArtist(
    @Param("id", ParseIntPipe) id: number,
    @Body() body: UpdateArtistBody,
  ) {
    return this.artistsService.updateArtist(id, body);
  }
}
