// apps/api/src/artists/artists.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma, VersionArtistRole } from "@prisma/client";

type ArtistSearchParams = {
  q?: string;
  skip: number;
  take: number;
  roles: VersionArtistRole[];
};

type UpdateArtistData = {
  title?: string;
  firstName?: string | null;
  lastName?: string | null;
  sex?: string | null;
  bornYear?: number | null;
  dieYear?: number | null;
  imageUrl?: string | null;
  biography?: string | null;
  wikiUrl?: string | null;
};

@Injectable()
export class ArtistsService {
  constructor(private readonly prisma: PrismaService) {}

  async search(params: ArtistSearchParams) {
    const skip = params.skip ?? 0;
    const take = params.take ?? 50;
    const q = params.q?.trim() || undefined;
    const roles = params.roles ?? [];

    const where: Prisma.ArtistWhereInput = {};

    // Φίλτρο κειμένου
    if (q) {
      where.OR = [
        {
          title: {
            contains: q,
            mode: "insensitive",
          },
        },
        {
          firstName: {
            contains: q,
            mode: "insensitive",
          },
        },
        {
          lastName: {
            contains: q,
            mode: "insensitive",
          },
        },
      ];
    }

    // Φίλτρο ρόλων (multi-select)
    if (roles.length > 0) {
      where.versionRoles = {
        some: {
          role: {
            in: roles,
          },
        },
      };
    }

    const [items, total] = await this.prisma.$transaction([
      this.prisma.artist.findMany({
        where,
        orderBy: { title: "asc" },
        skip,
        take,
        select: {
          id: true,
          title: true,
          firstName: true,
          lastName: true,
          imageUrl: true,
          bornYear: true,
          dieYear: true,
        },
      }),
      this.prisma.artist.count({ where }),
    ]);

    return {
      items,
      total,
      skip,
      take,
      q: q ?? "",
      role: roles,
    };
  }

  async findOne(id: number) {
    const artist = await this.prisma.artist.findUnique({
      where: { id },
      include: {
        versionRoles: {
          include: {
            version: {
              include: {
                song: true,
              },
            },
          },
        },
      },
    });

    if (!artist) {
      throw new NotFoundException(`Artist with id=${id} not found`);
    }

    const roles = artist.versionRoles
      .filter((vr) => vr.version && vr.version.song)
      .map((vr) => ({
        versionId: vr.versionId,
        versionTitle: vr.version.title,
        year: vr.version.year,
        role: vr.role,
        songId: vr.version.song.id,
        songTitle: vr.version.song.title,
      }));

    return {
      id: artist.id,
      title: artist.title,
      firstName: artist.firstName,
      lastName: artist.lastName,
      sex: artist.sex,
      bornYear: artist.bornYear,
      dieYear: artist.dieYear,
      imageUrl: artist.imageUrl,
      biography: artist.biography,
      wikiUrl: artist.wikiUrl,
      roles,
    };
  }

  /**
   * Ενημέρωση στοιχείων καλλιτέχνη (χωρίς να πειράζουμε τα versionRoles).
   * Όπως στα Songs: παίρνουμε ένα object με πεδία και ενημερώνουμε μόνο όσα έρχονται.
   */
  async updateArtist(id: number, payload: UpdateArtistData) {
    const existing = await this.prisma.artist.findUnique({
      where: { id },
    });

    if (!existing) {
      throw new NotFoundException(`Artist with id=${id} not found`);
    }

    const data: Prisma.ArtistUpdateInput = {};

    if (payload.title !== undefined) {
      data.title = payload.title;
    }
    if (payload.firstName !== undefined) {
      data.firstName = payload.firstName;
    }
    if (payload.lastName !== undefined) {
      data.lastName = payload.lastName;
    }
    if (payload.sex !== undefined) {
      data.sex = payload.sex;
    }
    if (payload.bornYear !== undefined) {
      data.bornYear = payload.bornYear;
    }
    if (payload.dieYear !== undefined) {
      data.dieYear = payload.dieYear;
    }
    if (payload.imageUrl !== undefined) {
      data.imageUrl = payload.imageUrl;
    }
    if (payload.biography !== undefined) {
      data.biography = payload.biography;
    }
    if (payload.wikiUrl !== undefined) {
      data.wikiUrl = payload.wikiUrl;
    }

    await this.prisma.artist.update({
      where: { id },
      data,
    });

    // Επιστρέφουμε το ίδιο shape με το findOne, για να είναι ενιαίο.
    return this.findOne(id);
  }
}
