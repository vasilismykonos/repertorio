// src/songs/songs.service.ts

import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { SongStatus } from "@prisma/client";

export enum VersionArtistRole {
  SINGER_FRONT = "SINGER_FRONT",
  SINGER_BACK = "SINGER_BACK",
  SOLOIST = "SOLOIST",
  MUSICIAN = "MUSICIAN",
}

@Injectable()
export class SongsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Επιστρέφει 1 τραγούδι σε μορφή DTO που ταιριάζει
   * με το SongDetail του Next.
   *
   * Αν noIncrement=true δεν αυξάνει τα views.
   */
  async findOne(id: number, noIncrement = false): Promise<any> {
    const song = await this.prisma.song.findUnique({
      where: { id },
      include: {
        category: true,
        rythm: true,
        composer: true,
        lyricist: true,
        versions: {
          include: {
            artists: {
              include: {
                artist: true,
              },
            },
          },
        },
      },
    });

    if (!song) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    // Αν δεν θέλουμε αύξηση views, δεν κάνουμε τίποτα.
    if (!noIncrement) {
      await this.prisma.song.update({
        where: { id },
        data: {
          views: (song.views ?? 0) + 1,
        },
      });
    }

    // -----------------------------
    // Υπολογισμός categoryTitle
    // -----------------------------
    const categoryTitle = song.category ? song.category.title : null;

    // -----------------------------
    // Υπολογισμός composerName / lyricistName
    // ΠΑΛΙΑ ΦΙΛΟΣΟΦΙΑ: ΑΝΑ SONG, ΟΧΙ ΑΝΑ VERSION
    // -----------------------------
    let composerName: string | null = null;
    let lyricistName: string | null = null;

    if (song.composer) {
      const a = song.composer;
      const full =
        `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim();
      composerName = full || a.title;
    }

    if (song.lyricist) {
      const a = song.lyricist;
      const full =
        `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim();
      lyricistName = full || a.title;
    }

    // -----------------------------
    // Υπολογισμός basedOnSongId / basedOnSongTitle
    // -----------------------------
    let basedOnSongId: number | null = null;
    let basedOnSongTitle: string | null = null;

    if (song.basedOn) {
      const idNum = Number(song.basedOn);
      if (Number.isFinite(idNum) && idNum > 0) {
        const baseSong = await this.prisma.song.findUnique({
          where: { id: idNum },
          select: {
            id: true,
            title: true,
          },
        });

        if (baseSong) {
          basedOnSongId = baseSong.id;
          basedOnSongTitle = baseSong.title;
        }
      }
    }

    // -----------------------------
    // Υπολογισμός views (για DTO)
    // -----------------------------
    const views = noIncrement
      ? song.views ?? 0
      : (song.views ?? 0) + 1;

    // -----------------------------
    // Μετατροπή versions σε απλό DTO
    // (ΜΟΝΟ ερμηνευτές / μουσικοί, όχι συνθέτης/στιχουργός)
    // -----------------------------
    const versions =
      song.versions?.map((v) => {
        const frontArray = v.artists.filter(
          (a) => a.role === VersionArtistRole.SINGER_FRONT,
        );
        const backArray = v.artists.filter(
          (a) => a.role === VersionArtistRole.SINGER_BACK,
        );
        const soloArray = v.artists.filter(
          (a) => a.role === VersionArtistRole.SOLOIST,
        );

        const singerFront = frontArray
          .map((a) => a.artist?.title)
          .filter((t): t is string => !!t)
          .join(", ");

        const singerBack = backArray
          .map((a) => a.artist?.title)
          .filter((t): t is string => !!t)
          .join(", ");

        const solist = soloArray
          .map((a) => a.artist?.title)
          .filter((t): t is string => !!t)
          .join(", ");

        // Παίρνουμε το πρώτο σχετικό artistId για κάθε ρόλο
        const singerFrontId =
          frontArray.length > 0 ? frontArray[0].artistId ?? null : null;
        const singerBackId =
          backArray.length > 0 ? backArray[0].artistId ?? null : null;
        const solistId =
          soloArray.length > 0 ? soloArray[0].artistId ?? null : null;

        return {
          id: v.id,
          year: v.year,
          singerFront,
          singerBack,
          solist,
          youtubeSearch: v.youtubeSearch ?? null,
          singerFrontId,
          singerBackId,
          solistId,
        };
      }) ?? [];

    // -----------------------------
    // Τελικό DTO προς Next
    // -----------------------------
    return {
      id: song.id,
      title: song.title,
      firstLyrics: song.firstLyrics,
      lyrics: song.lyrics,
      characteristics: song.characteristics,
      originalKey: song.originalKey,
      chords: song.chords,
      status: song.status,
      scoreFile: song.scoreFile,
      categoryId: song.categoryId ?? null,
      rythmId: song.rythmId ?? null,
      makamId: song.makamId ?? null,

      categoryTitle,
      composerName,
      lyricistName,
      rythmTitle: song.rythm ? song.rythm.title : null,

      basedOnSongId,
      basedOnSongTitle,

      views,
      versions,
    };
  }

  /**
   * Ενημέρωση τραγουδιού.
   *
   * Δέχεται μόνο συγκεκριμένα πεδία για update και επιστρέφει
   * πάλι το SongDetail DTO όπως το findOne, χωρίς να αυξάνει τα views.
   */
  async updateSong(
    id: number,
    body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      basedOn?: string | null;
      scoreFile?: string | null;
      highestVocalNote?: string | null;
      chords?: string | null;
      status?: SongStatus;
      categoryId?: number | null;
      rythmId?: number | null;
      makamId?: number | null;
    },
  ) {
    // Βεβαιωνόμαστε ότι υπάρχει το τραγούδι ή ρίχνουμε 404.
    const existing = await this.prisma.song.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    const data: any = {};

    if (typeof body.title === "string") {
      data.title = body.title;
    }

    if (Object.prototype.hasOwnProperty.call(body, "firstLyrics")) {
      data.firstLyrics = body.firstLyrics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "lyrics")) {
      data.lyrics = body.lyrics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "characteristics")) {
      data.characteristics = body.characteristics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "originalKey")) {
      data.originalKey = body.originalKey;
    }

    if (Object.prototype.hasOwnProperty.call(body, "defaultKey")) {
      data.defaultKey = body.defaultKey;
    }

    if (Object.prototype.hasOwnProperty.call(body, "basedOn")) {
      data.basedOn = body.basedOn;
    }

    if (Object.prototype.hasOwnProperty.call(body, "scoreFile")) {
      data.scoreFile = body.scoreFile;
    }

    if (
      Object.prototype.hasOwnProperty.call(body, "highestVocalNote")
    ) {
      data.highestVocalNote = body.highestVocalNote;
    }

    if (Object.prototype.hasOwnProperty.call(body, "chords")) {
      data.chords = body.chords;
    }

    if (body.status) {
      if (Object.values(SongStatus).includes(body.status)) {
        data.status = body.status;
      }
    }

    if (Object.prototype.hasOwnProperty.call(body, "categoryId")) {
      data.categoryId = body.categoryId;
    }

    if (Object.prototype.hasOwnProperty.call(body, "rythmId")) {
      data.rythmId = body.rythmId;
    }

    if (Object.prototype.hasOwnProperty.call(body, "makamId")) {
      data.makamId = body.makamId;
    }

    if (Object.keys(data).length === 0) {
      return this.findOne(id, true);
    }

    await this.prisma.song.update({
      where: { id },
      data,
    });

    return this.findOne(id, true);
  }
}
