// apps/api/src/songs/elastic-songs.controller.ts
import {
  Controller,
  Get,
  HttpException,
  HttpStatus,
  Query,
} from "@nestjs/common";

@Controller("songs-es")
export class ElasticSongsController {
  private readonly ES_URL =
    process.env.ES_SONGS_URL ?? "http://localhost:9200/app_songs/_search";

  private parseNumber(
    value: string | undefined,
    def: number,
    min: number,
    max?: number,
  ): number {
    if (!value) return def;
    const n = Number(value);
    if (!Number.isFinite(n)) return def;
    let v = Math.max(min, n);
    if (typeof max === "number") {
      v = Math.min(v, max);
    }
    return v;
  }

  @Get("search")
  async searchSongs(
    @Query("q") q = "",
    @Query("skip") skipStr = "0",
    @Query("take") takeStr = "50",
    @Query("chords") chordsStr?: string,
    @Query("partiture") partitureStr?: string,
    @Query("category_id") categoryIdStr?: string,
    @Query("rythm_id") rythmIdStr?: string,
    @Query("characteristics") characteristics?: string,
    @Query("lyrics") lyricsStr?: string,
    @Query("status") status?: string,
    @Query("popular") popular?: string,
  ) {
    const skip = this.parseNumber(skipStr, 0, 0, 10_000);
    const take = this.parseNumber(takeStr, 50, 1, 200);

    // -------------------------------------------------
    // Μετατροπή boolean filters (chords, partiture)
    // -------------------------------------------------
    let chords: boolean | undefined;
    if (chordsStr === "1") chords = true;
    else if (chordsStr === "0") chords = false;

    let partiture: boolean | undefined;
    if (partitureStr === "1") partiture = true;
    else if (partitureStr === "0") partiture = false;

    const parseIdList = (value?: string): number[] | undefined => {
      if (!value) return undefined;
      const ids = value
        .split(",")
        .map((v) => v.trim())
        .filter(Boolean)
        .map((v) => Number(v))
        .filter((n) => Number.isFinite(n));
      return ids.length > 0 ? ids : undefined;
    };

    const categoryIds = parseIdList(categoryIdStr);
    const rythmIds = parseIdList(rythmIdStr);

    // -------------------------------------------------
    // Φίλτρα ES
    // -------------------------------------------------
    const filter: any[] = [];

    if (typeof chords === "boolean") {
      filter.push({ term: { chords } });
    }

    if (typeof partiture === "boolean") {
      filter.push({ term: { partiture } });
    }

    if (categoryIds && categoryIds.length > 0) {
      filter.push({
        terms: {
          category_id: categoryIds,
        },
      });
    }

    if (rythmIds && rythmIds.length > 0) {
      filter.push({
        terms: {
          rythm_id: rythmIds,
        },
      });
    }

    if (characteristics && characteristics.trim() !== "") {
      filter.push({
        match: {
          characteristics: {
            query: characteristics.trim(),
            operator: "and",
          },
        },
      });
    }

    if (lyricsStr === "null") {
      // Μόνο τραγούδια χωρίς στίχους
      filter.push({
        bool: {
          must_not: {
            exists: { field: "lyrics" },
          },
        },
      });
    }

    if (status && status.trim() !== "") {
      filter.push({
        term: {
          status: status.trim(),
        },
      });
    }

    // -------------------------------------------------
    // Κείμενο αναζήτησης (q)
    // -------------------------------------------------
    const must: any[] = [];
    const cleanedQ = (q ?? "").trim();

    if (cleanedQ !== "") {
      must.push({
        multi_match: {
          query: cleanedQ,
          fields: ["title^4", "firstLyrics^3", "lyrics^2", "characteristics"],
          type: "best_fields",
          operator: "and",
        },
      });
    }

    // -------------------------------------------------
    // Sort (δημοφιλή ή σκέτο score)
    // -------------------------------------------------
    const sort: any[] = [];

    if (popular === "1") {
      sort.push({ views: { order: "desc" } });
      sort.push({ _score: { order: "desc" } });
    } else {
      sort.push({ _score: { order: "desc" } });
    }

    // -------------------------------------------------
    // Aggregations για counts σε κατηγορίες / ρυθμούς
    // -------------------------------------------------
    const esBody = {
      from: skip,
      size: take,
      query: {
        bool: {
          must: must.length > 0 ? must : [{ match_all: {} }],
          filter,
        },
      },
      sort,
      _source: [
        "song_id",
        "title",
        "firstLyrics",
        "lyrics",
        "characteristics",
        "originalKey",
        "chords",
        "partiture",
        "status",
        "score",
        "views",
        "category_id",
        "categoryId",
        "rythm_id",
        "rythmId",
      ],
      aggs: {
        category_counts: {
          terms: {
            field: "category_id",
            size: 500,
          },
        },
        rythm_counts: {
          terms: {
            field: "rythm_id",
            size: 500,
          },
        },
      },
    };

    let res: Response;

    try {
      res = await fetch(this.ES_URL, {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify(esBody),
      });
    } catch (err: any) {
      console.error("[ElasticSongsController] fetch error", err);
      throw new HttpException(
        "Failed to reach Elasticsearch",
        HttpStatus.BAD_GATEWAY,
      );
    }

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error("[ElasticSongsController] ES response not ok", {
        status: res.status,
        body: text,
      });
      throw new HttpException(
        `Elasticsearch error (status ${res.status})`,
        HttpStatus.BAD_GATEWAY,
      );
    }

    try {
      const data: any = await res.json();
      const hits = Array.isArray(data?.hits?.hits)
        ? data.hits.hits
        : [];

      const totalValue =
        typeof data?.hits?.total === "object" &&
        data.hits.total !== null
          ? data.hits.total.value
          : typeof data?.hits?.total === "number"
          ? data.hits.total
          : 0;

      // -------------------------------------------------
      // Aggregation αποτελέσματα -> maps για frontend
      // -------------------------------------------------
      const categoryCountsById: Record<string, number> = {};
      const rythmCountsById: Record<string, number> = {};

      const catBuckets = data?.aggregations?.category_counts?.buckets;
      if (Array.isArray(catBuckets)) {
        for (const b of catBuckets) {
          const key = String(b.key);
          const docCount =
            typeof b.doc_count === "number" ? b.doc_count : 0;
          categoryCountsById[key] = docCount;
        }
      }

      const rythmBuckets = data?.aggregations?.rythm_counts?.buckets;
      if (Array.isArray(rythmBuckets)) {
        for (const b of rythmBuckets) {
          const key = String(b.key);
          const docCount =
            typeof b.doc_count === "number" ? b.doc_count : 0;
          rythmCountsById[key] = docCount;
        }
      }

      // -------------------------------------------------
      // Μετατροπή hits -> items για frontend
      // -------------------------------------------------
      const items = hits.map((hit: any) => {
        const src = hit._source || {};

        const rawScore = typeof hit._score === "number" ? hit._score : null;
        const safeScore =
          rawScore !== null && !Number.isNaN(rawScore)
            ? rawScore
            : typeof src.score === "number" && !Number.isNaN(src.score)
            ? src.score
            : 0;

        const categoryRaw =
          typeof src.category_id === "number"
            ? src.category_id
            : typeof src.categoryId === "number"
            ? src.categoryId
            : null;

        const rythmRaw =
          typeof src.rythm_id === "number"
            ? src.rythm_id
            : typeof src.rythmId === "number"
            ? src.rythmId
            : null;

        return {
          song_id: src.song_id,
          title: src.title,
          firstLyrics: src.firstLyrics,
          lyrics: src.lyrics,
          characteristics: src.characteristics,
          originalKey: src.originalKey,
          chords: src.chords,
          partiture: src.partiture,
          status: src.status,
          score: safeScore,
          views: src.views,
          category_id: categoryRaw,
          categoryId: categoryRaw,
          rythm_id: rythmRaw,
          rythmId: rythmRaw,
        };
      });

      console.log("[ElasticSongsController] ES response", {
        total: totalValue,
        itemsCount: items.length,
        categoryAggsCount: Object.keys(categoryCountsById).length,
        rythmAggsCount: Object.keys(rythmCountsById).length,
      });

      return {
        items,
        total: totalValue,
        skip,
        take,
        categoryCountsById,
        rythmCountsById,
      };
    } catch (err: any) {
      console.error("[ElasticSongsController] unexpected error", err);

      if (err instanceof HttpException) {
        throw err;
      }

      throw new HttpException(
        "Unexpected error while searching songs in Elasticsearch",
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
