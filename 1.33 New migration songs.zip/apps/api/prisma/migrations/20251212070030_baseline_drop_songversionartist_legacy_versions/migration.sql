-- Baseline migration to reconcile drift without reset.
-- Safe to run even if parts already applied.

BEGIN;

-- 1) Drop the table that was manually removed (idempotent).
DROP TABLE IF EXISTS "SongVersionArtist" CASCADE;

-- 2) Ensure Song has composerId/lyricistId columns and FKs (idempotent where possible).
ALTER TABLE "Song"
  ADD COLUMN IF NOT EXISTS "composerId" INTEGER,
  ADD COLUMN IF NOT EXISTS "lyricistId" INTEGER;

-- Add FKs only if missing (PostgreSQL doesn't support IF NOT EXISTS for ADD CONSTRAINT).
-- So we guard by checking catalog in DO blocks.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'Song_composerId_fkey'
  ) THEN
    ALTER TABLE "Song"
      ADD CONSTRAINT "Song_composerId_fkey"
      FOREIGN KEY ("composerId") REFERENCES "Artist"(id)
      ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'Song_lyricistId_fkey'
  ) THEN
    ALTER TABLE "Song"
      ADD CONSTRAINT "Song_lyricistId_fkey"
      FOREIGN KEY ("lyricistId") REFERENCES "Artist"(id)
      ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

-- 3) Ensure legacy columns exist on Song (for correct legacy mapping)
ALTER TABLE "Song"
  ADD COLUMN IF NOT EXISTS "legacySongId" INTEGER,
  ADD COLUMN IF NOT EXISTS "legacySongIdOld" INTEGER;

-- Unique indexes (guarded)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='Song_legacySongId_key'
  ) THEN
    CREATE UNIQUE INDEX "Song_legacySongId_key" ON "Song"("legacySongId");
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='Song_legacySongIdOld_key'
  ) THEN
    CREATE UNIQUE INDEX "Song_legacySongIdOld_key" ON "Song"("legacySongIdOld");
  END IF;
END $$;

-- 4) Ensure SongVersion follows legacy (text fields inside SongVersion)
ALTER TABLE "SongVersion"
  ADD COLUMN IF NOT EXISTS "singerFront"   TEXT,
  ADD COLUMN IF NOT EXISTS "singerBack"    TEXT,
  ADD COLUMN IF NOT EXISTS "solist"        TEXT,
  ADD COLUMN IF NOT EXISTS "musicians"     TEXT;

ALTER TABLE "SongVersion"
  ADD COLUMN IF NOT EXISTS "legacyVersionId" INTEGER,
  ADD COLUMN IF NOT EXISTS "legacySongIdOld" INTEGER;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='SongVersion_legacyVersionId_key'
  ) THEN
    CREATE UNIQUE INDEX "SongVersion_legacyVersionId_key" ON "SongVersion"("legacyVersionId");
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='SongVersion_songId_idx'
  ) THEN
    CREATE INDEX "SongVersion_songId_idx" ON "SongVersion"("songId");
  END IF;
END $$;

COMMIT;
