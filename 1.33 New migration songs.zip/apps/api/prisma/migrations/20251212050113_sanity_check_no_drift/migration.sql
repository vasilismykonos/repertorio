/*
  SAFE migration: do NOT drop columns with data, do NOT change Makam schema now,
  do NOT add risky UNIQUE constraints now.

  This migration is intentionally minimal to avoid data loss.
*/

BEGIN;

-- Keep Makam as-is (do not drop "name", do not require new NOT NULL "title" now).
-- Keep SongVersion legacy columns (do not drop any legacy* columns now).
-- Do not drop enums/types that may still exist in DB history.

-- Optional: align Rythm.updatedAt default (safe)
ALTER TABLE "Rythm"
  ALTER COLUMN "updatedAt" SET DEFAULT CURRENT_TIMESTAMP;

-- Optional: indexes that are safe and help performance (only if missing)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='ListItem_listId_idx'
  ) THEN
    CREATE INDEX "ListItem_listId_idx" ON "ListItem"("listId");
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname='public' AND indexname='ListItem_songId_idx'
  ) THEN
    CREATE INDEX "ListItem_songId_idx" ON "ListItem"("songId");
  END IF;
END $$;

COMMIT;
