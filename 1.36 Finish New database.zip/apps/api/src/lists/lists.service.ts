import { Injectable, NotFoundException, ForbiddenException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

export type ListSummaryDto = {
  id: number;
  title: string;
  groupId: number | null;
  marked: boolean;
  role: "OWNER" | "EDITOR" | "VIEWER";
};

export type ListGroupSummaryDto = {
  id: number;
  title: string;
  fullTitle: string | null;
  listsCount: number;
};

export type ListsIndexResponse = {
  items: ListSummaryDto[];
  total: number;
  page: number;
  pageSize: number;
  groups: ListGroupSummaryDto[];
};

export type ListItemDto = {
  listItemId: number;
  listId: number;
  sortId: number;

  songId: number | null;

  transport: number;
  notes: string | null;

  title: string;
  chords: string | null;
  chordsSource: "LIST" | "SONG" | "NONE";

  lyrics: string | null;
  lyricsSource: "LIST" | "SONG" | "NONE";
};

export type ListDetailDto = {
  id: number;
  title: string;

  groupId: number | null;
  groupTitle: string | null;

  marked: boolean;

  role: "OWNER" | "EDITOR" | "VIEWER";

  items: ListItemDto[];
};

@Injectable()
export class ListsService {
  constructor(private readonly prisma: PrismaService) {}

  private async getUserContext(userId: number): Promise<{ isAdmin: boolean }> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, role: true },
    });

    if (!user) throw new NotFoundException(`User ${userId} not found`);

    return { isAdmin: user.role === "ADMIN" };
  }

  private normalizePage(page?: number) {
    return page && page > 0 ? page : 1;
  }

  private normalizePageSize(pageSize?: number) {
    return pageSize && pageSize > 0 && pageSize <= 100 ? pageSize : 20;
  }

  private trimOrNull(val?: string | null): string | null {
    if (!val) return null;
    const t = val.trim();
    return t.length ? t : null;
  }

  private computeRoleFromMembership(m: { role: string }[] | null | undefined): "OWNER" | "EDITOR" | "VIEWER" {
    // Αν επιστρέψει πολλαπλά (δεν πρέπει λόγω @@unique), παίρνουμε το ισχυρότερο.
    const roles = (m ?? []).map((x) => x.role);
    if (roles.includes("OWNER")) return "OWNER";
    if (roles.includes("EDITOR")) return "EDITOR";
    return "VIEWER";
  }

  async getListsIndex(params: {
    userId: number;
    search?: string;
    group?: string;
    groupId?: number;
    page?: number;
    pageSize?: number;
  }): Promise<ListsIndexResponse> {
    const { userId, search, group, groupId } = params;

    const pageN = this.normalizePage(params.page);
    const pageSizeN = this.normalizePageSize(params.pageSize);

    const { isAdmin } = await this.getUserContext(userId);

    const filters: any = {};

    if (search && search.trim().length > 0) {
      filters.title = { contains: search.trim(), mode: "insensitive" };
    }

    let rawGroup: string | undefined;
    if (group != null && group !== "") rawGroup = group;
    else if (typeof groupId === "number") rawGroup = String(groupId);

    if (rawGroup === "null") filters.groupId = null;
    else if (rawGroup && rawGroup.trim().length > 0) {
      const gid = Number(rawGroup);
      if (!Number.isNaN(gid)) filters.groupId = gid;
    }

    const aclWhere = isAdmin ? {} : { members: { some: { userId } } };
    const where = Object.keys(filters).length ? { AND: [aclWhere, filters] } : aclWhere;

    const [total, listRows, groupRows] = await Promise.all([
      this.prisma.list.count({ where }),

      this.prisma.list.findMany({
        where,
        orderBy: [{ marked: "desc" }, { title: "asc" }, { id: "asc" }],
        skip: (pageN - 1) * pageSizeN,
        take: pageSizeN,
        select: {
          id: true,
          title: true,
          groupId: true,
          marked: true,
          members: isAdmin
            ? false
            : {
                where: { userId },
                select: { role: true },
              },
        },
      }),

      this.prisma.listGroup.findMany({
        orderBy: [{ title: "asc" }, { id: "asc" }],
        include: {
          lists: {
            where: isAdmin ? undefined : { members: { some: { userId } } },
            select: { id: true },
          },
        },
      }),
    ]);

    const items: ListSummaryDto[] = listRows.map((row: any) => ({
      id: row.id,
      title: row.title,
      groupId: row.groupId,
      marked: row.marked,
      role: isAdmin ? "OWNER" : this.computeRoleFromMembership(row.members),
    }));

    const groups: ListGroupSummaryDto[] = groupRows.map((g) => ({
      id: g.id,
      title: g.title,
      fullTitle: g.fullTitle ?? null,
      listsCount: g.lists.length,
    }));

    return { items, total, page: pageN, pageSize: pageSizeN, groups };
  }

  async getListDetail(params: { listId: number; userId: number }): Promise<ListDetailDto> {
    const { listId, userId } = params;
    const { isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      include: {
        group: true,
        members: isAdmin ? false : { where: { userId }, select: { role: true } },
        items: {
          orderBy: [{ sortId: "asc" }, { id: "asc" }],
          include: { song: true },
        },
      },
    });

    if (!list) throw new NotFoundException("List not found");

    const membershipRole = isAdmin ? "OWNER" : this.computeRoleFromMembership((list as any).members);
    if (!isAdmin && !(list as any).members?.length) {
      // UX: 404 όπως παλιά
      throw new NotFoundException("Η λίστα δεν βρέθηκε ή δεν έχετε δικαίωμα να τη δείτε.");
    }

    const canEdit = isAdmin || membershipRole === "OWNER" || membershipRole === "EDITOR";

    const items: ListItemDto[] = list.items.map((item) => {
      const listChords = this.trimOrNull(item.chords);
      const songChords = this.trimOrNull(item.song?.chords ?? null);

      let chordsSource: "LIST" | "SONG" | "NONE" = "NONE";
      let chords: string | null = null;

      if (listChords) {
        chordsSource = "LIST";
        chords = listChords;
      } else if (songChords) {
        chordsSource = "SONG";
        chords = songChords;
      }

      const listLyrics = this.trimOrNull(item.lyrics);
      const songLyrics = this.trimOrNull(item.song?.lyrics ?? null);

      let lyricsSource: "LIST" | "SONG" | "NONE" = "NONE";
      let lyrics: string | null = null;

      if (listLyrics) {
        lyricsSource = "LIST";
        lyrics = listLyrics;
      } else if (songLyrics) {
        lyricsSource = "SONG";
        lyrics = songLyrics;
      }

      return {
        listItemId: item.id,
        listId: item.listId,
        sortId: item.sortId,

        songId: item.songId ?? null,

        transport: item.transport ?? 0,
        notes: item.notes ?? null,

        title: item.title,
        chords,
        chordsSource,
        lyrics,
        lyricsSource,
      };
    });

    return {
      id: list.id,
      title: list.title,

      groupId: list.groupId,
      groupTitle: list.group ? list.group.title : null,

      marked: list.marked,

      role: membershipRole,

      items,
    };
  }

  async getListItems(params: {
    userId: number;
    listId: number;
    page?: number;
    pageSize?: number;
  }): Promise<{ items: ListItemDto[]; total: number; page: number; pageSize: number }> {
    const { userId, listId } = params;

    const pageN = this.normalizePage(params.page);
    const pageSizeN = params.pageSize && params.pageSize > 0 && params.pageSize <= 200 ? params.pageSize : 200;

    const { isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      include: {
        members: isAdmin ? false : { where: { userId }, select: { role: true } },
        items: {
          orderBy: [{ sortId: "asc" }, { id: "asc" }],
          include: { song: true },
        },
      },
    });

    if (!list) throw new NotFoundException("List not found");

    if (!isAdmin && !(list as any).members?.length) {
      throw new ForbiddenException("Δεν έχετε πρόσβαση σε αυτή τη λίστα.");
    }

    const total = list.items.length;
    const start = (pageN - 1) * pageSizeN;
    const slice = list.items.slice(start, start + pageSizeN);

    const items: ListItemDto[] = slice.map((item) => {
      const listChords = this.trimOrNull(item.chords);
      const songChords = this.trimOrNull(item.song?.chords ?? null);

      let chordsSource: "LIST" | "SONG" | "NONE" = "NONE";
      let chords: string | null = null;

      if (listChords) {
        chordsSource = "LIST";
        chords = listChords;
      } else if (songChords) {
        chordsSource = "SONG";
        chords = songChords;
      }

      const listLyrics = this.trimOrNull(item.lyrics);
      const songLyrics = this.trimOrNull(item.song?.lyrics ?? null);

      let lyricsSource: "LIST" | "SONG" | "NONE" = "NONE";
      let lyrics: string | null = null;

      if (listLyrics) {
        lyricsSource = "LIST";
        lyrics = listLyrics;
      } else if (songLyrics) {
        lyricsSource = "SONG";
        lyrics = songLyrics;
      }

      return {
        listItemId: item.id,
        listId: item.listId,
        sortId: item.sortId,

        songId: item.songId ?? null,

        transport: item.transport ?? 0,
        notes: item.notes ?? null,

        title: item.title,
        chords,
        chordsSource,
        lyrics,
        lyricsSource,
      };
    });

    return { items, total, page: pageN, pageSize: pageSizeN };
  }
}
