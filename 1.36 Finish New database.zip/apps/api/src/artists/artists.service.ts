// apps/api/src/artists/artists.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma } from "@prisma/client";

// strings (όχι Prisma enum, γιατί στο δικό σου client δεν εξάγεται)
type VersionArtistRoleString =
  | "SINGER_FRONT"
  | "SINGER_BACK"
  | "SOLOIST"
  | "MUSICIAN"
  | "COMPOSER"
  | "LYRICIST";

type ArtistSearchParams = {
  q?: string;
  skip: number;
  take: number;
  roles: VersionArtistRoleString[];
};

type UpdateArtistData = {
  title?: string;
  firstName?: string | null;
  lastName?: string | null;
  sex?: string | null;
  bornYear?: number | null;
  dieYear?: number | null;
  imageUrl?: string | null;
  biography?: string | null;
  wikiUrl?: string | null;
};

type ArtistSearchItem = {
  id: number;
  title: string;
  firstName: string | null;
  lastName: string | null;
  imageUrl: string | null;
  bornYear: number | null;
  dieYear: number | null;
};

type ArtistSearchResponse = {
  total: number;
  items: ArtistSearchItem[];
};

@Injectable()
export class ArtistsService {
  constructor(private readonly prisma: PrismaService) {}

  async search(params: ArtistSearchParams): Promise<ArtistSearchResponse> {
    const { q, skip, take, roles } = params;

    // ΠΑΝΤΑ array (ποτέ undefined) για να μην έχουμε TS18048
    let roleArtistIds: number[] = [];

    if (roles && roles.length > 0) {
      const rows = await (this.prisma as any).songVersionArtist.findMany({
        where: {
          role: { in: roles as any },
        },
        select: { artistId: true },
        distinct: ["artistId"],
      });

      roleArtistIds = (rows ?? [])
        .map((r: any) => Number(r.artistId))
        .filter((n: number) => Number.isFinite(n) && n > 0);

      // Αν ζητήθηκαν roles αλλά δεν βρέθηκαν καλλιτέχνες, επιστρέφουμε άμεσα κενό
      if (roleArtistIds.length === 0) {
        return { total: 0, items: [] };
      }
    }

    const where: Prisma.ArtistWhereInput = {};

    if (q && q.trim() !== "") {
      const term = q.trim();
      where.OR = [
        { title: { contains: term, mode: "insensitive" } },
        { firstName: { contains: term, mode: "insensitive" } },
        { lastName: { contains: term, mode: "insensitive" } },
      ];
    }

    if (roleArtistIds.length > 0) {
      where.id = { in: roleArtistIds };
    }

    const [items, total] = await Promise.all([
      this.prisma.artist.findMany({
        where,
        skip,
        take,
        orderBy: { title: "asc" },
        select: {
          id: true,
          title: true,
          firstName: true,
          lastName: true,
          imageUrl: true,
          bornYear: true,
          dieYear: true,
        },
      }),
      this.prisma.artist.count({ where }),
    ]);

    return { total, items };
  }

  async findOne(id: number): Promise<any> {
    const artist = await this.prisma.artist.findUnique({
      where: { id },
    });

    if (!artist) {
      throw new NotFoundException(`Artist with id=${id} not found`);
    }

    const svaRows = await (this.prisma as any).songVersionArtist.findMany({
      where: { artistId: id },
      include: {
        version: {
          include: {
            song: true,
          },
        },
      },
    });

    const discography = (svaRows ?? [])
      .filter((r: any) => r?.version?.song)
      .map((r: any) => ({
        versionId: r.versionId,
        year: r.version?.year ?? null,
        role: r.role,
        songId: r.version.song.id,
        songTitle: r.version.song.title,
      }))
      .sort((a: any, b: any) => {
        const ay = a.year ?? -1;
        const by = b.year ?? -1;
        if (ay !== by) return by - ay;
        return (b.songId ?? 0) - (a.songId ?? 0);
      });

    const [composerSongs, lyricistSongs] = await Promise.all([
      this.prisma.song.findMany({
        where: { composerId: id },
        select: { id: true, title: true },
        orderBy: { id: "desc" },
      }),
      this.prisma.song.findMany({
        where: { lyricistId: id },
        select: { id: true, title: true },
        orderBy: { id: "desc" },
      }),
    ]);

    return {
      id: artist.id,
      title: artist.title,
      firstName: artist.firstName,
      lastName: artist.lastName,
      sex: artist.sex,
      bornYear: artist.bornYear,
      dieYear: artist.dieYear,
      imageUrl: artist.imageUrl,
      biography: artist.biography,
      wikiUrl: artist.wikiUrl,
      composerSongs,
      lyricistSongs,
      discography,
    };
  }

  async updateArtist(id: number, payload: UpdateArtistData): Promise<any> {
    const exists = await this.prisma.artist.findUnique({
      where: { id },
      select: { id: true },
    });
    if (!exists) {
      throw new NotFoundException(`Artist with id=${id} not found`);
    }

    const data: Prisma.ArtistUpdateInput = {};

    if (payload.title !== undefined) data.title = payload.title;
    if (payload.firstName !== undefined) data.firstName = payload.firstName;
    if (payload.lastName !== undefined) data.lastName = payload.lastName;
    if (payload.sex !== undefined) data.sex = payload.sex;
    if (payload.bornYear !== undefined) data.bornYear = payload.bornYear;
    if (payload.dieYear !== undefined) data.dieYear = payload.dieYear;
    if (payload.imageUrl !== undefined) data.imageUrl = payload.imageUrl;
    if (payload.biography !== undefined) data.biography = payload.biography;
    if (payload.wikiUrl !== undefined) data.wikiUrl = payload.wikiUrl;

    await this.prisma.artist.update({
      where: { id },
      data,
    });

    return this.findOne(id);
  }
}
