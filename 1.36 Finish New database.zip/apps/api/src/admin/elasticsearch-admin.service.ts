// apps/api/src/admin/elasticsearch-admin.service.ts
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

type ReindexState = {
  running: boolean;
  startedAt: string | null;
  finishedAt: string | null;

  total: number;
  processed: number;
  indexed: number;
  errors: number;

  lastId: number | null;
  message: string | null;
};

@Injectable()
export class ElasticsearchAdminService {
  private readonly indexName = process.env.ES_SONGS_INDEX ?? "app_songs";
  private readonly esBase = process.env.ES_BASE_URL ?? "http://localhost:9200";
  private readonly batchSize = Number(process.env.ES_REINDEX_BATCH_SIZE ?? "500");

  private state: ReindexState = {
    running: false,
    startedAt: null,
    finishedAt: null,
    total: 0,
    processed: 0,
    indexed: 0,
    errors: 0,
    lastId: null,
    message: null,
  };

  constructor(private readonly prisma: PrismaService) {}

  getStatus() {
    return this.state;
  }

  private nowIso() {
    return new Date().toISOString();
  }

  private async esFetch(path: string, init?: RequestInit) {
    const url = `${this.esBase}${path}`;
    const res = await fetch(url, init);
    const text = await res.text();

    if (!res.ok) {
      throw new Error(`ES ${res.status} ${res.statusText} – ${url} – body: ${text}`);
    }

    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }

  private async ensureIndexExists() {
    const head = await fetch(`${this.esBase}/${this.indexName}`, { method: "HEAD" });
    if (head.ok) return;

    await this.esFetch(`/${this.indexName}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        settings: { number_of_shards: 1, number_of_replicas: 0 },
        mappings: {
          properties: {
            id: { type: "integer" },
            legacySongId: { type: "integer" },
            title: { type: "text" },
            firstLyrics: { type: "text" },
            lyrics: { type: "text" },
            characteristics: { type: "text" },
            categoryId: { type: "integer" },
            rythmId: { type: "integer" },
            views: { type: "integer" },
            scoreFile: { type: "keyword" },
            status: { type: "keyword" },
          },
        },
      }),
    });
  }

  private async clearIndex() {
    await this.esFetch(
      `/${this.indexName}/_delete_by_query?refresh=true&conflicts=proceed`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query: { match_all: {} } }),
      },
    );
  }

  async preview(take = 20) {
    const json = await this.esFetch(`/${this.indexName}/_search`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        size: Math.min(Math.max(take, 1), 200),
        sort: [{ id: { order: "asc" } }],
        _source: [
          "id",
          "legacySongId",
          "title",
          "firstLyrics",
          "categoryId",
          "rythmId",
          "views",
          "status",
          "scoreFile",
        ],
        query: { match_all: {} },
      }),
    });

    const hits = json?.hits?.hits ?? [];
    const total = json?.hits?.total?.value ?? 0;
    const items = hits.map((h: any) => h?._source ?? {});

    return { total, items };
  }

  async startReindex() {
    if (this.state.running) {
      return { ok: false, message: "Reindex is already running", status: this.state };
    }

    this.state = {
      running: true,
      startedAt: this.nowIso(),
      finishedAt: null,
      total: 0,
      processed: 0,
      indexed: 0,
      errors: 0,
      lastId: null,
      message: "Starting reindex...",
    };

    void this.runReindex().catch((e) => {
      this.state.running = false;
      this.state.finishedAt = this.nowIso();
      this.state.message = `FAILED: ${e?.message ?? String(e)}`;
    });

    return { ok: true, message: "Reindex started", status: this.state };
  }

  private async runReindex() {
    await this.ensureIndexExists();

    this.state.message = "Clearing index...";
    await this.clearIndex();

    this.state.message = "Counting songs in Postgres...";
    this.state.total = await this.prisma.song.count();

    this.state.message = "Indexing...";
    let lastId = 0;

    while (true) {
      const rows = await this.prisma.song.findMany({
        where: { id: { gt: lastId } },
        orderBy: { id: "asc" },
        take: this.batchSize,
        select: {
          id: true,
          legacySongId: true,
          title: true,
          firstLyrics: true,
          lyrics: true,
          characteristics: true,
          categoryId: true,
          rythmId: true,
          views: true,
          scoreFile: true,
          status: true,
        },
      });

      if (!rows.length) break;

      const ndjsonLines: string[] = [];
      for (const s of rows) {
        // ✅ IMPORTANT: document _id = Postgres id
        ndjsonLines.push(JSON.stringify({ index: { _index: this.indexName, _id: String(s.id) } }));
        ndjsonLines.push(
          JSON.stringify({
            id: s.id,
            legacySongId: s.legacySongId ?? null,
            title: s.title ?? null,
            firstLyrics: s.firstLyrics ?? null,
            lyrics: s.lyrics ?? null,
            characteristics: s.characteristics ?? "",
            categoryId: s.categoryId ?? null,
            rythmId: s.rythmId ?? null,
            views: typeof s.views === "number" ? s.views : 0,
            scoreFile: s.scoreFile ?? null,
            status: (s.status as any) ?? null,
          }),
        );
      }

      const bulkBody = ndjsonLines.join("\n") + "\n";

      const bulkRes = await this.esFetch(`/_bulk?refresh=false`, {
        method: "POST",
        headers: { "content-type": "application/x-ndjson" },
        body: bulkBody,
      });

      const items = bulkRes?.items ?? [];
      let batchErrors = 0;

      for (const it of items) {
        const obj = it?.index ?? it?.create ?? it?.update ?? it?.delete;
        if (obj?.error) batchErrors++;
      }

      this.state.processed += rows.length;
      this.state.indexed += Math.max(0, rows.length - batchErrors);
      this.state.errors += batchErrors;

      lastId = rows[rows.length - 1].id;
      this.state.lastId = lastId;
      this.state.message = `Indexing... lastId=${lastId}`;

      await new Promise((r) => setTimeout(r, 10));
    }

    this.state.message = "Refreshing index...";
    await this.esFetch(`/${this.indexName}/_refresh`, { method: "POST" });

    this.state.running = false;
    this.state.finishedAt = this.nowIso();
    this.state.message = "DONE";
  }
}
