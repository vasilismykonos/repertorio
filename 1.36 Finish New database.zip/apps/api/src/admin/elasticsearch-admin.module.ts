//elasticsearch-admin.module.ts
import { Module } from "@nestjs/common";
import { ElasticsearchAdminController } from "./elasticsearch-admin.controller";
import { ElasticsearchAdminService } from "./elasticsearch-admin.service";
import { PrismaService } from "../prisma/prisma.service";

@Module({
  controllers: [ElasticsearchAdminController],
  providers: [ElasticsearchAdminService, PrismaService],
})
export class ElasticsearchAdminModule {}
