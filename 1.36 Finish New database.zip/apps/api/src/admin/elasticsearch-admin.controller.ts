// apps/api/src/admin/elasticsearch-admin.controller.ts
import { Controller, Get, Post, Query } from "@nestjs/common";
import { ElasticsearchAdminService } from "./elasticsearch-admin.service";

@Controller("admin/es")
export class ElasticsearchAdminController {
  constructor(private readonly esAdmin: ElasticsearchAdminService) {}

  @Get("status")
  status() {
    return this.esAdmin.getStatus();
  }

  @Get("preview")
  async preview(@Query("take") takeStr?: string) {
    const take = Number(takeStr ?? "25");
    return await this.esAdmin.preview(Number.isFinite(take) ? take : 25);
  }

  @Post("reindex")
  async reindex() {
    // fire-and-forget start, επιστρέφει αμέσως ok + status
    return await this.esAdmin.startReindex();
  }
}
