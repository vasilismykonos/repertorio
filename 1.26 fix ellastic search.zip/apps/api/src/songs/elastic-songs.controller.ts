// apps/api/src/songs/elastic-songs.controller.ts
import {
  Controller,
  Get,
  HttpException,
  HttpStatus,
  Query,
} from "@nestjs/common";

/**
 * Αναζήτηση τραγουδιών στο Elasticsearch index "app_songs".
 *
 * Τελικό API (με global prefix /api/v1):
 *   GET /api/v1/songs-es/search
 *
 * Query params:
 *   q               : string (full-text σε title / firstLyrics / lyrics)
 *   skip            : number (offset, default 0)
 *   take            : number (limit, default 50)
 *   chords          : "1" | "0"  (φιλτράρισμα σε πεδίο chords)
 *   partiture       : "1" | "0"  (φιλτράρισμα σε πεδίο partiture)
 *   category_id     : string     (αντιστοίχιση σε πεδίο category_id, αν το έχεις περάσει στο ES)
 *   rythm_id        : string     (αντιστοίχιση σε πεδίο rythm_id, αν το έχεις περάσει στο ES)
 *   characteristics : string     (π.χ. "Οργανικό")
 *   lyrics          : "1" | "0"  (αν θες μόνο όσα έχουν lyrics – προαιρετικό)
 *   status          : string     (π.χ. "PUBLISHED")
 *   createdByUserId : string     (αν έχεις αυτό το πεδίο στο ES)
 *   popular         : "1" | "0"  (όταν είναι 1 -> sort κατά views desc, αλλιώς score)
 */
@Controller("songs-es")
export class ElasticSongsController {
  @Get("search")
  async searchSongs(
    @Query("q") q = "",
    @Query("skip") skipStr = "0",
    @Query("take") takeStr = "50",
    @Query("chords") chordsStr?: string,
    @Query("partiture") partitureStr?: string,
    @Query("category_id") categoryId?: string,
    @Query("rythm_id") rythmId?: string,
    @Query("characteristics") characteristics?: string,
    @Query("lyrics") lyricsStr?: string,
    @Query("status") status?: string,
    @Query("createdByUserId") createdByUserId?: string,
    @Query("popular") popularStr?: string,
  ) {
    // ---------------- Βασικά params ----------------
    const skipNum = Number(skipStr);
    const takeNum = Number(takeStr);

    const skip = Number.isNaN(skipNum) || skipNum < 0 ? 0 : skipNum;
    const take =
      Number.isNaN(takeNum) || takeNum <= 0 || takeNum > 200 ? 50 : takeNum;

    const hasQuery = q.trim().length > 0;

    const chords =
      chordsStr === "1" || chordsStr === "true"
        ? true
        : chordsStr === "0" || chordsStr === "false"
        ? false
        : undefined;

    const partiture =
      partitureStr === "1" || partitureStr === "true"
        ? true
        : partitureStr === "0" || partitureStr === "false"
        ? false
        : undefined;

    const popular =
      popularStr === "1" || popularStr === "true"
        ? true
        : popularStr === "0" || popularStr === "false"
        ? false
        : false;

    // ---------------- Φίλτρα ----------------
    const filter: any[] = [];

    if (typeof chords === "boolean") {
      filter.push({ term: { chords } });
    }

    if (typeof partiture === "boolean") {
      filter.push({ term: { partiture } });
    }

    if (categoryId && categoryId !== "0") {
      filter.push({
        term: {
          category_id: categoryId,
        },
      });
    }

    if (rythmId && rythmId !== "0") {
      filter.push({
        term: {
          rythm_id: rythmId,
        },
      });
    }

    if (characteristics && characteristics.trim() !== "") {
      filter.push({
        match_phrase: {
          characteristics,
        },
      });
    }

    if (lyricsStr === "1" || lyricsStr === "true") {
      filter.push({
        exists: { field: "lyrics" },
      });
    }

    if (status && status.trim() !== "") {
      filter.push({
        term: { status },
      });
    }

    if (createdByUserId && createdByUserId.trim() !== "") {
      filter.push({
        term: { createdByUserId },
      });
    }

    // ---------------- Κείμενο (βάρη + phrase + prefix + fuzziness) ----------------
    let baseQuery: any;

    if (hasQuery) {
      const textShould: any[] = [];

      // 1) Πολύ ισχυρό: φράση με prefix στην τελευταία λέξη (τίτλος με autocomplete)
      //    Παίζει μεγάλο ρόλο όταν γράφεις "οτι κι αν π" και ο τίτλος είναι "ό,τι κι αν πω"
      textShould.push({
        match_phrase_prefix: {
          "title.autocomplete": {
            query: q,
            boost: 8, // ισχυρό weight στον τίτλο (3) + φράση + prefix
          },
        },
      });

      // 2) Φράση με prefix στον τίτλο (κανονικό text field)
      textShould.push({
        match_phrase_prefix: {
          title: {
            query: q,
            boost: 6,
          },
        },
      });

      // 3) Φράση με prefix στους πρώτους στίχους
      textShould.push({
        match_phrase_prefix: {
          firstLyrics: {
            query: q,
            boost: 6,
          },
        },
      });

      // 4) Φράση με prefix στα πλήρη lyrics
      textShould.push({
        match_phrase_prefix: {
          lyrics: {
            query: q,
            boost: 4,
          },
        },
      });

      // 5) Fuzzy multi_match (ανεκτικότητα σε ορθογραφικά, ίδια σειρά, όλες οι λέξεις)
      textShould.push({
        multi_match: {
          query: q,
          type: "best_fields",
          fields: ["title^3", "firstLyrics^3", "lyrics^2"],
          operator: "and", // όλες οι λέξεις
          fuzziness: "AUTO", // ανοχή σε ορθογραφικά
        },
      });

      baseQuery = {
        bool: {
          must: [
            {
              bool: {
                should: textShould,
                minimum_should_match: 1,
              },
            },
          ],
          filter,
        },
      };
    } else {
      // Χωρίς q: όπως πριν – φέρνουμε όλα και αφήνουμε το sort να δουλέψει
      baseQuery = {
        bool: {
          must: [{ match_all: {} }],
          filter,
        },
      };
    }

    // ---------------- Βαθμολογία views (field_value_factor) ----------------
    // Δίνουμε ένα "βάρος 1" στα views, προσθετικά πάνω στο text score,
    // ώστε να μετράνε χωρίς να καταστρέφουν τη σχετικότητα.
    const scoredQuery: any = {
      function_score: {
        query: baseQuery,
        score_mode: "sum",
        boost_mode: "sum",
        functions: [
          {
            field_value_factor: {
              field: "views",
              factor: 0.01, // ρυθμίζει πόσο δυνατά επηρεάζουν τα views
              modifier: "log1p",
              missing: 0,
            },
            weight: 1,
          },
        ],
      },
    };

    // ---------------- Sort ----------------
    const sort = popular
      ? [
          { views: { order: "desc" } },
          { song_id: { order: "asc" } },
        ]
      : hasQuery
      ? [
          { _score: { order: "desc" } },
          { views: { order: "desc" } },
        ]
      : [
          { views: { order: "desc" } },
          { song_id: { order: "asc" } },
        ];

    const esBody: any = {
      from: skip,
      size: take,
      query: scoredQuery,
      sort,
    };

    try {
      console.log("[ElasticSongsController] ES request", {
        q,
        skip,
        take,
        popular,
        hasQuery,
      });

      const esUrl = "http://localhost:9200/app_songs/_search";

      const res = await fetch(esUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(esBody),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error(
          "[ElasticSongsController] ES HTTP error",
          res.status,
          text,
        );
        throw new HttpException(
          `Elasticsearch error: ${res.status}`,
          HttpStatus.BAD_GATEWAY,
        );
      }

      const data: any = await res.json();

      const hits = Array.isArray(data?.hits?.hits) ? data.hits.hits : [];

      const totalValue =
        typeof data?.hits?.total === "object" && data.hits.total !== null
          ? data.hits.total.value
          : typeof data?.hits?.total === "number"
          ? data.hits.total
          : 0;

      const items = hits.map((hit: any) => {
        const src = hit._source || {};

        const rawScore = typeof hit._score === "number" ? hit._score : null;
        const safeScore =
          rawScore !== null && !Number.isNaN(rawScore)
            ? rawScore
            : typeof src.score === "number" && !Number.isNaN(src.score)
            ? src.score
            : 0;

        return {
          song_id: src.song_id,
          title: src.title,
          firstLyrics: src.firstLyrics,
          lyrics: src.lyrics,
          characteristics: src.characteristics,
          originalKey: src.originalKey,
          chords: src.chords,
          partiture: src.partiture,
          status: src.status,
          score: safeScore,
          views: src.views,
        };
      });

      console.log("[ElasticSongsController] ES response", {
        total: totalValue,
        itemsCount: items.length,
      });

      return {
        items,
        total: totalValue,
        skip,
        take,
      };
    } catch (err: any) {
      console.error("[ElasticSongsController] unexpected error", err);

      if (err instanceof HttpException) {
        throw err;
      }

      throw new HttpException(
        "Unexpected error while searching songs in Elasticsearch",
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
