// apps/api/src/songs/songs-search.service.ts
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import type { Prisma } from "@prisma/client";
import { SongStatus } from "@prisma/client";

export type SearchParams = {
  q?: string;
  skip?: number;
  take?: number;
  createdByUserId?: number;

  // Φίλτρα όπως στο παλιό /songs
  chords?: string;           // "1" | "0" | "null"
  partiture?: string;        // "1" | "0" | "null"
  categoryId?: number;       // category_id
  rythmId?: number;          // rythm_id
  characteristics?: string;  // characteristics
  lyricsFlag?: string;       // "null" για "χωρίς στίχους"
  status?: string;           // π.χ. "PUBLISHED", "PENDING_APPROVAL"

  // Δημοφιλή (ταξινόμηση κατά προβολές)
  popular?: string;          // "1" = sort by views desc
};

export type SearchResultItem = {
  song_id: number;
  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number;       // 1 = έχει συγχορδίες, 0 = όχι
  partiture: number;    // 1 = έχει scoreFile, 0 = όχι
  status: string;
  score: number;        // placeholder (προς το παρόν 0, χωρίς ES)
  views: number | null; // προβολές
};

export type SongsSearchResponse = {
  total: number;
  items: SearchResultItem[];
};

@Injectable()
export class SongsSearchService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Map από Prisma Song σε αντικείμενο για το /songs.
   * Χρησιμοποιούμε απλή λογική για chords / partiture.
   */
  private mapSongWithoutScore(s: any): SearchResultItem {
    const chordsValue =
      typeof s.chords === "string" && s.chords.trim() !== "" ? 1 : 0;

    return {
      song_id: s.id,
      title: s.title ?? "",
      firstLyrics: s.firstLyrics ?? "",
      lyrics: s.lyrics ?? "",
      characteristics: s.characteristics ?? "",
      originalKey: s.originalKey ?? "",
      chords: chordsValue,
      partiture: s.scoreFile ? 1 : 0,
      status: s.status ? String(s.status) : "",
      score: 0, // προς το παρόν, χωρίς Elasticsearch score
      views: typeof s.views === "number" ? s.views : null,
    };
  }

  /**
   * Βασική Postgres αναζήτηση με q πάνω σε title / firstLyrics / lyrics / characteristics.
   * Δέχεται baseWhere ώστε να "κουμπώνει" και τα υπόλοιπα φίλτρα
   * και flag sortByPopular για ταξινόμηση κατά views.
   */
  private async searchPostgresWithQuery(
    q: string,
    skip: number,
    take: number,
    baseWhere: Prisma.SongWhereInput,
    sortByPopular: boolean,
  ): Promise<SongsSearchResponse> {
    const cleaned = q.trim();

    const existingAnd: Prisma.SongWhereInput[] =
      ((baseWhere.AND as unknown as Prisma.SongWhereInput[]) ?? []);

    const where: Prisma.SongWhereInput = {
      ...baseWhere,
      AND: [
        ...existingAnd,
        {
          OR: [
            { title: { contains: cleaned, mode: "insensitive" } },
            { firstLyrics: { contains: cleaned, mode: "insensitive" } },
            { lyrics: { contains: cleaned, mode: "insensitive" } },
            {
              characteristics: {
                contains: cleaned,
                mode: "insensitive",
              },
            },
          ],
        },
      ],
    };

    const orderBy: Prisma.SongOrderByWithRelationInput[] = sortByPopular
      ? [{ views: "desc" }, { title: "asc" }]
      : [{ title: "asc" }];

    const [songs, total] = await this.prisma.$transaction([
      this.prisma.song.findMany({
        where,
        skip,
        take,
        orderBy,
      }),
      this.prisma.song.count({ where }),
    ]);

    return {
      total,
      items: songs.map((s) => this.mapSongWithoutScore(s)),
    };
  }

  /**
   * Κεντρική είσοδος αναζήτησης.
   * Προσομοιώνει τη λογική του παλιού /songs πάνω στο PostgreSQL schema.
   */
  async search(params: SearchParams): Promise<SongsSearchResponse> {
    let {
      q,
      skip = 0,
      take = 50,
      createdByUserId,
      chords,
      partiture,
      categoryId,
      rythmId,
      characteristics,
      lyricsFlag,
      status,
      popular,
    } = params;

    const sortByPopular = popular === "1";

    if (take <= 0) take = 50;
    if (take > 200) take = 200;
    if (skip < 0) skip = 0;

    q = (q ?? "").trim() || undefined;

    const baseWhere: Prisma.SongWhereInput = {};

    // -------------------------
    // Φίλτρο δημιουργού
    // -------------------------
    if (createdByUserId !== undefined) {
      baseWhere.createdByUserId = createdByUserId;
    }

    // -------------------------
    // Φίλτρο status
    // -------------------------
    let statusEnum: SongStatus | undefined;
    if (status) {
      const maybe = status.toUpperCase() as SongStatus;
      if ((Object.values(SongStatus) as string[]).includes(maybe)) {
        statusEnum = maybe;
      }
    }

    if (statusEnum) {
      baseWhere.status = statusEnum;
    }

    // -------------------------
    // Φίλτρο κατηγορίας
    // -------------------------
    if (categoryId !== undefined) {
      baseWhere.categoryId = categoryId;
    }

    // -------------------------
    // Φίλτρο ρυθμού
    // -------------------------
    if (rythmId !== undefined) {
      baseWhere.rythmId = rythmId;
    }

    // -------------------------
    // Φίλτρο characteristics
    // -------------------------
    if (characteristics === "null") {
      baseWhere.characteristics = null;
    } else if (characteristics && characteristics.trim() !== "") {
      baseWhere.characteristics = {
        contains: characteristics.trim(),
        mode: "insensitive",
      };
    }

    // -------------------------
    // Φίλτρο "χωρίς στίχους" (lyrics = null)
    // -------------------------
    if (lyricsFlag === "null") {
      baseWhere.lyrics = null;
    }

    // -------------------------
    // Φίλτρο συγχορδιών (chords)
    // -------------------------
    if (chords === "1") {
      // Θέλουμε chords όχι null ΚΑΙ όχι ""
      baseWhere.chords = { not: null };

      const andArr: Prisma.SongWhereInput[] =
        ((baseWhere.AND as unknown as Prisma.SongWhereInput[]) ?? []);
      andArr.push({
        chords: {
          not: "",
        },
      });
      baseWhere.AND = andArr;
    } else if (chords === "0" || chords === "null") {
      const orArr: Prisma.SongWhereInput[] =
        ((baseWhere.OR as unknown as Prisma.SongWhereInput[]) ?? []);
      orArr.push({ chords: null }, { chords: "" });
      baseWhere.OR = orArr;
    }

    // -------------------------
    // Φίλτρο παρτιτούρας (scoreFile)
    // -------------------------
    if (partiture === "1") {
      baseWhere.scoreFile = { not: null };
    } else if (partiture === "0" || partiture === "null") {
      baseWhere.scoreFile = null;
    }

    // -------------------------
    // Case A: ΔΕΝ υπάρχει q
    // -------------------------
    if (!q) {
      const where: Prisma.SongWhereInput = { ...baseWhere };

      // Αν δεν έχει δοθεί ούτε status ούτε createdByUserId,
      // για global λίστα βάζουμε μόνο PUBLISHED.
      if (!statusEnum && createdByUserId === undefined) {
        where.status = SongStatus.PUBLISHED;
      }

      const orderBy: Prisma.SongOrderByWithRelationInput[] = sortByPopular
        ? [{ views: "desc" }, { title: "asc" }]
        : [{ title: "asc" }];

      const [songs, total] = await this.prisma.$transaction([
        this.prisma.song.findMany({
          where,
          skip,
          take,
          orderBy,
        }),
        this.prisma.song.count({ where }),
      ]);

      return {
        total,
        items: songs.map((s) => this.mapSongWithoutScore(s)),
      };
    }

    // -------------------------
    // Case B: Υπάρχει q
    // -------------------------
    return this.searchPostgresWithQuery(q, skip, take, baseWhere, sortByPopular);
  }
}
