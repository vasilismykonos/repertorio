// apps/web/app/rooms/RoomsClient.tsx
"use client";

import { useCallback, useEffect, useState } from "react";
import { useRooms } from "@/app/components/RoomsProvider";

type Room = {
  room: string;
  userCount: number;
  hasPassword: boolean;
};

type RoomsClientProps = {
  initialRooms: Room[];
  isLoggedIn: boolean;
  isAdmin: boolean;
  initialCurrentRoom: string | null;
};

export default function RoomsClient(props: RoomsClientProps) {
  const { initialRooms, isLoggedIn, isAdmin, initialCurrentRoom } = props;
  const { currentRoom, switchRoom, wsConnected } = useRooms();

  const [rooms, setRooms] = useState<Room[]>(initialRooms);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomPassword, setNewRoomPassword] = useState("");
  const [selectedRoom, setSelectedRoom] = useState<string | null>(
    initialCurrentRoom
  );

  const showStatus = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  // Refresh rooms από API
  const refreshRooms = useCallback(async () => {
    try {
      const res = await fetch("/api/rooms", { cache: "no-store" });
      if (!res.ok) throw new Error("Αποτυχία φόρτωσης rooms");
      const data = (await res.json()) as Room[];
      setRooms(data);
    } catch (err) {
      console.error("Σφάλμα στο refreshRooms:", err);
      showStatus("❌ Αποτυχία φόρτωσης rooms.");
    }
  }, []);

  // Auto refresh κάθε 10 δευτερόλεπτα
  useEffect(() => {
    refreshRooms();
    const id = setInterval(() => {
      refreshRooms();
    }, 10000);
    return () => clearInterval(id);
  }, [refreshRooms]);

  // Live ενημέρωση count από WebSocket (RoomsProvider)
  useEffect(() => {
    if (typeof window === "undefined") return;

    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        room: string;
        userCount: number;
      };
      setRooms((prev) =>
        prev.map((r) =>
          r.room === detail.room ? { ...r, userCount: detail.userCount } : r
        )
      );
    };

    window.addEventListener("rep_rooms_update_count", handler as EventListener);

    return () => {
      window.removeEventListener(
        "rep_rooms_update_count",
        handler as EventListener
      );
    };
  }, []);

  // Όταν αλλάζει currentRoom στο context
  useEffect(() => {
    setSelectedRoom(currentRoom);
  }, [currentRoom]);

  const handleCreateRoom = async () => {
    if (!isLoggedIn) {
      showStatus("Πρέπει να είσαι συνδεδεμένος για να δημιουργήσεις room.");
      return;
    }

    const name = newRoomName.trim();
    if (!name) {
      showStatus("Δώσε όνομα room.");
      return;
    }

    try {
      const res = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          room: name,
          password: newRoomPassword.trim() || "",
        }),
      });

      const json = (await res.json().catch(() => ({}))) as {
        success?: boolean;
        message?: string;
      };

      if (!res.ok || json.success === false) {
        showStatus(json.message || "Αποτυχία δημιουργίας room.");
        return;
      }

      showStatus(json.message || "Το room δημιουργήθηκε.");
      setNewRoomName("");
      setNewRoomPassword("");
      await refreshRooms();

      // Κάνε join στο νέο room
      switchRoom(name, newRoomPassword.trim() || "");
    } catch (err) {
      console.error("handleCreateRoom error:", err);
      showStatus("Σφάλμα κατά τη δημιουργία room.");
    }
  };

  const handleJoinRoom = async (room: Room) => {
    if (!isLoggedIn) {
      showStatus("Πρέπει να είσαι συνδεδεμένος για να μπεις σε room.");
      return;
    }

    let password = "";
    if (room.hasPassword) {
      password = window.prompt(`Κωδικός για το room "${room.room}"`) || "";
    }

    // Προαιρετικός HTTP έλεγχος
    if (room.hasPassword && password.trim() !== "") {
      try {
        const res = await fetch("/api/rooms/join", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ room: room.room, password }),
        });
        const json = (await res.json().catch(() => ({}))) as {
          success?: boolean;
          valid?: boolean;
          message?: string;
        };
        if (!res.ok || !json.valid) {
          showStatus(json.message || "Λάθος κωδικός room.");
          return;
        }
      } catch (err) {
        console.error("join verify error:", err);
        showStatus("Σφάλμα κατά τον έλεγχο κωδικού.");
        return;
      }
    }

    switchRoom(room.room, password);
  };

  const handleLeaveRoom = () => {
    switchRoom(null);
  };

  const handleDeleteRoom = async (roomName: string) => {
    if (!isAdmin) {
      showStatus("Μόνο admin μπορούν να διαγράψουν room.");
      return;
    }
    if (!window.confirm(`Διαγραφή του room "${roomName}" ;`)) return;

    try {
      const res = await fetch(`/api/rooms/${encodeURIComponent(roomName)}`, {
        method: "DELETE",
      });
      const json = (await res.json().catch(() => ({}))) as {
        success?: boolean;
        message?: string;
      };

      if (!res.ok || json.success === false) {
        showStatus(json.message || "Αποτυχία διαγραφής room.");
        return;
      }

      showStatus(json.message || "Το room διαγράφηκε.");
      await refreshRooms();

      if (selectedRoom === roomName) {
        handleLeaveRoom();
      }
    } catch (err) {
      console.error("delete room error:", err);
      showStatus("Σφάλμα κατά τη διαγραφή room.");
    }
  };

  return (
    <div className="rooms-container">
      <div className="rooms-status">
        {statusMsg && <div className="rooms-status-msg">{statusMsg}</div>}
        <div className="rooms-connection">
          WebSocket: {wsConnected ? "🟢 συνδεδεμένο" : "🔴 αποσυνδεδεμένο"}
        </div>
      </div>

      <div className="rooms-create">
        <h4>Δημιουργία νέου room</h4>
        <input
          type="text"
          placeholder="Όνομα room"
          value={newRoomName}
          onChange={(e) => setNewRoomName(e.target.value)}
        />
        <input
          type="password"
          placeholder="Κωδικός (προαιρετικός)"
          value={newRoomPassword}
          onChange={(e) => setNewRoomPassword(e.target.value)}
        />
        <button onClick={handleCreateRoom}>Δημιουργία</button>
      </div>

      <div className="rooms-list">
        <h4>Διαθέσιμα rooms</h4>
        {rooms.length === 0 && <p>Δεν υπάρχουν rooms.</p>}
        {rooms.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Room</th>
                <th>Χρήστες</th>
                <th>Κωδικός</th>
                <th>Ενέργειες</th>
              </tr>
            </thead>
            <tbody>
              {rooms.map((r) => {
                const isCurrent = selectedRoom === r.room;
                return (
                  <tr key={r.room} className={isCurrent ? "current-room" : ""}>
                    <td>{r.room}</td>
                    <td>{r.userCount}</td>
                    <td>{r.hasPassword ? "🔒" : "—"}</td>
                    <td>
                      {!isCurrent && (
                        <button onClick={() => handleJoinRoom(r)}>Είσοδος</button>
                      )}
                      {isCurrent && (
                        <button onClick={handleLeaveRoom}>Έξοδος</button>
                      )}
                      {isAdmin && (
                        <button onClick={() => handleDeleteRoom(r.room)}>
                          Διαγραφή
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
