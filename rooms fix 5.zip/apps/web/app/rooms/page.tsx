// apps/web/app/rooms/page.tsx

import "@/public/rooms/repertorio-rooms.css";
import RoomsClient from "./RoomsClient";
import { getCurrentUserFromApi } from "@/lib/currentUser";

type Room = {
  room: string;
  userCount: number;
  hasPassword: boolean;
};

export const metadata = {
  title: "Rooms | Repertorio",
};

function getRoomsBaseUrl(): string {
  const base =
    process.env.ROOMS_HTTP_BASE_URL ||
    process.env.NEXT_PUBLIC_ROOMS_HTTP_BASE_URL ||
    "http://127.0.0.1:4455";

  return base.replace(/\/+$/, "");
}

async function fetchRooms(): Promise<Room[]> {
  const url = `${getRoomsBaseUrl()}/get-rooms`;
  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) return [];
    return (await res.json()) as Room[];
  } catch {
    return [];
  }
}

export default async function RoomsPage() {
  const [rooms, currentUser] = await Promise.all([
    fetchRooms(),
    getCurrentUserFromApi(),
  ]);

  const isLoggedIn = !!currentUser;
  const isAdmin = currentUser?.role === "ADMIN";
  const currentRoom = null; // θα ληφθεί από RoomsProvider (localStorage) client-side

  return (
    <div id="rooms-wrapper">
      <h3>Rooms</h3>

      <RoomsClient
        initialRooms={rooms}
        isLoggedIn={isLoggedIn}
        isAdmin={isAdmin}
        initialCurrentRoom={currentRoom}
      />
    </div>
  );
}
