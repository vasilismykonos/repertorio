// app/components/Sidebar.tsx
"use client";

import { useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { usePathname } from "next/navigation";

type SidebarProps = {
  isOpen: boolean;
  onClose: () => void;
};

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();

  const variants = {
    hidden: { x: "100%" },
    visible: { x: 0 },
  };

  // Debug / παρακολούθηση κατάστασης (μπορείς να το αφαιρέσεις αν σε ενοχλεί)
  useEffect(() => {
    console.log("[Sidebar] isOpen =", isOpen, "pathname =", pathname);
  }, [isOpen, pathname]);

  // Κλείσιμο σε κάθε αλλαγή route (ασφάλεια για να μην μένει ανοιχτό)
  useEffect(() => {
    if (isOpen) {
      onClose();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  // Κοινός handler για όλα τα menu links
  const handleLinkClick = () => {
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onClose}
        />
      )}

      {/* Πλαϊνό μενού */}
      <motion.aside
        className="fixed top-0 right-0 h-full w-72 bg-[var(--repertorio-sidebar-bg,#111)] text-white z-50 shadow-xl flex flex-col"
        initial="hidden"
        animate={isOpen ? "visible" : "hidden"}
        variants={variants}
        transition={{ type: "tween", duration: 0.3 }}
      >
        {/* Close button */}
        <button
          className="absolute top-2 right-3 text-2xl font-bold"
          onClick={onClose}
          aria-label="Close menu"
        >
          ×
        </button>

        {/* Header / λογότυπο sidebar (προσαρμόζεται ελεύθερα) */}
        <div className="mt-4 px-4 pb-2 border-b border-[rgba(255,255,255,0.12)]">
          <Link href="/" onClick={handleLinkClick}>
            <span className="text-xl font-semibold tracking-wide">
              Repertorio
            </span>
          </Link>
          <p className="mt-1 text-sm opacity-70">
            Γρήγορη πλοήγηση στις βασικές ενότητες.
          </p>
        </div>

        {/* Κύριο μενού */}
            <nav className="mt-4 px-4 space-y-3 text-lg flex-1 overflow-y-auto">
          <Link
            href="/songs"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            🎶 Τραγούδια
          </Link>

          <Link
            href="/lists"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            📋 Λίστες
          </Link>

          <Link
            href="/artists"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            👨‍🎤 Καλλιτέχνες
          </Link>

          <Link
            href="/rooms"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            🏠 Δωμάτια
          </Link>

          <Link
            href="/history"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            🕑 Ιστορικό
          </Link>

          <Link
            href="/profile"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            👤 Προφίλ
          </Link>

          <Link
            href="/contact"
            className="block hover:text-[var(--repertorio-primary,#ffd54f)]"
            onClick={handleLinkClick}
          >
            ❓ Βοήθεια &amp; επικοινωνία
          </Link>
        </nav>


        {/* Footer (π.χ. PWA / info) */}
        <div className="px-4 py-3 border-t border-[rgba(255,255,255,0.12)] text-sm space-y-2">
          <button
            type="button"
            className="w-full text-left text-[0.9rem] hover:text-[var(--repertorio-primary,#ffd54f)]"
            // εδώ θα βάλεις handler για PWA εγκατάσταση αν έχεις
            onClick={handleLinkClick}
          >
            📱 Εγκατάσταση εφαρμογής
          </button>

          <p className="opacity-60">
            © {new Date().getFullYear()} Repertorio. Όλα τα δικαιώματα
            διατηρούνται.
          </p>
        </div>
      </motion.aside>
    </>
  );
}
