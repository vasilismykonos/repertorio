/**
 * index.js – Entry point for the rooms WebSocket/REST server.
 *
 * This server exposes a small REST API for creating, listing and managing
 * rooms as well as a WebSocket endpoint for real-time song synchronisation
 * between users. It is intended to be run behind an HTTP proxy (e.g. Nginx)
 * that forwards both REST and WebSocket requests to the same port.
 *
 * Key endpoints:
 *   - GET  /health                 Health check
 *   - GET  /get-rooms              Returns a list of rooms (name, users, hasPassword)
 *   - POST /create-room            Creates a new room with optional password
 *   - POST /delete-room            Deletes an existing room and disconnects users
 *   - POST /verify-room-password   Verifies that a password matches the room
 *   - GET  /status                 Returns server status (uptime, rooms, users)
 *   - POST /manage-server          Wrapper around systemctl for restart/stop/start
 */


const http = require("http");
const express = require("express");
const cors = require("cors");
const { WebSocketServer } = require("ws");
const { exec } = require("child_process");
const { RoomManager } = require("./rooms");
const { handleWSConnection } = require("./ws-handler");

// -----------------------------------------------------------------------------
// Configuration via environment variables
// -----------------------------------------------------------------------------

// ΤΩΡΑ: ο νέος server ακούει στην 4455
// Μπορείς να ορίσεις ROOMS_PORT στο systemd, αλλιώς default 4455.
const PORT = Number(process.env.ROOMS_PORT || 4455);
const WS_PATH = process.env.WS_PATH || "/ws";

// -----------------------------------------------------------------------------
// Express application setup
// -----------------------------------------------------------------------------
const app = express();

// Limit JSON payloads to 32kb to prevent abuse
app.use(express.json({ limit: "32kb" }));

// Basic CORS configuration – in production we only allow your domains
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.length === 0) {
        return callback(null, true);
      }

      try {
        const host = new URL(origin).hostname;
        const allowedHostRegExp = new RegExp(
          allowedOrigins.map((h) => h.replace(/\./g, "\\.")).join("|"),
          "i",
        );
        return callback(null, allowedHostRegExp.test(host));
      } catch {
        // Reject malformed origins
        return callback(null, false);
      }
    },
    credentials: false,
  }),
);

// In-memory room manager. No persistence layer is provided by default.
const roomManager = new RoomManager();

// -----------------------------------------------------------------------------
// Utility helpers
// -----------------------------------------------------------------------------

/**
 * Simple structured logging helper.
 */
function logRequest(req, extra = {}) {
  const { method, url } = req;
  const time = new Date().toISOString();
  console.log(
    JSON.stringify({
      time,
      method,
      url,
      ...extra,
    }),
  );
}

// -----------------------------------------------------------------------------
// REST API endpoints
// -----------------------------------------------------------------------------

/**
 * Health check endpoint.
 */
app.get("/health", (req, res) => {
  res.json({
    ok: true,
    uptime: process.uptime(),
    rooms: roomManager.getRoomsOverview(),
  });
});

/**
 * Returns the current list of rooms.
 */
app.get("/get-rooms", (req, res) => {
  logRequest(req);
  const rooms = roomManager.getRoomsOverview();
  res.json(rooms);
});

/**
 * Create a new room with optional password.
 */
app.post("/create-room", (req, res) => {
  logRequest(req, { body: req.body });

  const { room, password } = req.body || {};

  if (!room || typeof room !== "string" || !room.trim()) {
    return res.status(400).json({
      success: false,
      message: "Το όνομα του room είναι υποχρεωτικό.",
    });
  }

  try {
    const normalizedRoom = room.trim();
    const hasPassword = !!(password && String(password).trim());

    roomManager.createRoom(normalizedRoom, hasPassword ? String(password) : null);

    return res.json({
      success: true,
      message: `Το room "${normalizedRoom}" δημιουργήθηκε επιτυχώς.`,
      room: normalizedRoom,
      hasPassword,
    });
  } catch (err) {
    console.error("Error in /create-room:", err);
    return res.status(500).json({
      success: false,
      message: "Σφάλμα κατά τη δημιουργία του room.",
    });
  }
});

/**
 * Delete an existing room and disconnect all users.
 */
app.post("/delete-room", (req, res) => {
  logRequest(req, { body: req.body });

  const { room } = req.body || {};

  if (!room || typeof room !== "string" || !room.trim()) {
    return res.status(400).json({
      success: false,
      message: "Το όνομα του room είναι υποχρεωτικό.",
    });
  }

  try {
    const normalizedRoom = room.trim();
    const existed = roomManager.deleteRoom(normalizedRoom);

    if (!existed) {
      return res.status(404).json({
        success: false,
        message: `Το room "${normalizedRoom}" δεν βρέθηκε.`,
      });
    }

    return res.json({
      success: true,
      message: `Το room "${normalizedRoom}" διαγράφηκε και όλοι οι χρήστες αποσυνδέθηκαν.`,
    });
  } catch (err) {
    console.error("Error in /delete-room:", err);
    return res.status(500).json({
      success: false,
      message: "Σφάλμα κατά τη διαγραφή του room.",
    });
  }
});

/**
 * Verify room password – used before attempting to join a room that has a password.
 */
app.post("/verify-room-password", (req, res) => {
  logRequest(req, { body: req.body });

  const { room, password } = req.body || {};

  if (!room || typeof room !== "string" || !room.trim()) {
    return res.status(400).json({
      success: false,
      message: "Το όνομα του room είναι υποχρεωτικό.",
      valid: false,
    });
  }

  if (typeof password !== "string") {
    return res.status(400).json({
      success: false,
      message: "Ο κωδικός είναι υποχρεωτικός.",
      valid: false,
    });
  }

  try {
    const normalizedRoom = room.trim();
    const isValid = roomManager.verifyRoomPassword(normalizedRoom, password);

    if (!isValid) {
      return res.status(200).json({
        success: false,
        message: "Ο κωδικός δεν είναι σωστός.",
        valid: false,
      });
    }

    return res.json({
      success: true,
      message: "Ο κωδικός είναι σωστός.",
      valid: true,
    });
  } catch (err) {
    console.error("Error in /verify-room-password:", err);
    return res.status(500).json({
      success: false,
      message: "Σφάλμα κατά τον έλεγχο του κωδικού.",
      valid: false,
    });
  }
});

/**
 * Returns server status, useful for debugging.
 */
app.get("/status", (req, res) => {
  logRequest(req);
  res.json({
    ok: true,
    uptime: process.uptime(),
    rooms: roomManager.getRoomsOverview(),
    memoryUsage: process.memoryUsage(),
  });
});

/**
 * manage-server endpoint: wrapper around systemctl restart/stop/start for the rooms service.
 *
 * WARNING: Use this only behind authentication / from trusted callers.
 */
app.post("/manage-server", (req, res) => {
  logRequest(req, { body: req.body });

  const { action } = req.body || {};
  if (!["restart", "stop", "start"].includes(action)) {
    return res.status(400).json({
      success: false,
      message: "Η ενέργεια πρέπει να είναι μία από: restart, stop, start.",
    });
  }

  const serviceName = process.env.ROOMS_SERVICE_NAME || "repertorio-rooms.service";
  const command = `systemctl ${action} ${serviceName}`;

  console.log(`Executing: ${command}`);

  // Απαντάμε αμέσως στον client
  res.json({
    success: true,
    message: `Η ενέργεια '${action}' ξεκίνησε...`,
  });

  // Τρέχουμε την εντολή systemctl ασύγχρονα
  setTimeout(() => {
    exec(command, (err, stdout, stderr) => {
      if (err) {
        console.error(`systemctl ${action} error:`, err);
      } else {
        console.log(
          `systemctl ${action} output:\nstdout:\n${stdout}\nstderr:\n${stderr}`,
        );
      }
    });
  }, 50);
});

// -----------------------------------------------------------------------------
// HTTP & WebSocket server setup
// -----------------------------------------------------------------------------
const httpServer = http.createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: WS_PATH });

// Handle incoming WebSocket connections
wss.on("connection", (ws, req) => {
  // mark as alive for heartbeat
  ws.isAlive = true;
  ws.on("pong", () => {
    ws.isAlive = true;
  });

  // Δεν απαιτούμε πλέον query ?room=...&device_id=...
  // Το δωμάτιο και το device_id έρχονται στo πρώτο μήνυμα
  // (type: "join_room", room: ..., password: ...).
  handleWSConnection(ws, req, roomManager);
});

// Heartbeat: terminate dead sockets every HEARTBEAT_MS
const HEARTBEAT_MS = 30000;
const heartbeatTimer = setInterval(() => {
  wss.clients.forEach((client) => {
    if (!client.isAlive) {
      try {
        client.terminate();
      } catch {}
      return;
    }
    client.isAlive = false;
    try {
      client.ping();
    } catch {}
  });
}, HEARTBEAT_MS);

wss.on("close", () => clearInterval(heartbeatTimer));

// Start listening
httpServer.listen(PORT, () => {
  console.log(`✅ Rooms server listening on http://0.0.0.0:${PORT}`);
  console.log(`   WS path: ${WS_PATH}`);
});
