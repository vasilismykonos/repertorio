// apps/api/src/songs/tags.service.ts

import { BadRequestException, Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

export type TagDto = {
  id: number;
  title: string;
  slug: string;
};

export type ListTagsArgs = {
  search?: string;
  take?: number;
  skip?: number;
};

function normalizeTitleForSlug(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function slugify(input: string): string {
  const s = normalizeTitleForSlug(input);

  const slug = s
    .replace(/[^a-z0-9\u0370-\u03ff\u1f00-\u1fff]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");

  return slug;
}

function clampInt(v: number, min: number, max: number): number {
  const n = Math.trunc(v);
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

@Injectable()
export class SongTagsService {
  constructor(private readonly prisma: PrismaService) {}

  async listTags(args: ListTagsArgs): Promise<TagDto[]> {
    const rawSearch = (args.search ?? "").toString().trim();
    const take = clampInt(args.take ?? 25, 1, 100);
    const skip = clampInt(args.skip ?? 0, 0, 1_000_000);

    const where =
      rawSearch.length > 0
        ? {
            OR: [
              { title: { contains: rawSearch, mode: "insensitive" as const } },
              {
                slug: {
                  contains: slugify(rawSearch),
                  mode: "insensitive" as const,
                },
              },
            ],
          }
        : undefined;

    return this.prisma.tag.findMany({
      where,
      orderBy: [{ title: "asc" }],
      take,
      skip,
      select: { id: true, title: true, slug: true },
    });
  }

  async createTag(body: { title: string }): Promise<TagDto> {
    const title = String(body?.title ?? "").trim();
    if (!title) throw new BadRequestException("title is required");

    const slug = slugify(title);
    if (!slug) throw new BadRequestException("invalid title");

    return this.prisma.tag.upsert({
      where: { slug },
      update: { title },
      create: { title, slug },
      select: { id: true, title: true, slug: true },
    });
  }
}
