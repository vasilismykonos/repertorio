import {
  BadRequestException,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Query,
} from "@nestjs/common";
import { ListsService } from "./lists.service";

@Controller("lists")
export class ListsController {
  constructor(private readonly listsService: ListsService) {}

  /**
   * Λίστα λιστών (index)
   * GET /lists?userId=&search=&groupId=&page=&pageSize=
   */
  @Get()
  async getListsIndex(
    @Query("userId") userIdStr?: string,
    @Query("search") search?: string,
    @Query("groupId") groupIdStr?: string,
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userId = Number(userIdStr);
    if (!Number.isFinite(userId) || userId <= 0) {
      throw new BadRequestException("userId must be a positive number");
    }

    const groupId =
      groupIdStr && groupIdStr !== "0"
        ? Number(groupIdStr)
        : undefined;

    const page = pageStr ? Number(pageStr) : 1;
    const pageSize = pageSizeStr ? Number(pageSizeStr) : 50;

    return this.listsService.getListsIndex({
      userId,
      search: search ?? "",
      groupId,
      page,
      pageSize,
    });
  }

  /**
   * Λεπτομέρεια λίστας (όλα τα items)
   */
  @Get(":id")
  async getListDetail(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userId = Number(userIdStr);
    if (!Number.isFinite(userId) || userId <= 0) {
      throw new BadRequestException("userId must be a positive number");
    }

    return this.listsService.getListDetail({
      listId: id,
      userId,
    });
  }

  /**
   * Μόνο τα items (με pagination)
   */
  @Get(":id/items")
  async getListItems(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userId = Number(userIdStr);
    if (!Number.isFinite(userId) || userId <= 0) {
      throw new BadRequestException("userId must be a positive number");
    }

    const page = pageStr ? Number(pageStr) : 1;
    const pageSize = pageSizeStr ? Number(pageSizeStr) : 50;

    return this.listsService.getListItems({
      userId,
      listId: id,
      page,
      pageSize,
    });
  }
}
