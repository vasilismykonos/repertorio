// apps/api/src/elasticsearch/elastic-songs.controller.ts

import { Controller, Get, HttpException, HttpStatus, Query } from "@nestjs/common";

type EsHit<T> = {
  _id: string;
  _source: T;
};

type EsSearchResponse<T> = {
  hits?: {
    total?: { value?: number };
    hits?: Array<EsHit<T>>;
  };
  aggregations?: any;
};

@Controller("songs-es")
export class ElasticSongsController {
  private readonly ES_BASE = process.env.ES_BASE_URL ?? "http://localhost:9200";
  private readonly INDEX = process.env.ES_SONGS_INDEX ?? "app_songs";

  private parseNumber(value: string | undefined, fallback: number, min?: number, max?: number) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    if (typeof min === "number" && n < min) return min;
    if (typeof max === "number" && n > max) return max;
    return n;
  }

  private parseBoolLike(v?: string): boolean | undefined {
    if (v == null) return undefined;
    const s = String(v).trim().toLowerCase();
    if (!s) return undefined;
    if (["1", "true", "yes", "y"].includes(s)) return true;
    if (["0", "false", "no", "n"].includes(s)) return false;
    return undefined;
  }

  private parseIdList(value?: string): number[] | undefined {
    if (!value) return undefined;
    const ids = value
      .split(",")
      .map((x) => Number(x.trim()))
      .filter((n) => Number.isFinite(n) && n > 0);
    return ids.length ? ids : undefined;
  }

  private pickFirstNonEmpty(...vals: Array<string | undefined>) {
    for (const v of vals) {
      const s = (v ?? "").toString().trim();
      if (s) return s;
    }
    return "";
  }

  private async esSearch<T>(body: any): Promise<EsSearchResponse<T>> {
    const url = `${this.ES_BASE}/${this.INDEX}/_search`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (!res.ok) {
      throw new HttpException(`Elasticsearch error ${res.status}: ${text}`, HttpStatus.BAD_GATEWAY);
    }
    try {
      return JSON.parse(text);
    } catch {
      throw new HttpException(`Elasticsearch returned non-JSON: ${text}`, HttpStatus.BAD_GATEWAY);
    }
  }

  private parseIdsFromAliases(...vals: Array<string | undefined>): number[] | undefined {
    const merged: number[] = [];
    for (const v of vals) {
      const ids = this.parseIdList(v);
      if (ids?.length) merged.push(...ids);
    }
    const uniq = Array.from(new Set(merged)).filter((n) => Number.isFinite(n) && n > 0);
    return uniq.length ? uniq : undefined;
  }

  @Get("search")
  async search(
    @Query("search_term") searchTerm?: string,
    @Query("q") q?: string,
    @Query("take") takeStr?: string,
    @Query("skip") skipStr?: string,

    @Query("categoryIds") categoryIdsStr?: string,
    @Query("rythmIds") rythmIdsStr?: string,

    @Query("category_id") categoryIdLegacy?: string,
    @Query("rythm_id") rythmIdLegacy?: string,
    @Query("categoryId") categoryIdAlt?: string,
    @Query("rythmId") rythmIdAlt?: string,

    @Query("chords") chordsStr?: string,
    @Query("lyrics") lyricsStr?: string,
    @Query("partiture") partitureStr?: string,

    @Query("status") status?: string,
    @Query("characteristics") characteristics?: string,

    // ✅ ΝΕΟ: dependent filtering A↔B
    @Query("singerFrontId") singerFrontIdStr?: string,
    @Query("singerBackId") singerBackIdStr?: string,
  ) {
    try {
      const take = this.parseNumber(takeStr, 50, 1, 200);
      const skip = this.parseNumber(skipStr, 0, 0, 1_000_000);

      const term = this.pickFirstNonEmpty(searchTerm, q);

      const categoryIds = this.parseIdsFromAliases(categoryIdsStr, categoryIdLegacy, categoryIdAlt);
      const rythmIds = this.parseIdsFromAliases(rythmIdsStr, rythmIdLegacy, rythmIdAlt);

      const wantChords = this.parseBoolLike(chordsStr);
      const wantLyrics = this.parseBoolLike(lyricsStr);
      const wantScore = this.parseBoolLike(partitureStr);

      const singerFrontId = this.parseNumber(singerFrontIdStr, 0, 0, 2_000_000) || null;
      const singerBackId = this.parseNumber(singerBackIdStr, 0, 0, 2_000_000) || null;

      const filters: any[] = [];

      if (categoryIds?.length) filters.push({ terms: { categoryId: categoryIds } });
      if (rythmIds?.length) filters.push({ terms: { rythmId: rythmIds } });

      if (status && String(status).trim()) filters.push({ term: { status: String(status).trim() } });

      if (typeof wantChords === "boolean") filters.push({ term: { hasChords: wantChords } });
      if (typeof wantLyrics === "boolean") filters.push({ term: { hasLyrics: wantLyrics } });
      if (typeof wantScore === "boolean") filters.push({ term: { hasScore: wantScore } });

      if (characteristics && String(characteristics).trim()) {
        filters.push({ match: { characteristics: String(characteristics).trim() } });
      }

      // ✅ ΝΕΟ: nested φίλτρο για συσχέτιση Α↔Β ανά version
      if (singerFrontId || singerBackId) {
        const nestedMust: any[] = [];
        if (singerFrontId) nestedMust.push({ term: { "versionSingerPairs.frontId": singerFrontId } });
        if (singerBackId) nestedMust.push({ term: { "versionSingerPairs.backId": singerBackId } });

        filters.push({
          nested: {
            path: "versionSingerPairs",
            query: { bool: { must: nestedMust } },
          },
        });
      }

      const query =
        term && term.trim().length
          ? {
              bool: {
                filter: filters,
                must: [
                  {
                    multi_match: {
                      query: term.trim(),
                      type: "best_fields",
                      operator: "and",
                      fields: [
                        "title^6",
                        "firstLyrics^3",
                        "lyrics^1",
                        "categoryTitle.text^2",
                        "rythmTitle.text^2",
                        "composerName.text^2",
                        "lyricistName.text^2",
                        "singerFrontNames.text^2",
                        "singerBackNames.text^2",
                        "yearText.text^1",
                      ],
                    },
                  },
                ],
              },
            }
          : { bool: { filter: filters } };

      // ✅ Dependent aggs: “δώσε μου τους επιτρεπτούς Β για τον επιλεγμένο Α”
      // (και αντίστροφα). Τα βγάζουμε από nested pairs.
      const dependentAggs: any = {};

      if (singerFrontId) {
        dependentAggs.pairedSingerBacks = {
          nested: { path: "versionSingerPairs" },
          aggs: {
            onlyThisFront: {
              filter: { term: { "versionSingerPairs.frontId": singerFrontId } },
              aggs: {
                backIds: { terms: { field: "versionSingerPairs.backId", size: 500 } },
                backNames: { terms: { field: "versionSingerPairs.backName.keyword", size: 500 } },
              },
            },
          },
        };
      }

      if (singerBackId) {
        dependentAggs.pairedSingerFronts = {
          nested: { path: "versionSingerPairs" },
          aggs: {
            onlyThisBack: {
              filter: { term: { "versionSingerPairs.backId": singerBackId } },
              aggs: {
                frontIds: { terms: { field: "versionSingerPairs.frontId", size: 500 } },
                frontNames: { terms: { field: "versionSingerPairs.frontName.keyword", size: 500 } },
              },
            },
          },
        };
      }

      const body = {
        from: skip,
        size: take,
        track_total_hits: true,
        _source: [
          "id",
          "legacySongId",
          "title",
          "firstLyrics",
          "lyrics",
          "characteristics",
          "originalKey",
          "categoryId",
          "categoryTitle",
          "rythmId",
          "rythmTitle",
          "composerName",
          "lyricistName",
          "singerFrontNames",
          "singerBackNames",
          "years",
          "minYear",
          "maxYear",
          "yearText",
          // NOTE: δεν χρειάζεται να γυρνάμε όλο το nested στο listing, εκτός αν το ζητήσεις
          "views",
          "status",
          "scoreFile",
          "hasChords",
          "hasLyrics",
          "hasScore",
        ],
        sort: [{ views: { order: "desc" } }, { id: { order: "asc" } }],
        aggs: {
          categoryId: { terms: { field: "categoryId", size: 200 } },
          rythmId: { terms: { field: "rythmId", size: 200 } },
          hasChords: { terms: { field: "hasChords", size: 2 } },
          hasLyrics: { terms: { field: "hasLyrics", size: 2 } },
          hasScore: { terms: { field: "hasScore", size: 2 } },
          ...dependentAggs,
        },
        query,
      };

      const json = await this.esSearch<any>(body);

      const total = json?.hits?.total?.value ?? 0;
      const hits = json?.hits?.hits ?? [];

      const items = hits.map((h) => {
        const s = (h?._source ?? {}) as any;
        const hasChords = !!s?.hasChords;
        const hasLyrics = !!s?.hasLyrics;
        const hasScore = !!s?.hasScore;

        return {
          ...s,
          chords: hasChords ? 1 : 0,
          lyricsFlag: hasLyrics ? 1 : 0,
          partiture: hasScore ? 1 : 0,
        };
      });

      const aggs = json?.aggregations ?? {};
      return { total, items, aggs };
    } catch (e: any) {
      throw new HttpException(e?.message ?? "Elasticsearch request failed", HttpStatus.BAD_GATEWAY);
    }
  }
}
