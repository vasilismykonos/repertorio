// apps/api/src/elasticsearch/elasticsearch-reindex.service.ts

import { Injectable, HttpException, HttpStatus } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

type ReindexState = {
  running: boolean;
  startedAt: string | null;
  finishedAt: string | null;

  total: number;
  processed: number;
  indexed: number;
  errors: number;

  lastId: number | null;
  message: string | null;

  esBase: string;
  index: string;
};

type EsBulkResponse = {
  errors?: boolean;
  items?: any[];
};

type VersionSingerPair = {
  versionId: number | null;
  year: number | null;

  frontId: number | null;
  frontName: string | null;

  backId: number | null;
  backName: string | null;
};

@Injectable()
export class ElasticsearchReindexService {
  private readonly ES_BASE = process.env.ES_BASE_URL ?? "http://localhost:9200";
  private readonly INDEX = process.env.ES_SONGS_INDEX ?? "app_songs";
  private readonly BATCH_SIZE = Number(process.env.ES_REINDEX_BATCH_SIZE ?? "500");

  private state: ReindexState = {
    running: false,
    startedAt: null,
    finishedAt: null,
    total: 0,
    processed: 0,
    indexed: 0,
    errors: 0,
    lastId: null,
    message: null,

    esBase: this.ES_BASE,
    index: this.INDEX,
  };

  constructor(private readonly prisma: PrismaService) {}

  getStatus() {
    return { ...this.state, esBase: this.ES_BASE, index: this.INDEX };
  }

  private nowIso() {
    return new Date().toISOString();
  }

  private textWithKeyword() {
    return {
      type: "text",
      analyzer: "el_text",
      fields: {
        keyword: { type: "keyword", ignore_above: 256 },
      },
    };
  }

  private kwWithText() {
    return {
      type: "text",
      analyzer: "el_text",
      fields: {
        keyword: { type: "keyword", ignore_above: 256 },
        text: { type: "text", analyzer: "el_text" },
      },
    };
  }

  buildIndexBody() {
    return {
      settings: {
        number_of_shards: 1,
        number_of_replicas: 0,
        refresh_interval: "1s",
        analysis: {
          char_filter: {
            el_diacritics_map: {
              type: "mapping",
              mappings: [
                "ά=>α",
                "έ=>ε",
                "ή=>η",
                "ί=>ι",
                "ό=>ο",
                "ύ=>υ",
                "ώ=>ω",
                "Ά=>Α",
                "Έ=>Ε",
                "Ή=>Η",
                "Ί=>Ι",
                "Ό=>Ο",
                "Ύ=>Υ",
                "Ώ=>Ω",
                "ϊ=>ι",
                "ΐ=>ι",
                "ϋ=>υ",
                "ΰ=>υ",
                "Ϊ=>Ι",
                "Ϋ=>Υ",
              ],
            },
          },
          analyzer: {
            el_text: {
              type: "custom",
              char_filter: ["html_strip", "el_diacritics_map"],
              tokenizer: "standard",
              filter: ["lowercase"],
            },
          },
        },
      },
      mappings: {
        dynamic: true,
        properties: {
          id: { type: "integer" },
          legacySongId: { type: "integer" },

          title: { type: "text", analyzer: "el_text" },
          firstLyrics: { type: "text", analyzer: "el_text" },
          lyrics: { type: "text", analyzer: "el_text" },

          characteristics: this.textWithKeyword(),

          categoryId: { type: "integer" },
          rythmId: { type: "integer" },

          categoryTitle: this.kwWithText(),
          rythmTitle: this.kwWithText(),

          composerName: this.kwWithText(),
          lyricistName: this.kwWithText(),

          // ✅ Υπάρχοντα: συγκεντρωτικά ονόματα
          singerFrontNames: this.kwWithText(),
          singerBackNames: this.kwWithText(),

          // ✅ Χρονιές
          years: { type: "integer" },
          minYear: { type: "integer" },
          maxYear: { type: "integer" },
          yearText: this.kwWithText(),

          // ✅ ΝΕΟ: συσχέτιση Α↔Β ανά δισκογραφία (SongVersion)
          // Nested ώστε να μπορούμε:
          // - να φιλτράρουμε αποτελέσματα με frontId/backId
          // - να κάνουμε aggs για "Β μόνο για αυτόν τον Α"
          versionSingerPairs: {
            type: "nested",
            properties: {
              versionId: { type: "integer" },
              year: { type: "integer" },

              frontId: { type: "integer" },
              frontName: this.kwWithText(),

              backId: { type: "integer" },
              backName: this.kwWithText(),
            },
          },

          status: { type: "keyword" },
          scoreFile: { type: "keyword" },
          originalKey: { type: "keyword" },
          views: { type: "integer" },

          hasChords: { type: "boolean" },
          hasLyrics: { type: "boolean" },
          hasScore: { type: "boolean" },
        },
      },
    };
  }

  private async esFetch(path: string, init?: RequestInit) {
    const res = await fetch(`${this.ES_BASE}${path}`, init);
    const text = await res.text();

    if (!res.ok) {
      throw new HttpException(`Elasticsearch error ${res.status}: ${text}`, HttpStatus.BAD_GATEWAY);
    }

    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }

  private async indexExists(index: string) {
    const res = await fetch(`${this.ES_BASE}/${index}`, { method: "HEAD" });
    return res.ok;
  }

  private async createIndex(index: string) {
    await this.esFetch(`/${index}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(this.buildIndexBody()),
    });
  }

  private async recreateIndex(index: string) {
    const exists = await this.indexExists(index);
    if (exists) {
      await this.esFetch(`/${index}`, { method: "DELETE" });
    }

    await this.esFetch(`/${index}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(this.buildIndexBody()),
    });
  }

  private async clearIndexDocs(index: string) {
    await this.esFetch(`/${index}/_delete_by_query?conflicts=proceed&refresh=false`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ query: { match_all: {} } }),
    });
  }

  private computeFirstLyrics(firstLyrics: string | null, lyrics: string | null) {
    const fl = (firstLyrics ?? "").toString().trim();
    if (fl) return fl;

    const ly = (lyrics ?? "").toString().trim();
    if (!ly) return null;

    const s = ly.replace(/\s+/g, " ").trim();
    return s.length > 120 ? s.slice(0, 120) : s;
  }

  private buildArtistName(a: any): string {
    const title = (a?.title ?? "").toString().trim();
    const first = (a?.firstName ?? "").toString().trim();
    const last = (a?.lastName ?? "").toString().trim();
    const full = `${first} ${last}`.trim();
    return (full || title || "").trim() || title || "";
  }

  private computeCreditNames(
    credits: any[] | null | undefined,
  ): { composerName: string | null; lyricistName: string | null } {
    const list = Array.isArray(credits) ? credits : [];

    const composers = list
      .filter((c) => c?.role === "COMPOSER" && c?.artist)
      .map((c) => this.buildArtistName(c.artist))
      .filter((s) => !!s);

    const lyricists = list
      .filter((c) => c?.role === "LYRICIST" && c?.artist)
      .map((c) => this.buildArtistName(c.artist))
      .filter((s) => !!s);

    return {
      composerName: composers.length ? composers.join(", ") : null,
      lyricistName: lyricists.length ? lyricists.join(", ") : null,
    };
  }

  private computeVersionMeta(
    versions: any[] | null | undefined,
  ): {
    singerFrontNames: string[] | null;
    singerBackNames: string[] | null;
    years: number[] | null;
    minYear: number | null;
    maxYear: number | null;
    yearText: string | null;

    versionSingerPairs: VersionSingerPair[] | null;
  } {
    const list = Array.isArray(versions) ? versions : [];

    const singerFront = new Set<string>();
    const singerBack = new Set<string>();
    const years = new Set<number>();

    const pairs: VersionSingerPair[] = [];

    for (const v of list) {
      const versionId = typeof v?.id === "number" ? v.id : null;

      const y = Number(v?.year);
      const year = Number.isFinite(y) && y > 0 ? y : null;
      if (year) years.add(year);

      const artists = Array.isArray(v?.artists) ? v.artists : [];

      // Συγκεντρώνουμε ανά version τους FRONT/BACK (με id+name),
      // και φτιάχνουμε ζεύγη front↔back (cartesian) μόνο μέσα στο ίδιο version.
      const fronts: Array<{ id: number | null; name: string | null }> = [];
      const backs: Array<{ id: number | null; name: string | null }> = [];

      for (const va of artists) {
        const role = (va?.role ?? "").toString();
        const artist = va?.artist;
        if (!artist) continue;

        const id = typeof artist?.id === "number" ? artist.id : null;
        const name = this.buildArtistName(artist);
        if (!name) continue;

        if (role === "SINGER_FRONT") {
          singerFront.add(name);
          fronts.push({ id, name });
        }
        if (role === "SINGER_BACK") {
          singerBack.add(name);
          backs.push({ id, name });
        }
      }

      // Ζεύγη μόνο όταν υπάρχουν και οι δύο πλευρές.
      if (fronts.length && backs.length) {
        for (const f of fronts) {
          for (const b of backs) {
            pairs.push({
              versionId,
              year,
              frontId: f.id,
              frontName: f.name,
              backId: b.id,
              backName: b.name,
            });
          }
        }
      }
    }

    const singerFrontNames = Array.from(singerFront);
    const singerBackNames = Array.from(singerBack);

    const yearsArr = Array.from(years).sort((a, b) => a - b);
    const minYear = yearsArr.length ? yearsArr[0] : null;
    const maxYear = yearsArr.length ? yearsArr[yearsArr.length - 1] : null;

    const yearText = yearsArr.length ? yearsArr.join(" ") : null;

    return {
      singerFrontNames: singerFrontNames.length ? singerFrontNames : null,
      singerBackNames: singerBackNames.length ? singerBackNames : null,
      years: yearsArr.length ? yearsArr : null,
      minYear,
      maxYear,
      yearText,
      versionSingerPairs: pairs.length ? pairs : null,
    };
  }

  private async bulkIndexBatch(index: string, rows: any[]) {
    const lines: string[] = [];

    for (const s of rows) {
      const lyrics = s.lyrics ?? null;
      const computedFirstLyrics = this.computeFirstLyrics(s.firstLyrics ?? null, lyrics);

      const chordsRaw = (s.chords ?? "").toString();
      const lyricsRaw = (lyrics ?? "").toString();
      const scoreFile = s.scoreFile ?? null;

      const hasChords = chordsRaw.trim().length > 0;
      const hasLyrics = lyricsRaw.trim().length > 0;
      const hasScore = !!(scoreFile && String(scoreFile).trim().length > 0);

      const { composerName, lyricistName } = this.computeCreditNames(s.credits);

      const {
        singerFrontNames,
        singerBackNames,
        years,
        minYear,
        maxYear,
        yearText,
        versionSingerPairs,
      } = this.computeVersionMeta(s.versions);

      lines.push(JSON.stringify({ index: { _index: index, _id: String(s.id) } }));
      lines.push(
        JSON.stringify({
          id: s.id,
          legacySongId: s.legacySongId ?? null,

          title: s.title ?? null,
          firstLyrics: computedFirstLyrics,
          lyrics: lyrics ?? null,

          characteristics: s.characteristics ?? null,

          categoryId: s.categoryId ?? null,
          rythmId: s.rythmId ?? null,

          categoryTitle: s.category?.title ?? null,
          rythmTitle: s.rythm?.title ?? null,

          composerName,
          lyricistName,

          singerFrontNames,
          singerBackNames,

          years,
          minYear,
          maxYear,
          yearText,

          // ✅ ΝΕΟ nested (Α↔Β ανά version)
          versionSingerPairs,

          status: (s.status ?? null) as any,
          scoreFile: scoreFile ?? null,
          originalKey: s.originalKey ?? null,
          views: typeof s.views === "number" ? s.views : 0,

          hasChords,
          hasLyrics,
          hasScore,
        }),
      );
    }

    const ndjson = lines.join("\n") + "\n";

    const res = await fetch(`${this.ES_BASE}/_bulk?refresh=false`, {
      method: "POST",
      headers: { "content-type": "application/x-ndjson" },
      body: ndjson,
    });

    const text = await res.text();

    if (!res.ok) {
      throw new HttpException(`Elasticsearch bulk HTTP ${res.status}: ${text}`, HttpStatus.BAD_GATEWAY);
    }

    let json: EsBulkResponse;
    try {
      json = JSON.parse(text);
    } catch {
      throw new HttpException(`Elasticsearch bulk returned non-JSON: ${text}`, HttpStatus.BAD_GATEWAY);
    }

    let batchErrors = 0;
    if (json?.items?.length) {
      for (const it of json.items) {
        const obj = it?.index ?? it?.create ?? it?.update ?? it?.delete;
        if (obj?.error) batchErrors++;
      }
    }

    return { batchErrors };
  }

  async startReindexNow(opts?: { recreate?: boolean }) {
    if (this.state.running) {
      return this.getStatus();
    }

    this.state = {
      running: true,
      startedAt: this.nowIso(),
      finishedAt: null,
      total: 0,
      processed: 0,
      indexed: 0,
      errors: 0,
      lastId: null,
      message: `Starting reindex... (esBase=${this.ES_BASE}, index=${this.INDEX}, recreate=${!!opts?.recreate})`,
      esBase: this.ES_BASE,
      index: this.INDEX,
    };

    void this.runReindex({ recreate: !!opts?.recreate }).catch((e) => {
      this.state.running = false;
      this.state.finishedAt = this.nowIso();
      this.state.message = `Reindex failed: ${e?.message ?? String(e)}`;
    });

    return this.getStatus();
  }

  private async runReindex(opts: { recreate: boolean }) {
    const index = this.INDEX;

    this.state.message = "Checking index...";
    const exists = await this.indexExists(index);

    if (!exists) {
      this.state.message = "Creating index...";
      await this.createIndex(index);
    } else if (opts.recreate) {
      this.state.message = "Recreating index...";
      await this.recreateIndex(index);
    }

    this.state.message = "Clearing documents...";
    await this.clearIndexDocs(index);

    this.state.message = "Counting songs in Postgres...";
    this.state.total = await this.prisma.song.count();

    this.state.message = "Indexing...";
    let lastId = 0;

    while (true) {
      const rows = await this.prisma.song.findMany({
        where: { id: { gt: lastId } },
        orderBy: { id: "asc" },
        take: this.BATCH_SIZE,
        select: {
          id: true,
          legacySongId: true,
          title: true,
          firstLyrics: true,
          lyrics: true,
          chords: true,
          characteristics: true,
          categoryId: true,
          rythmId: true,
          views: true,
          scoreFile: true,
          status: true,
          originalKey: true,

          category: { select: { title: true } },
          rythm: { select: { title: true } },

          credits: {
            select: {
              role: true,
              artist: { select: { id: true, title: true, firstName: true, lastName: true } },
            },
          },

          versions: {
            select: {
              // ✅ ΧΡΕΙΑΖΟΜΑΣΤΕ version id για nested pairs
              id: true,
              year: true,
              artists: {
                select: {
                  role: true,
                  artist: { select: { id: true, title: true, firstName: true, lastName: true } },
                },
              },
            },
          },
        },
      });

      if (!rows.length) break;

      const { batchErrors } = await this.bulkIndexBatch(index, rows);

      this.state.processed += rows.length;
      this.state.errors += batchErrors;
      this.state.indexed += Math.max(0, rows.length - batchErrors);

      lastId = rows[rows.length - 1].id;
      this.state.lastId = lastId;
      this.state.message = `Indexing... lastId=${lastId} (batchErrors=${batchErrors})`;

      await new Promise((r) => setTimeout(r, 5));
    }

    this.state.message = "Refreshing index...";
    await this.esFetch(`/${index}/_refresh`, { method: "POST" });

    this.state.running = false;
    this.state.finishedAt = this.nowIso();
    this.state.message = "Reindex completed";
  }

  async preview(take = 25) {
    const size = Math.min(Math.max(Number(take) || 25, 1), 200);

    const json = await this.esFetch(`/${this.INDEX}/_search`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        size,
        sort: [{ id: { order: "asc" } }],
        _source: [
          "id",
          "legacySongId",
          "title",
          "firstLyrics",
          "lyrics",
          "characteristics",
          "originalKey",
          "categoryId",
          "categoryTitle",
          "rythmId",
          "rythmTitle",
          "composerName",
          "lyricistName",
          "singerFrontNames",
          "singerBackNames",
          "years",
          "minYear",
          "maxYear",
          "yearText",
          "versionSingerPairs",
          "views",
          "status",
          "scoreFile",
          "hasChords",
          "hasLyrics",
          "hasScore",
        ],
        query: { match_all: {} },
      }),
    });

    const hits = json?.hits?.hits ?? [];
    const total = json?.hits?.total?.value ?? 0;
    const items = hits.map((h: any) => h?._source ?? {});

    return { total, items };
  }
}
