// apps/api/src/songs/songs.controller.ts

import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
} from "@nestjs/common";
import { SongsService } from "./songs.service";

@Controller("songs")
export class SongsController {
  constructor(private readonly songsService: SongsService) {}

  /**
   * GET /songs/:id
   * Query:
   *  - noIncrement=1 -> δεν αυξάνει views
   *
   * NOTE:
   *  Παλαιότερα υπήρχε route-regex (\\d+) για να ταιριάζει μόνο αριθμούς.
   *  Στο current stack (NestJS + path-to-regexp v8) το "(:id(\\d+))" ΔΕΝ υποστηρίζεται
   *  και προκαλεί runtime crash στον router.
   *
   *  Η προστασία του /songs/search γίνεται πλέον μέσω route registration order
   *  (βλ. SongsModule: δήλωση SongsSearchController πριν από SongsController).
   */
  @Get(":id")
  async findOne(
    @Param("id", ParseIntPipe) id: number,
    @Query("noIncrement") noIncrement?: string,
  ) {
    const noInc =
      noIncrement === "1" ||
      noIncrement === "true" ||
      noIncrement === "yes";
    return this.songsService.findOne(id, noInc);
  }

  /**
   * PATCH /songs/:id
   * Ενημέρωση βασικών πεδίων τραγουδιού.
   *
   * NOTE:
   *  Βλ. σχόλιο στο GET /songs/:id για το γιατί αφαιρέθηκε το regex.
   *
   * NEW:
   *  - tagIds: replace-all tags μέσω explicit join table (SongTag)
   *  - assets: replace-all assets μέσω explicit join table (SongAsset)
   */
  @Patch(":id")
  async updateSong(
    @Param("id", ParseIntPipe) id: number,
    @Body()
    body: {
      // core fields
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      chords?: string | null;
      status?: any; // mapping σε SongStatus γίνεται στο service
      categoryId?: number | null;
      rythmId?: number | null;
      basedOnSongId?: number | null;
      scoreFile?: string | null;
      highestVocalNote?: string | null;

      // ✅ NEW (explicit)
      tagIds?: number[] | null;
      assets?: Array<{
        id?: number;
        kind: any; // AssetKind (enum) validated στο service
        type?: any; // AssetType (enum)
        title?: string | null;
        url?: string | null;
        filePath?: string | null;
        mimeType?: string | null;
        sizeBytes?: string | number | bigint | null;

        // join metadata
        label?: string | null;
        sort?: number | null;
        isPrimary?: boolean | null;
      }> | null;
    },
  ) {
    return this.songsService.updateSong(id, body as any);
  }
}
