// apps/web/app/api/songs/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { fetchJson } from "@/lib/api";

type ApiSongResponse = {
  id: number;
  title: string;
};

type PatchSongBody = {
  title?: string;
  firstLyrics?: string | null;
  lyrics?: string | null;
  characteristics?: string | null;
  originalKey?: string | null;
  chords?: string | null;
  status?: string | null;

  categoryId?: number | null;
  rythmId?: number | null;
  makamId?: number | null;

  // ✅ αυτό πρέπει να φτάσει στο Nest
  tagIds?: number[] | null;

  // αν το χρησιμοποιείς
  assets?: any[] | null;
};

function buildRedirectHtml(targetPath: string): string {
  const safePath = targetPath.startsWith("/") ? targetPath : `/${targetPath}`;
  return `<!DOCTYPE html>
<html lang="el">
  <head>
    <meta charset="utf-8" />
    <title>Μεταφορά...</title>
    <meta http-equiv="refresh" content="0; url=${safePath}" />
  </head>
  <body>
    <p>Μεταφορά... Αν δεν γίνει αυτόματα, πατήστε <a href="${safePath}">εδώ</a>.</p>
    <script>window.location.href=${JSON.stringify(safePath)};</script>
  </body>
</html>`;
}

function parseJsonSafe<T>(raw: FormDataEntryValue | null, fallback: T): T {
  if (typeof raw !== "string") return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function toIntOrNull(v: FormDataEntryValue | null): number | null {
  if (v === null) return null;
  const s = String(v).trim();
  if (!s) return null;
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  return Math.trunc(n);
}

function normalizeTagIds(input: unknown): number[] {
  if (!Array.isArray(input)) return [];
  const ids = input
    .map((x) => Number(x))
    .filter((n) => Number.isFinite(n) && n > 0)
    .map((n) => Math.trunc(n));
  return Array.from(new Set(ids));
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  const idNum = Number(params.id);

  if (!Number.isFinite(idNum) || idNum <= 0) {
    const html = buildRedirectHtml("/songs");
    return new NextResponse(html, {
      status: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  let ok = true;

  try {
    const formData = await req.formData();

    const title = formData.get("title");
    const firstLyrics = formData.get("firstLyrics");
    const lyrics = formData.get("lyrics");
    const characteristics = formData.get("characteristics");
    const originalKey = formData.get("originalKey");
    const chords = formData.get("chords");
    const status = formData.get("status");

    const categoryId = formData.get("categoryId");
    const rythmId = formData.get("rythmId");
    const makamId = formData.get("makamId");

    // ✅ hidden inputs από page.tsx
    const tagIdsJson = formData.get("tagIdsJson");
    const assetsJson = formData.get("assetsJson");

    const body: PatchSongBody = {};

    if (title !== null) body.title = String(title);

    if (firstLyrics !== null) {
      const v = String(firstLyrics);
      body.firstLyrics = v === "" ? null : v;
    }

    if (lyrics !== null) {
      const v = String(lyrics);
      body.lyrics = v === "" ? null : v;
    }

    if (characteristics !== null) {
      const v = String(characteristics);
      body.characteristics = v === "" ? null : v;
    }

    if (originalKey !== null) {
      const v = String(originalKey);
      body.originalKey = v === "" ? null : v;
    }

    if (chords !== null) {
      const v = String(chords);
      body.chords = v === "" ? null : v;
    }

    if (status !== null) {
      const v = String(status);
      body.status = v === "" ? null : v;
    }

    if (categoryId !== null) body.categoryId = toIntOrNull(categoryId);
    if (rythmId !== null) body.rythmId = toIntOrNull(rythmId);
    if (makamId !== null) body.makamId = toIntOrNull(makamId);

    // ✅ TAGS: tagIdsJson -> tagIds
    const parsedTagIds = parseJsonSafe<unknown>(tagIdsJson, []);
    body.tagIds = normalizeTagIds(parsedTagIds);

    // ✅ assets (αν έχεις)
    const parsedAssets = parseJsonSafe<unknown>(assetsJson, null);
    body.assets = Array.isArray(parsedAssets) ? (parsedAssets as any[]) : null;

    // PATCH προς Nest API
    await fetchJson<ApiSongResponse>(`/songs/${idNum}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch (err) {
    ok = false;
    console.error("Update song failed for id=", params.id, err);
  }

  const targetPath = ok ? `/songs/${idNum}` : `/songs/${idNum}?error=1`;
  const html = buildRedirectHtml(targetPath);

  return new NextResponse(html, {
    status: 200,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
}
