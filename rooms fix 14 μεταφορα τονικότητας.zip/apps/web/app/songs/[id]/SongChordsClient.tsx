"use client";

import { useEffect, useMemo, useState } from "react";

type SongChordsClientProps = {
  chords: string;
  originalKey?: string | null;
};

// Πίνακες συγχορδιών όπως στο PHP
const ALL_CHORDS = [
  "Ντο",
  "Ντο#",
  "Ρε",
  "Ρε#",
  "Μι",
  "Φα",
  "Φα#",
  "Σολ",
  "Σολ#",
  "Λα",
  "Λα#",
  "Σι",
  "ντο",
  "ντο#",
  "ρε",
  "ρε#",
  "μι",
  "φα",
  "φα#",
  "σολ",
  "σολ#",
  "λα",
  "λα#",
  "σι",
];

const ALL_CHORDS_SMALL = [
  "ντο",
  "ντο#",
  "ρε",
  "ρε#",
  "μι",
  "φα",
  "φα#",
  "σολ",
  "σολ#",
  "λα",
  "λα#",
  "σι",
];

const NATURAL_TONICITIES = ["Ντο", "Ρε", "Μι", "Φα", "Σολ", "Λα", "Σι"];
const SHARP_TONICITIES = ["Ντο#", "Ρε#", "", "Φα#", "Σολ#", "Λα#", ""];

// Map για index → συγχορδία
const CHORD_INDEX_MAP: Record<string, number> = ALL_CHORDS.reduce(
  (acc, chord, index) => {
    acc[chord] = index;
    return acc;
  },
  {} as Record<string, number>
);

// Εξαγωγή τελευταίας συγχορδίας + πρόσημο (+/-) από το κείμενο
function detectLastChordAndSign(chords: string): {
  baseChord: string | null;
  sign: "+" | "-";
} {
  if (!chords) {
    return { baseChord: null, sign: "+" };
  }

  const regexChord = /([Νν][το]|[Ρρ][ε]|[Μμ][ι]|[Φφ][α]|[Σσ][ολ]|[Λλ][α]|[Σσ][ι])(#?)[\+\-]?/g;
  let match: RegExpExecArray | null;
  let lastMatch: RegExpExecArray | null = null;

  while ((match = regexChord.exec(chords)) !== null) {
    lastMatch = match;
  }

  if (!lastMatch) {
    return { baseChord: null, sign: "+" };
  }

  const full = lastMatch[0];
  let sign: "+" | "-" = "+";
  if (full.includes("-")) {
    sign = "-";
  }

  const tonic = (lastMatch[1] || "").toLowerCase();
  const sharp = lastMatch[2] || "";

  let baseChord: string | null = null;
  switch (tonic) {
    case "ντο":
      baseChord = "Ντο";
      break;
    case "ρε":
      baseChord = "Ρε";
      break;
    case "μι":
      baseChord = "Μι";
      break;
    case "φα":
      baseChord = "Φα";
      break;
    case "σολ":
      baseChord = "Σολ";
      break;
    case "λα":
      baseChord = "Λα";
      break;
    case "σι":
      baseChord = "Σι";
      break;
    default:
      baseChord = null;
  }

  if (!baseChord) {
    return { baseChord: null, sign };
  }

  if (sharp === "#") {
    baseChord += "#";
  }

  return { baseChord, sign };
}

// Μεταφορά συγχορδιών από baseChord σε targetTonicity
function transportChords(
  baseChord: string,
  targetTonicity: string,
  chords: string
): string {
  const originalIndex = CHORD_INDEX_MAP[baseChord];
  const targetIndex = CHORD_INDEX_MAP[targetTonicity];

  if (
    originalIndex === undefined ||
    targetIndex === undefined ||
    Number.isNaN(originalIndex) ||
    Number.isNaN(targetIndex)
  ) {
    return chords;
  }

  const offset = targetIndex - originalIndex;

  let result = chords;

  // Δημιουργία placeholders (ώστε να μη γίνουν διπλές αντικαταστάσεις)
  const placeholders = ALL_CHORDS.map(
    (_chord, index) => `__CHORD_${index}__`
  );
  const placeholdersSmall = ALL_CHORDS_SMALL.map(
    (_chord, index) => `__chord_${index}__`
  );

  // 1. Αντικατάσταση πρώτα των # (κεφαλαίων)
  ALL_CHORDS.forEach((chord, index) => {
    const placeholder = placeholders[index];
    const escaped = chord.replace("#", "\\#");
    const regex = new RegExp(escaped + "(?![A-Za-zΑ-Ωα-ω0-9])", "g");
    result = result.replace(regex, placeholder);
  });

  // 2. Αντικατάσταση απλών (κεφαλαίων)
  ALL_CHORDS.forEach((chord, index) => {
    const placeholder = placeholders[index];
    const escaped = chord.replace("#", "\\#");
    const regex = new RegExp(escaped, "g");
    result = result.replace(regex, placeholder);
  });

  // 3. Μικρά με # (για να ταιριάζουν σε πεζά)
  ALL_CHORDS_SMALL.forEach((chord, index) => {
    const placeholder = placeholdersSmall[index];
    const escaped = chord.replace("#", "\\#");
    const regex = new RegExp(escaped + "(?![A-Za-zΑ-Ωα-ω0-9])", "g");
    result = result.replace(regex, placeholder);
  });

  // 4. Μικρά χωρίς #
  ALL_CHORDS_SMALL.forEach((chord, index) => {
    const placeholder = placeholdersSmall[index];
    const escaped = chord.replace("#", "\\#");
    const regex = new RegExp(escaped, "g");
    result = result.replace(regex, placeholder);
  });

  // 5. Τελική αντικατάσταση placeholders με νέες συγχορδίες (κεφαλαία)
  ALL_CHORDS.forEach((chord, index) => {
    const placeholder = placeholders[index];
    const baseIndex = CHORD_INDEX_MAP[chord];
    if (baseIndex === undefined) return;
    const newIndex = (baseIndex + offset + 12) % 12;
    const newChord = ALL_CHORDS[newIndex];
    result = result.split(placeholder).join(newChord);
  });

  // 6. Τελική αντικατάσταση placeholders με νέες συγχορδίες (πεζά)
  ALL_CHORDS_SMALL.forEach((chord, index) => {
    const placeholder = placeholdersSmall[index];
    const baseIndex = CHORD_INDEX_MAP[chord.charAt(0).toUpperCase() + chord.slice(1)];
    if (baseIndex === undefined) return;
    const newIndex = (baseIndex + offset + 12) % 12;
    const newChord = ALL_CHORDS_SMALL[newIndex];
    result = result.split(placeholder).join(newChord);
  });

  return result;
}

// Χρωματισμός συγχορδιών όπως στο παλιό site
function colorizeChords(chords: string): string {
  if (!chords) return "";

  let result = chords;

  // Απλοποιημένο παράδειγμα: μπορείς να έχεις εδώ ό,τι λογική είχες στο PHP
  // για SpTune, Tunes_small, Stigmata, Numbers κτλ.
  result = result.replace(
    /(\[[^\]]+\])/g,
    '<span class="SpTune">$1</span>'
  );

  return result;
}

export default function SongChordsClient({
  chords,
  originalKey,
}: SongChordsClientProps) {
  const [baseChord, setBaseChord] = useState<string | null>(null);
  const [lastSign, setLastSign] = useState<"+" | "-">("+");
  const [selectedTonicity, setSelectedTonicity] = useState<string | null>(
    null
  );

  // Εντοπισμός τελευταίας συγχορδίας + πρόσημο όταν φορτώνει / αλλάζει το κείμενο
  useEffect(() => {
    const { baseChord, sign } = detectLastChordAndSign(chords);
    setBaseChord(baseChord);
    setLastSign(sign);
    setSelectedTonicity(baseChord); // default: ίδια τονικότητα με την τελευταία συγχορδία
  }, [chords]);

  // ΚΟΙΝΗ ΤΟΝΙΚΟΤΗΤΑ: ενημέρωση global μεταβλητής για το κουμπί "Room"
  useEffect(() => {
    if (typeof window === "undefined") return;
    const w = window as any;
    w.__repSelectedTonicity = selectedTonicity || null;
  }, [selectedTonicity]);

  // Εφαρμογή pending τονικότητας που ήρθε από το room (π.χ. από άλλον χρήστη)
  useEffect(() => {
    if (typeof window === "undefined") return;
    const w = window as any;
    const pending = w.__repPendingSelectedTonicity as string | null | undefined;
    if (!pending) return;

    let attempts = 0;
    const maxAttempts = 20;
    const interval = 250;

    const tryApply = () => {
      const ton = w.__repPendingSelectedTonicity as string | null | undefined;
      if (!ton) return;

      const btn = document.querySelector<HTMLButtonElement>(
        '.tonicity-button[data-tonicity="' + ton + '"]'
      );

      if (btn) {
        btn.click();
        // καθαρίζουμε το pending ώστε να μη ξανατρέχει
        w.__repPendingSelectedTonicity = null;
        return;
      }

      attempts += 1;
      if (attempts < maxAttempts) {
        window.setTimeout(tryApply, interval);
      } else {
        console.warn(
          "[SongChordsClient] Δεν μπόρεσα να εφαρμόσω την τονικότητα από το room:",
          pending
        );
      }
    };

    tryApply();
  }, []);

  const renderedChordsHtml = useMemo(() => {
    if (!chords || chords.trim() === "") return "";

    // Αν δεν βρέθηκε έγκυρη συγχορδία, γύρνα απλά χρωματισμένο το αρχικό
    if (!baseChord || !selectedTonicity) {
      return colorizeChords(chords);
    }

    const transported = transportChords(
      baseChord,
      selectedTonicity,
      chords
    );
    return colorizeChords(transported);
  }, [chords, baseChord, selectedTonicity]);

  return (
    <section
      id="chords-section"
      className="song-chords-container"
      style={{ marginBottom: 24 }}
    >
      {/* Κουμπιά Τονικοτήτων */}
      {baseChord && (
        <div
          className="tonicities-wrapper"
          style={{ marginTop: 8, marginBottom: 8 }}
        >
          <div className="tonicities-row">
            {NATURAL_TONICITIES.map((ton) => {
              const selected = selectedTonicity === ton;
              const label = `${ton}${lastSign}`;
              return (
                <button
                  key={ton}
                  type="button"
                  className={
                    "tonicity-button" +
                    (selected ? " selected" : "")
                  }
                  data-tonicity={ton}
                  onClick={() => setSelectedTonicity(ton)}
                >
                  {label}
                </button>
              );
            })}
          </div>

          <div className="tonicities-row">
            {SHARP_TONICITIES.map((ton) => {
              if (!ton) return null;
              const selected = selectedTonicity === ton;
              const label = `${ton}${lastSign}`;
              return (
                <button
                  key={ton}
                  type="button"
                  className={
                    "tonicity-button" +
                    (selected ? " selected" : "")
                  }
                  data-tonicity={ton}
                  onClick={() => setSelectedTonicity(ton)}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Μπλοκ συγχορδιών */}
      <div
        className="chords-block"
        style={{
          whiteSpace: "pre-wrap",
          backgroundColor: "#111",
          padding: "16px",
          borderRadius: 8,
          border: "1px solid #333",
          lineHeight: 1.6,
          fontFamily: "monospace",
          fontSize: "0.95rem",
        }}
        dangerouslySetInnerHTML={{ __html: renderedChordsHtml }}
      />

      <style jsx>{`
        .tonicities-wrapper {
          display: flex;
          flex-direction: column;
          gap: 4px;
          margin-bottom: 8px;
        }
        .tonicities-row {
          display: flex;
          flex-wrap: wrap;
          gap: 4px;
          margin-bottom: 4px;
        }
        .tonicity-button {
          background: #222;
          color: #fff;
          border: 1px solid #444;
          border-radius: 8px;
          padding: 4px 8px;
          cursor: pointer;
          font-size: 0.85rem;
          transition: 0.2s;
        }
        .tonicity-button:hover {
          background: #333;
        }
        .tonicity-button.selected {
          background: #2b6cb0;
          border-color: #2b6cb0;
          color: #fff;
        }
        .SpTune {
          color: #ffd700;
          font-weight: bold;
        }
        .Tunes_small {
          color: #ffe7a9;
        }
        .Stigmata {
          color: #cccccc;
        }
        .Numbers {
          color: #66d9ef;
          font-weight: bold;
        }
      `}</style>
    </section>
  );
}
