// src/users/users.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { UserRole } from "./user-role.enum";
import type { Prisma } from "@prisma/client";

export interface ListUsersOptions {
  search?: string;
  page: number;
  pageSize: number;
  sort: string;
  order: "asc" | "desc";
}

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Βοηθητική για sort στο Prisma με ασφαλή πεδία.
   */
  private buildOrderBy(
    sort: string,
    order: "asc" | "desc",
  ): Prisma.UserOrderByWithRelationInput {
    const direction: Prisma.SortOrder = order === "desc" ? "desc" : "asc";

    switch (sort) {
      case "email":
        return { email: direction };
      case "username":
        return { username: direction };
      case "createdAt":
        return { createdAt: direction };
      case "displayName":
      default:
        return { displayName: direction };
    }
  }

  /**
   * Μετράει τραγούδια ανά χρήστη από Postgres (Song.createdByUserId).
   */
  private async getSongCountsFromPostgres(
    userIds: number[],
  ): Promise<Map<number, number>> {
    const map = new Map<number, number>();
    if (userIds.length === 0) return map;

    const rows = await this.prisma.song.groupBy({
      by: ["createdByUserId"],
      where: {
        createdByUserId: { in: userIds },
      },
      _count: { _all: true },
    });

    for (const row of rows) {
      if (row.createdByUserId != null) {
        map.set(row.createdByUserId, row._count._all);
      }
    }

    return map;
  }

  /**
   * Μετράει εκδόσεις ανά χρήστη από Postgres (SongVersion.createdByUserId).
   */
  private async getVersionCountsFromPostgres(
    userIds: number[],
  ): Promise<Map<number, number>> {
    const map = new Map<number, number>();
    if (userIds.length === 0) return map;

    const rows = await this.prisma.songVersion.groupBy({
      by: ["createdByUserId"],
      where: {
        createdByUserId: { in: userIds },
      },
      _count: { _all: true },
    });

    for (const row of rows) {
      if (row.createdByUserId != null) {
        map.set(row.createdByUserId, row._count._all);
      }
    }

    return map;
  }

  /**
   * Λίστα χρηστών με:
   * - αναζήτηση
   * - ταξινόμηση
   * - σελιδοποίηση
   * - ΠΛΗΘΟΣ Τραγουδιών από Postgres
   * - ΠΛΗΘΟΣ Εκδόσεων από Postgres
   */
  async listUsers(options: ListUsersOptions) {
    const { search, page, pageSize, sort, order } = options;

    let where: Prisma.UserWhereInput | undefined;

    if (search && search.trim() !== "") {
      const s = search.trim();
      where = {
        OR: [
          { displayName: { contains: s } },
          { email: { contains: s } },
          { username: { contains: s } },
        ],
      };
    }

    const orderBy = this.buildOrderBy(sort, order);

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          wpId: true,
          email: true,
          username: true,
          displayName: true,
          role: true,
          createdAt: true,
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    const userIds = users.map((u) => u.id);

    const [songCounts, versionCounts] = await Promise.all([
      this.getSongCountsFromPostgres(userIds),
      this.getVersionCountsFromPostgres(userIds),
    ]);

    const items = users.map((u) => {
      const createdSongsCount = songCounts.get(u.id) ?? 0;
      const createdVersionsCount = versionCounts.get(u.id) ?? 0;

      return {
        id: u.id,
        email: u.email,
        username: u.username,
        displayName: u.displayName,
        role: u.role as UserRole,
        createdAt: u.createdAt,
        createdSongsCount,
        createdVersionsCount,
      };
    });

    const totalPages = total > 0 ? Math.ceil(total / pageSize) : 1;

    return {
      items,
      total,
      page,
      pageSize,
      totalPages,
    };
  }

  /**
   * Επιστροφή ενός χρήστη με counts για /users/[id].
   */
  async getUserById(id: number) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        wpId: true,
        email: true,
        username: true,
        displayName: true,
        role: true,
        createdAt: true,
      },
    });

    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    const [songsCount, versionsCount] = await Promise.all([
      this.prisma.song.count({
        where: { createdByUserId: user.id },
      }),
      this.prisma.songVersion.count({
        where: { createdByUserId: user.id },
      }),
    ]);

    return {
      id: user.id,
      email: user.email,
      username: user.username,
      displayName: user.displayName,
      role: user.role as UserRole,
      createdAt: user.createdAt,
      createdSongsCount: songsCount,
      createdVersionsCount: versionsCount,
    };
  }

  /**
   * Ενημέρωση χρήστη (displayName, role) από /users/[id]/edit.
   */
  async updateUser(
    id: number,
    body: { displayName?: string; role?: UserRole },
  ) {
    const existing = await this.prisma.user.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    const data: Prisma.UserUpdateInput = {};

    if (typeof body.displayName === "string") {
      const trimmed = body.displayName.trim();
      data.displayName = trimmed.length > 0 ? trimmed : null;
    }

    if (body.role) {
      data.role = body.role;
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data,
    });

    return updated;
  }
}
