// app/songs/[id]/page.tsx
export { default, generateMetadata } from "./SongPage";
