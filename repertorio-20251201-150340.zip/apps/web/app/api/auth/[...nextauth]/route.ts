// app/api/auth/[...nextauth]/route.ts
import NextAuth, { AuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";

/**
 * Κοινές ρυθμίσεις NextAuth, ώστε να μπορούμε να τις
 * χρησιμοποιήσουμε και από άλλα API routes (π.χ. /api/auth/me).
 */
export const authOptions: AuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      // Αν είναι πρώτη φορά login, περνάμε extra info
      if (account && profile) {
        // ποιος provider χρησιμοποιήθηκε (google κλπ)
        (token as any).provider = account.provider;
        // εικόνα προφίλ από το Google profile
        (token as any).picture = (profile as any).picture;
      }
      return token;
    },
    async session({ session, token }) {
      // Περνάμε custom δεδομένα στο session
      if (token) {
        (session.user as any).picture = (token as any).picture;
        (session.user as any).provider = (token as any).provider;
      }
      return session;
    },
  },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
