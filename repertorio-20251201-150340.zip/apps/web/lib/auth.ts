// lib/auth.ts
import type { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      // Αν είναι πρώτη φορά login, περνάμε extra info
      if (account && profile) {
        (token as any).provider = account.provider;
        (token as any).picture = (profile as any).picture;
      }
      return token;
    },
    async session({ session, token }) {
      // Περνάμε custom δεδομένα στο session
      if (token) {
        (session.user as any).picture = (token as any).picture;
        (session.user as any).provider = (token as any).provider;
      }
      return session;
    },
  },
};
