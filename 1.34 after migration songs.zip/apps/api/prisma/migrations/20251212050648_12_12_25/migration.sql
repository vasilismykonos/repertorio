/*
  Warnings:

  - You are about to drop the column `name` on the `Makam` table. All the data in the column will be lost.
  - You are about to drop the column `legacyComposerOld` on the `SongVersion` table. All the data in the column will be lost.
  - You are about to drop the column `legacyNewId` on the `SongVersion` table. All the data in the column will be lost.
  - You are about to drop the column `legacySongIdOld` on the `SongVersion` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[legacyArtistId]` on the table `Artist` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[title]` on the table `Makam` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `title` to the `Makam` table without a default value. This is not possible if the table is not empty.

*/
-- DropIndex
DROP INDEX "public"."Makam_name_key";

-- AlterTable
ALTER TABLE "Makam" DROP COLUMN "name",
ADD COLUMN     "title" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "SongVersion" DROP COLUMN "legacyComposerOld",
DROP COLUMN "legacyNewId",
DROP COLUMN "legacySongIdOld";

-- DropEnum
DROP TYPE "public"."VersionArtistRole";

-- CreateIndex
CREATE UNIQUE INDEX "Artist_legacyArtistId_key" ON "Artist"("legacyArtistId");

-- CreateIndex
CREATE UNIQUE INDEX "Makam_title_key" ON "Makam"("title");
