import { PrismaClient } from "@prisma/client";
import mysql from "mysql2/promise";

const prisma = new PrismaClient();

const MYSQL_CONFIG = {
  host: "127.0.0.1",
  user: "root",
  password: "ΒΑΛΕ_ΤΟ_MYSQL_PASSWORD",
  database: "repertorio.net",
};

async function main() {
  const mysqlConn = await mysql.createConnection(MYSQL_CONFIG);

  try {
    console.log("Loading MySQL songs...");
    const [mysqlSongs]: any[] = await mysqlConn.query(
      `SELECT Song_ID FROM songs ORDER BY Song_ID ASC`
    );

    console.log("Loading Postgres songs...");
    const pgSongs = await prisma.song.findMany({
      orderBy: { id: "asc" },
      take: mysqlSongs.length, // 2761
      select: { id: true },
    );

    if (mysqlSongs.length !== pgSongs.length) {
      throw new Error(
        `Count mismatch: MySQL=${mysqlSongs.length}, Postgres=${pgSongs.length}`
      );
    }

    console.log(`Mapping ${mysqlSongs.length} songs...`);

    const BATCH = 200;
    for (let i = 0; i < mysqlSongs.length; i += BATCH) {
      const ops = [];
      for (let j = i; j < i + BATCH && j < mysqlSongs.length; j++) {
        ops.push(
          prisma.song.update({
            where: { id: pgSongs[j].id },
            data: { legacySongId: mysqlSongs[j].Song_ID },
          })
        );
      }
      await prisma.$transaction(ops);
      console.log(`Updated ${Math.min(i + BATCH, mysqlSongs.length)} / ${mysqlSongs.length}`);
    }

    console.log("Done.");
  } finally {
    await prisma.$disconnect();
    await mysqlConn.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

