// src/songs/songs.controller.ts
import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
  NotFoundException,
  Res,
} from "@nestjs/common";
import { SongsService } from "./songs.service";
import type { Response } from "express";

@Controller("songs")
export class SongsController {
  constructor(private readonly songsService: SongsService) {}

  /**
   * Legacy redirect:
   * GET /songs/legacy/:legacyId  -> 301 /songs/:id (canonical Postgres Song.id)
   */
  @Get("legacy/:legacyId")
  async redirectFromLegacy(
    @Param("legacyId", ParseIntPipe) legacyId: number,
    @Res() res: Response,
  ) {
    const song = await this.songsService.findByLegacySongId(legacyId);

    if (!song) {
      throw new NotFoundException(`Song with legacySongId=${legacyId} not found`);
    }

    // 301 Permanent Redirect στο canonical URL (Postgres id)
    return res.redirect(301, `/songs/${song.id}`);
  }

  /**
   * Επιστρέφει ένα τραγούδι σε μορφή DTO, συμβατή
   * με το SongDetail του Next (SongPage.tsx).
   *
   * Αν καλέσεις /songs/:id?noIncrement=1 → ΔΕΝ αυξάνει views.
   * Αλλιώς αυξάνει views κατά 1.
   */
  @Get(":id")
  async getSongById(
    @Param("id", ParseIntPipe) id: number,
    @Query("noIncrement") noIncrement?: string,
  ) {
    const skipIncrement =
      noIncrement === "1" || noIncrement === "true" || noIncrement === "yes";
    return this.songsService.findOne(id, skipIncrement);
  }

  /**
   * Ενημέρωση τραγουδιού.
   *
   * Δέχεται μέρος των πεδίων του Song και επιστρέφει
   * το πλήρες SongDetail DTO μετά την αποθήκευση.
   */
  @Patch(":id")
  async updateSong(
    @Param("id", ParseIntPipe) id: number,
    @Body()
    body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      basedOn?: string | null;
      scoreFile?: string | null;
      highestVocalNote?: string | null;
      chords?: string | null;
      status?: string;
      categoryId?: number | null;
      rythmId?: number | null;
      makamId?: number | null;
    },
  ) {
    return this.songsService.updateSong(id, {
      ...body,
      // Η αντιστοίχιση του status στο enum SongStatus
      // γίνεται στο SongsService.updateSong.
    } as any);
  }
}
