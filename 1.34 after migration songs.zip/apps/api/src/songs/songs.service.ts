// apps/api/src/songs/songs.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { SongStatus } from "@prisma/client";

type ArtistMini = {
  id: number;
  legacyArtistId: number | null;
  title: string;
  firstName: string | null;
  lastName: string | null;
};

function buildArtistDisplayName(a: ArtistMini): string {
  const full = `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim();
  return full || a.title;
}

/**
 * Τα singerFront/singerBack/solist στο SongVersion είναι TEXT και
 * περιέχουν legacy Artist_ID της MySQL.
 *
 * Μπορεί να είναι:
 * - "373"
 * - "571,448" (πολλαπλοί -> κρατάμε τον πρώτο)
 * - "" ή "NULL" ή null
 * - ή μη αριθμητικό
 */
function parseFirstLegacyId(value: string | null | undefined): number | null {
  if (!value) return null;
  const v = value.trim();
  if (!v) return null;
  if (v.toUpperCase() === "NULL") return null;

  const first = v.split(",")[0]?.trim();
  if (!first) return null;
  if (!/^\d+$/.test(first)) return null;

  const n = Number(first);
  return Number.isFinite(n) ? n : null;
}

@Injectable()
export class SongsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Για legacy redirect:
   * Βρίσκει το canonical Postgres Song.id με βάση legacySongId.
   */
  async findByLegacySongId(
    legacySongId: number,
  ): Promise<{ id: number } | null> {
    return this.prisma.song.findFirst({
      where: { legacySongId },
      select: { id: true },
    });
  }

  /**
   * Επιστρέφει 1 τραγούδι σε μορφή DTO που ταιριάζει
   * με το SongDetail του Next.
   *
   * Αν noIncrement=true δεν αυξάνει τα views.
   */
  async findOne(id: number, noIncrement = false): Promise<any> {
    const song = await this.prisma.song.findUnique({
      where: { id },
      include: {
        category: true,
        rythm: true,
        composer: true,
        lyricist: true,
        versions: true, // ΝΕΟ: δεν υπάρχει πλέον SongVersionArtist
      },
    });

    if (!song) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    // Αν δεν θέλουμε αύξηση views, δεν κάνουμε τίποτα.
    if (!noIncrement) {
      await this.prisma.song.update({
        where: { id },
        data: {
          views: (song.views ?? 0) + 1,
        },
      });
    }

    // -----------------------------
    // Υπολογισμός categoryTitle
    // -----------------------------
    const categoryTitle = song.category ? song.category.title : null;

    // -----------------------------
    // Υπολογισμός composerName / lyricistName
    // (ανά SONG)
    // -----------------------------
    let composerName: string | null = null;
    let lyricistName: string | null = null;

    if (song.composer) {
      composerName = buildArtistDisplayName(song.composer as any);
    }

    if (song.lyricist) {
      lyricistName = buildArtistDisplayName(song.lyricist as any);
    }

    // -----------------------------
    // Υπολογισμός basedOnSongId / basedOnSongTitle
    // -----------------------------
    let basedOnSongId: number | null = null;
    let basedOnSongTitle: string | null = null;

    if (song.basedOn) {
      const idNum = Number(song.basedOn);
      if (Number.isFinite(idNum) && idNum > 0) {
        const baseSong = await this.prisma.song.findUnique({
          where: { id: idNum },
          select: { id: true, title: true },
        });

        if (baseSong) {
          basedOnSongId = baseSong.id;
          basedOnSongTitle = baseSong.title;
        }
      }
    }

    // -----------------------------
    // Υπολογισμός views (για DTO)
    // -----------------------------
    const views = noIncrement ? song.views ?? 0 : (song.views ?? 0) + 1;

    // -----------------------------
    // Enrich versions: legacy artist ids -> Postgres Artist
    // -----------------------------
    const versionsRaw = song.versions ?? [];

    // 1) Μάζεψε όλα τα legacy ids που χρειάζονται
    const legacyIdsSet = new Set<number>();
    for (const v of versionsRaw) {
      const sf = parseFirstLegacyId((v as any).singerFront);
      const sb = parseFirstLegacyId((v as any).singerBack);
      const so = parseFirstLegacyId((v as any).solist);
      if (sf != null) legacyIdsSet.add(sf);
      if (sb != null) legacyIdsSet.add(sb);
      if (so != null) legacyIdsSet.add(so);
    }

    // 2) Φέρε τους καλλιτέχνες με βάση legacyArtistId
    const legacyIds = Array.from(legacyIdsSet);
    const artists: ArtistMini[] =
      legacyIds.length > 0
        ? await this.prisma.artist.findMany({
            where: { legacyArtistId: { in: legacyIds } },
            select: {
              id: true,
              legacyArtistId: true,
              title: true,
              firstName: true,
              lastName: true,
            },
          })
        : [];

    const artistByLegacy = new Map<number, ArtistMini>();
    for (const a of artists) {
      if (a.legacyArtistId != null) {
        artistByLegacy.set(a.legacyArtistId, a);
      }
    }

    // 3) Φτιάξε DTO versions όπως τα θέλει το Next:
    //    - singerFront/singerBack/solist: ΟΝΟΜΑ
    //    - singerFrontId/singerBackId/solistId: Postgres Artist.id
    const versions =
      versionsRaw.map((v: any) => {
        const sfLegacy = parseFirstLegacyId(v.singerFront);
        const sbLegacy = parseFirstLegacyId(v.singerBack);
        const soLegacy = parseFirstLegacyId(v.solist);

        const sf = sfLegacy != null ? artistByLegacy.get(sfLegacy) : undefined;
        const sb = sbLegacy != null ? artistByLegacy.get(sbLegacy) : undefined;
        const so = soLegacy != null ? artistByLegacy.get(soLegacy) : undefined;

        return {
          id: v.id,
          year: v.year ?? null,

          // Πλέον επιστρέφουμε ΟΝΟΜΑΤΑ (όπως στο παλιό site)
          singerFront: sf ? buildArtistDisplayName(sf) : null,
          singerBack: sb ? buildArtistDisplayName(sb) : null,
          solist: so ? buildArtistDisplayName(so) : null,

          youtubeSearch: v.youtubeSearch ?? null,

          // Για link /artists/{id}
          singerFrontId: sf?.id ?? null,
          singerBackId: sb?.id ?? null,
          solistId: so?.id ?? null,
        };
      }) ?? [];

    // -----------------------------
    // Τελικό DTO προς Next
    // -----------------------------
    return {
      id: song.id,
      title: song.title,
      firstLyrics: song.firstLyrics,
      lyrics: song.lyrics,
      characteristics: song.characteristics,
      originalKey: song.originalKey,
      chords: song.chords,
      status: song.status,
      scoreFile: song.scoreFile,
      categoryId: song.categoryId ?? null,
      rythmId: song.rythmId ?? null,
      makamId: song.makamId ?? null,

      categoryTitle,
      composerName,
      lyricistName,
      rythmTitle: song.rythm ? song.rythm.title : null,

      basedOnSongId,
      basedOnSongTitle,

      views,
      versions,
    };
  }

  /**
   * Ενημέρωση τραγουδιού.
   *
   * Δέχεται μόνο συγκεκριμένα πεδία για update και επιστρέφει
   * πάλι το SongDetail DTO όπως το findOne, χωρίς να αυξάνει τα views.
   */
  async updateSong(
    id: number,
    body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      basedOn?: string | null;
      scoreFile?: string | null;
      highestVocalNote?: string | null;
      chords?: string | null;
      status?: SongStatus;
      categoryId?: number | null;
      rythmId?: number | null;
      makamId?: number | null;
    },
  ) {
    // Βεβαιωνόμαστε ότι υπάρχει το τραγούδι ή ρίχνουμε 404.
    const existing = await this.prisma.song.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    const data: any = {};

    if (typeof body.title === "string") {
      data.title = body.title;
    }

    if (Object.prototype.hasOwnProperty.call(body, "firstLyrics")) {
      data.firstLyrics = body.firstLyrics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "lyrics")) {
      data.lyrics = body.lyrics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "characteristics")) {
      data.characteristics = body.characteristics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "originalKey")) {
      data.originalKey = body.originalKey;
    }

    if (Object.prototype.hasOwnProperty.call(body, "defaultKey")) {
      data.defaultKey = body.defaultKey;
    }

    if (Object.prototype.hasOwnProperty.call(body, "basedOn")) {
      data.basedOn = body.basedOn;
    }

    if (Object.prototype.hasOwnProperty.call(body, "scoreFile")) {
      data.scoreFile = body.scoreFile;
    }

    if (Object.prototype.hasOwnProperty.call(body, "highestVocalNote")) {
      data.highestVocalNote = body.highestVocalNote;
    }

    if (Object.prototype.hasOwnProperty.call(body, "chords")) {
      data.chords = body.chords;
    }

    if (body.status) {
      if (Object.values(SongStatus).includes(body.status)) {
        data.status = body.status;
      }
    }

    if (Object.prototype.hasOwnProperty.call(body, "categoryId")) {
      data.categoryId = body.categoryId;
    }

    if (Object.prototype.hasOwnProperty.call(body, "rythmId")) {
      data.rythmId = body.rythmId;
    }

    if (Object.prototype.hasOwnProperty.call(body, "makamId")) {
      data.makamId = body.makamId;
    }

    if (Object.keys(data).length === 0) {
      return this.findOne(id, true);
    }

    await this.prisma.song.update({
      where: { id },
      data,
    });

    return this.findOne(id, true);
  }
}
