// apps/api/src/songs/songs-search.controller.ts
import { Controller, Get, Query } from "@nestjs/common";
import { SongsSearchService, SongsSearchResponse } from "./songs-search.service";

@Controller("songs")
export class SongsSearchController {
  constructor(private readonly songsSearchService: SongsSearchService) {}

  @Get("search")
  async search(
    @Query("q") q?: string,
    @Query("search_term") searchTerm?: string,
    @Query("term") term?: string,
    @Query("searchTerm") searchTerm2?: string,

    @Query("skip") skipStr?: string,
    @Query("take") takeStr?: string,

    @Query("chords") chords?: string,
    @Query("partiture") partiture?: string,
    @Query("category_id") categoryIdStr?: string,
    @Query("rythm_id") rythmIdStr?: string,
    @Query("characteristics") characteristics?: string,
    @Query("lyrics") lyricsFlag?: string,
    @Query("status") status?: string,
    @Query("popular") popular?: string,
    @Query("createdByUserId") createdByUserIdStr?: string,
  ): Promise<SongsSearchResponse> {
    const effectiveQ =
      (q || searchTerm || term || searchTerm2 || "").trim() || undefined;

    const skipNum = Number(skipStr);
    const takeNum = Number(takeStr);

    let skip = Number.isFinite(skipNum) && skipNum >= 0 ? skipNum : 0;
    let take = Number.isFinite(takeNum) && takeNum > 0 ? takeNum : 50;
    if (take > 200) take = 200;

    const createdByUserIdNum = Number(createdByUserIdStr);
    const createdByUserId =
      createdByUserIdStr &&
      Number.isFinite(createdByUserIdNum) &&
      createdByUserIdNum > 0
        ? createdByUserIdNum
        : undefined;

    const parseIdList = (value?: string): number[] | undefined => {
      if (!value) return undefined;
      const ids = value
        .split(",")
        .map((x) => Number(x.trim()))
        .filter((n) => Number.isFinite(n) && n > 0);
      return ids.length ? ids : undefined;
    };

    const categoryIds = parseIdList(categoryIdStr);
    const rythmIds = parseIdList(rythmIdStr);

    return this.songsSearchService.searchSongs({
      q: effectiveQ,
      skip,
      take,
      createdByUserId,
      chords,
      partiture,
      categoryIds,
      rythmIds,
      characteristics,
      lyricsFlag,
      status,
      popular,
    });
  }
}
