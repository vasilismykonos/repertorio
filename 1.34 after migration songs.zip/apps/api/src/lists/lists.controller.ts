// apps/api/src/lists/lists.controller.ts

import {
  BadRequestException,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Query,
} from "@nestjs/common";
import { ListsService } from "./lists.service";

@Controller("lists")
export class ListsController {
  constructor(private readonly listsService: ListsService) {}

  /**
   * Λίστα λιστών (index), αντίστοιχο με το display_lists_with_search
   * του παλιού plugin.
   *
   * Παράμετροι:
   * - userId (ΥΠΟΧΡΕΩΤΙΚΟ)
   * - search (προαιρετικό)
   * - groupId (προαιρετικό)
   * - page, pageSize (προαιρετικά)
   */
  @Get()
  async getListsIndex(
    @Query("userId") userIdStr?: string,
    @Query("search") search?: string,
    @Query("groupId") groupIdStr?: string,
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    const page = pageStr ? Number(pageStr) : 1;
    const pageSize = pageSizeStr ? Number(pageSizeStr) : 50;

    const groupId =
      groupIdStr && groupIdStr !== "0" ? Number(groupIdStr) : undefined;

    return this.listsService.getListsIndex({
      userId: userIdNum,
      search: search ?? "",
      groupId,
      page,
      pageSize,
    });
  }

  /**
   * Λεπτομέρειες λίστας + ΟΛΑ τα items (χωρίς pagination),
   * αντίστοιχο με το display_lists_items του παλιού plugin.
   *
   * Παράμετροι:
   * - userId (ΥΠΟΧΡΕΩΤΙΚΟ)
   */
  @Get(":id")
  async getListDetail(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    return this.listsService.getListDetail({
      userId: userIdNum,
      listId: id,
    });
  }

  /**
   * Μόνο τα items μίας λίστας, με σελιδοποίηση.
   * Εσωτερικά χρησιμοποιεί το getListDetail, άρα
   * τα δεδομένα είναι 1-προς-1 με το παλιό site.
   *
   * Παράμετροι:
   * - userId (ΥΠΟΧΡΕΩΤΙΚΟ)
   * - page, pageSize (προαιρετικά)
   */
  @Get(":id/items")
  async getListItems(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Query parameter 'userId' is required.");
    }

    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    const page = pageStr ? Number(pageStr) : 1;
    const pageSize = pageSizeStr ? Number(pageSizeStr) : 50;

    return this.listsService.getListItems({
      userId: userIdNum,
      listId: id,
      page,
      pageSize,
    });
  }
}
