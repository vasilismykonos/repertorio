import { Injectable, NotFoundException, ForbiddenException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

export type ListSummaryDto = {
  id: number;
  title: string;
  groupId: number | null;
  marked: boolean;
};

export type ListGroupSummaryDto = {
  id: number;
  title: string;
  fullTitle: string | null;
  listsCount: number;
};

export type ListsIndexResponse = {
  items: ListSummaryDto[];
  total: number;
  page: number;
  pageSize: number;
  groups: ListGroupSummaryDto[];
};

export type ListItemDto = {
  listItemId: number;
  listId: number;
  sortId: number;

  songId: number | null;
  rythmId: number | null;

  transport: number;
  notes: string | null;

  title: string;
  chords: string | null;
  chordsSource: "LIST" | "SONG" | "NONE";

  lyrics: string | null;
  lyricsSource: "LIST" | "SONG" | "NONE";
};

export type ListDetailDto = {
  id: number;
  title: string;
  notes: string | null;

  groupId: number | null;
  groupTitle: string | null;

  marked: boolean;

  role: "OWNER" | "EDITOR" | "VIEWER";

  items: ListItemDto[];
};

@Injectable()
export class ListsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Βοηθητικό: βρίσκει τον χρήστη και επιστρέφει wpId + αν είναι admin.
   */
  private async getUserContext(userId: number): Promise<{
    wpId: number | null;
    isAdmin: boolean;
  }> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, wpId: true, role: true },
    });

    if (!user) {
      throw new NotFoundException(`User ${userId} not found`);
    }

    const isAdmin = user.role === "ADMIN";
    const wpId = user.wpId ?? null;

    return { wpId, isAdmin };
  }

  /**
   * Φτιάχνει where-condition ACL για τον πίνακα List,
   * βασισμένο σε ownerWpId / viewWpIds / editWpIds.
   */
  private buildAclWhere(wpId: number | null, isAdmin: boolean): any {
    if (isAdmin || wpId == null) {
      // Admin ή χρήστης χωρίς wpId → βλέπει όλες τις λίστες
      return {};
    }

    const wpStr = String(wpId);

    return {
      OR: [
        { ownerWpId: wpId },
        { viewWpIds: { contains: wpStr } },
        { editWpIds: { contains: wpStr } },
      ],
    };
  }

  /**
   * Επιστρέφει λίστες (index) για τη σελίδα /lists.
   * Υλοποιείται 100% από Postgres μέσω Prisma.
   *
   * ΔΕΧΕΤΑΙ και group ΚΑΙ groupId (number), ώστε να είναι συμβατή
   * με τον controller που περνάει το groupId ως αριθμό.
   */
  async getListsIndex(params: {
    userId: number;
    search?: string;
    group?: string;
    groupId?: number;
    page?: number;
    pageSize?: number;
  }): Promise<ListsIndexResponse> {
    const {
      userId,
      search,
      group,
      groupId,
      page = 1,
      pageSize = 20,
    } = params;

    const cleanPage = page > 0 ? page : 1;
    const cleanPageSize = pageSize > 0 && pageSize <= 100 ? pageSize : 20;

    const { wpId, isAdmin } = await this.getUserContext(userId);
    const aclWhere = this.buildAclWhere(wpId, isAdmin);

    const filters: any = {};

    // Φίλτρο αναζήτησης τίτλου
    if (search && search.trim().length > 0) {
      filters.title = {
        contains: search.trim(),
        mode: "insensitive",
      };
    }

    // Φίλτρο group – παίρνουμε από group (string) ή από groupId (number)
    let rawGroup: string | undefined;

    if (group != null && group !== "") {
      rawGroup = group;
    } else if (typeof groupId === "number") {
      rawGroup = String(groupId);
    }

    if (rawGroup === "null") {
      filters.groupId = null;
    } else if (rawGroup && rawGroup.trim().length > 0) {
      const groupIdNum = Number(rawGroup);
      if (!Number.isNaN(groupIdNum)) {
        filters.groupId = groupIdNum;
      }
    }

    const where: any =
      Object.keys(aclWhere).length > 0 ? { AND: [aclWhere, filters] } : filters;

    const [total, listRows, groupRows] = await Promise.all([
      this.prisma.list.count({ where }),

      this.prisma.list.findMany({
        where,
        orderBy: [{ marked: "desc" }, { title: "asc" }, { id: "asc" }],
        skip: (cleanPage - 1) * cleanPageSize,
        take: cleanPageSize,
        select: {
          id: true,
          title: true,
          groupId: true,
          marked: true,
        },
      }),

      // Για τα group summaries, πόσες λίστες βλέπει ο χρήστης σε κάθε group
      this.prisma.listGroup.findMany({
        orderBy: [{ title: "asc" }, { id: "asc" }],
        include: {
          lists: {
            where: Object.keys(aclWhere).length > 0 ? aclWhere : undefined,
            select: { id: true },
          },
        },
      }),
    ]);

    const items: ListSummaryDto[] = listRows.map((row) => ({
      id: row.id,
      title: row.title,
      groupId: row.groupId,
      marked: row.marked,
    }));

    const groups: ListGroupSummaryDto[] = groupRows.map((g) => ({
      id: g.id,
      title: g.title,
      fullTitle: g.fullTitle ?? null,
      listsCount: g.lists.length,
    }));

    return {
      items,
      total,
      page: cleanPage,
      pageSize: cleanPageSize,
      groups,
    };
  }

  /**
   * Συμβατό helper, αν το καλεί κάπου ο controller με groupId:number.
   * Απλώς κάνει delegate στο getListsIndex.
   */
  async getListsForUser(params: {
    userId: number;
    search?: string;
    groupId?: number;
    page?: number;
    pageSize?: number;
  }): Promise<ListsIndexResponse> {
    const { userId, search, groupId, page, pageSize } = params;

    return this.getListsIndex({
      userId,
      search,
      groupId,
      page,
      pageSize,
    });
  }

  /**
   * Λεπτομέρειες μίας λίστας, μαζί με όλα τα items της.
   *
   * Δέχεται object { listId, userId }, για να ταιριάζει
   * με τον controller που καλεί getListDetail({ ... }).
   */
  async getListDetail(params: {
    listId: number;
    userId: number;
  }): Promise<ListDetailDto> {
    const { listId, userId } = params;

    const { wpId, isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      include: {
        group: true,
        items: {
          orderBy: [{ sortId: "asc" }, { id: "asc" }],
          include: { song: true },
        },
      },
    });

    if (!list) {
      throw new NotFoundException("List not found");
    }

    // Έλεγχος ACL: αν δεν είναι admin, χρειάζεται owner/view/edit
    const wpStr = wpId != null ? String(wpId) : null;
    if (!isAdmin && wpId != null) {
      const canView =
        list.ownerWpId === wpId ||
        (list.viewWpIds && list.viewWpIds.includes(wpStr!)) ||
        (list.editWpIds && list.editWpIds.includes(wpStr!));

      if (!canView) {
        // Για λόγους UX, 404 όπως στο παλιό Repertorio
        throw new NotFoundException(
          "Η λίστα δεν βρέθηκε ή δεν έχετε δικαίωμα να τη δείτε.",
        );
      }
    }

    const canEdit =
      isAdmin ||
      (wpId != null &&
        (list.ownerWpId === wpId ||
          (list.editWpIds && list.editWpIds.includes(String(wpId)))));

    const items: ListItemDto[] = list.items.map((item) => {
      const trimOrNull = (val?: string | null): string | null => {
        if (!val) return null;
        const t = val.trim();
        return t.length ? t : null;
      };

      const listChords = trimOrNull(item.chords);
      const songChords = trimOrNull(item.song?.chords ?? null);

      let chordsSource: "LIST" | "SONG" | "NONE";
      let chords: string | null;

      if (listChords) {
        chordsSource = "LIST";
        chords = listChords;
      } else if (songChords) {
        chordsSource = "SONG";
        chords = songChords;
      } else {
        chordsSource = "NONE";
        chords = null;
      }

      const listLyrics = trimOrNull(item.lyrics);
      const songLyrics = trimOrNull(item.song?.lyrics ?? null);

      let lyricsSource: "LIST" | "SONG" | "NONE";
      let lyrics: string | null;

      if (listLyrics) {
        lyricsSource = "LIST";
        lyrics = listLyrics;
      } else if (songLyrics) {
        lyricsSource = "SONG";
        lyrics = songLyrics;
      } else {
        lyricsSource = "NONE";
        lyrics = null;
      }

      return {
        listItemId: item.id,
        listId: item.listId,
        sortId: item.sortId,

        songId: item.songId ?? null,
        rythmId: (item as any).rythmId ?? null, // placeholder αν προσθέσεις rythmId στο ListItem

        transport: item.transport ?? 0,
        notes: item.notes ?? null,

        title: item.title,
        chords,
        chordsSource,
        lyrics,
        lyricsSource,
      };
    });

    const dto: ListDetailDto = {
      id: list.id,
      title: list.title,
      // Δεν έχουμε ξεχωριστό notes πεδίο στο List, οπότε null.
      notes: null,

      groupId: list.groupId,
      groupTitle: list.group ? list.group.title : null,

      marked: list.marked,

      role: canEdit ? "EDITOR" : "VIEWER",

      items,
    };

    return dto;
  }

  /**
   * Paginated items endpoint. Προς το παρόν γυρίζει όλα τα items (όπως getListDetail),
   * αλλά υποστηρίζει page/pageSize για μελλοντικό "load more".
   */
  async getListItems(params: {
    userId: number;
    listId: number;
    page?: number;
    pageSize?: number;
  }): Promise<{
    items: ListItemDto[];
    total: number;
    page: number;
    pageSize: number;
  }> {
    const { userId, listId } = params;
    const page = params.page && params.page > 0 ? params.page : 1;
    const pageSize =
      params.pageSize && params.pageSize > 0 && params.pageSize <= 200
        ? params.pageSize
        : 200;

    const { wpId, isAdmin } = await this.getUserContext(userId);

    const list = await this.prisma.list.findUnique({
      where: { id: listId },
      include: {
        items: {
          orderBy: [{ sortId: "asc" }, { id: "asc" }],
          include: { song: true },
        },
      },
    });

    if (!list) {
      throw new NotFoundException("List not found");
    }

    const wpStr = wpId != null ? String(wpId) : null;
    if (!isAdmin && wpId != null) {
      const canView =
        list.ownerWpId === wpId ||
        (list.viewWpIds && list.viewWpIds.includes(wpStr!)) ||
        (list.editWpIds && list.editWpIds.includes(wpStr!));

      if (!canView) {
        throw new ForbiddenException("Δεν έχετε πρόσβαση σε αυτή τη λίστα.");
      }
    }

    const total = list.items.length;
    const start = (page - 1) * pageSize;
    const slice = list.items.slice(start, start + pageSize);

    const items: ListItemDto[] = slice.map((item) => {
      const trimOrNull = (val?: string | null): string | null => {
        if (!val) return null;
        const t = val.trim();
        return t.length ? t : null;
      };

      const listChords = trimOrNull(item.chords);
      const songChords = trimOrNull(item.song?.chords ?? null);

      let chordsSource: "LIST" | "SONG" | "NONE";
      let chords: string | null;

      if (listChords) {
        chordsSource = "LIST";
        chords = listChords;
      } else if (songChords) {
        chordsSource = "SONG";
        chords = songChords;
      } else {
        chordsSource = "NONE";
        chords = null;
      }

      const listLyrics = trimOrNull(item.lyrics);
      const songLyrics = trimOrNull(item.song?.lyrics ?? null);

      let lyricsSource: "LIST" | "SONG" | "NONE";
      let lyrics: string | null;

      if (listLyrics) {
        lyricsSource = "LIST";
        lyrics = listLyrics;
      } else if (songLyrics) {
        lyricsSource = "SONG";
        lyrics = songLyrics;
      } else {
        lyricsSource = "NONE";
        lyrics = null;
      }

      return {
        listItemId: item.id,
        listId: item.listId,
        sortId: item.sortId,

        songId: item.songId ?? null,
        rythmId: (item as any).rythmId ?? null,

        transport: item.transport ?? 0,
        notes: item.notes ?? null,

        title: item.title,
        chords,
        chordsSource,
        lyrics,
        lyricsSource,
      };
    });

    return {
      items,
      total,
      page,
      pageSize,
    };
  }
}
