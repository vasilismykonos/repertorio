// app/components/RoomsSongSyncHandler.tsx
"use client";

import { useEffect } from "react";

/**
 * RoomsSongSyncHandler
 *
 * Ακούει το custom event "rep_song_sync" που εκπέμπει το RoomsProvider
 * όταν λάβει μήνυμα type: "song_sync" από τον WebSocket server.
 *
 * Όταν το payload.kind === "song" και υπάρχει payload.url,
 * κάνει redirect τον browser σε αυτό το URL, ώστε όλοι στο ίδιο room
 * να βλέπουν το ίδιο τραγούδι (όπως στο παλιό site).
 */
export default function RoomsSongSyncHandler() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const handler = (ev: Event) => {
      const custom = ev as CustomEvent<any>;
      const detail = custom.detail || {};
      const payload = detail.payload || {};

      // Περιμένουμε payload.kind === "song"
      if (payload.kind !== "song") {
        return;
      }

      const url = payload.url;
      if (!url || typeof url !== "string") {
        console.warn(
          "[RoomsSongSyncHandler] Received song_sync without valid url",
          payload
        );
        return;
      }

      try {
        const current = window.location.href;
        if (current === url) {
          // Ήδη στο ίδιο URL, δεν χρειάζεται redirect
          return;
        }
      } catch {
        // Αν για κάποιο λόγο αποτύχει, προχωράμε στο redirect.
      }

      console.log(
        "[RoomsSongSyncHandler] Navigating to synced song url:",
        url
      );

      // Απλό hard redirect – συμβατό με όλες τις σελίδες (Next, παλιό WP, κτλ.)
      window.location.href = url;
    };

    window.addEventListener("rep_song_sync", handler as EventListener);

    return () => {
      window.removeEventListener("rep_song_sync", handler as EventListener);
    };
  }, []);

  // Δεν αποδίδει τίποτα στο DOM – απλά side-effect.
  return null;
}
