// apps/api/src/songs/songs-search.service.ts
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma, SongStatus } from "@prisma/client";

export type SearchParams = {
  q?: string;
  skip: number;
  take: number;

  createdByUserId?: number;

  // Φίλτρα όπως στο /songs page
  chords?: string;           // "1" | "0" | "null"
  partiture?: string;        // "1" | "0" | "null"
  categoryIds?: number[];    // από query param category_id=1,2,3
  rythmIds?: number[];       // από query param rythm_id=4,5
  characteristics?: string;  // CSV / απλό string
  lyricsFlag?: string;       // "null" => μόνο χωρίς στίχους
  status?: string;           // PUBLISHED, PENDING_APPROVAL, DRAFT
  popular?: string;          // "1" => ταξινόμηση κατά views
};

export type SearchResultItem = {
  song_id: number;
  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number | string | boolean | null;
  partiture: number | string | boolean | null;
  status: string;
  score: number;
  views: number | null;

  // για τα counts των φίλτρων στο frontend
  category_id: number | null;
  categoryId: number | null;
  rythm_id: number | null;
  rythmId: number | null;
};

export type SongsSearchResponse = {
  total: number;
  items: SearchResultItem[];
};

@Injectable()
export class SongsSearchService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Mapping από Prisma Song -> SearchResultItem (χωρίς ES score).
   */
  private mapSongToResult(s: any): SearchResultItem {
    const chordsHas =
      typeof s.chords === "string" && s.chords.trim() !== ""
        ? 1
        : 0;

    const partitureHas = s.scoreFile ? 1 : 0;

    const categoryId =
      typeof s.categoryId === "number" ? s.categoryId : null;
    const rythmId =
      typeof s.rythmId === "number" ? s.rythmId : null;

    return {
      song_id: s.id,
      title: s.title ?? "",
      firstLyrics: s.firstLyrics ?? "",
      lyrics: s.lyrics ?? "",
      characteristics: s.characteristics ?? "",
      originalKey: s.originalKey ?? "",
      chords: chordsHas,
      partiture: partitureHas,
      status: s.status ? String(s.status) : "",
      score: 0, // Postgres δεν έχει _score από ES
      views: typeof s.views === "number" ? s.views : null,

      category_id: categoryId,
      categoryId,
      rythm_id: rythmId,
      rythmId,
    };
  }

  /**
   * Postgres αναζήτηση με q πάνω σε title / firstLyrics / lyrics / characteristics.
   */
  private async searchWithQuery(
    q: string,
    skip: number,
    take: number,
    baseWhere: Prisma.SongWhereInput,
    sortByPopular: boolean,
  ): Promise<SongsSearchResponse> {
    const cleaned = q.trim();

    const existingAnd: Prisma.SongWhereInput[] = Array.isArray(
      baseWhere.AND as any,
    )
      ? ((baseWhere.AND as any) as Prisma.SongWhereInput[])
      : [];

    const orClause: Prisma.SongWhereInput = {
      OR: [
        { title: { contains: cleaned, mode: "insensitive" } },
        { firstLyrics: { contains: cleaned, mode: "insensitive" } },
        { lyrics: { contains: cleaned, mode: "insensitive" } },
        { characteristics: { contains: cleaned, mode: "insensitive" } },
      ],
    };

    const finalWhere: Prisma.SongWhereInput = {
      ...baseWhere,
      AND: [...existingAnd, orClause],
    };

    const orderBy: Prisma.SongOrderByWithRelationInput[] = sortByPopular
      ? [{ views: "desc" }, { title: "asc" }]
      : [{ title: "asc" }];

    const [songs, total] = await this.prisma.$transaction([
      this.prisma.song.findMany({
        where: finalWhere,
        skip,
        take,
        orderBy,
      }),
      this.prisma.song.count({ where: finalWhere }),
    ]);

    return {
      total,
      items: songs.map((s) => this.mapSongToResult(s)),
    };
  }

  /**
   * Κεντρική είσοδος αναζήτησης για το /songs/search (Postgres).
   */
  async searchSongs(params: SearchParams): Promise<SongsSearchResponse> {
    const {
      q,
      skip,
      take,
      createdByUserId,
      chords,
      partiture,
      categoryIds,
      rythmIds,
      characteristics,
      lyricsFlag,
      status,
      popular,
    } = params;

    // Βασικό where – χωρίς deletedAt, για να ταιριάζει στο schema σου
    const where: Prisma.SongWhereInput = {};

    // createdByUserId
    if (typeof createdByUserId === "number") {
      where.createdByUserId = createdByUserId;
    }

    // chords
    if (chords === "1") {
      where.chords = { not: null };
    } else if (chords === "0") {
      where.chords = null;
    }

    // partiture
    if (partiture === "1") {
      where.scoreFile = { not: null };
    } else if (partiture === "0") {
      where.scoreFile = null;
    }

    // status
    if (status && status.trim() !== "") {
      const upper = status.trim().toUpperCase();
      const allowed = Object.values(SongStatus);
      if (allowed.includes(upper as SongStatus)) {
        where.status = upper as SongStatus;
      }
    }

    // categoryIds
    if (categoryIds && categoryIds.length > 0) {
      where.categoryId = { in: categoryIds };
    }

    // rythmIds
    if (rythmIds && rythmIds.length > 0) {
      where.rythmId = { in: rythmIds };
    }

    // characteristics
    if (characteristics === "null") {
      where.characteristics = null;
    } else if (characteristics && characteristics.trim() !== "") {
      where.characteristics = {
        contains: characteristics.trim(),
        mode: "insensitive",
      };
    }

    // lyricsFlag "null" => μόνο χωρίς στίχους
    if (lyricsFlag === "null") {
      where.lyrics = null;
    }

    const sortByPopular = popular === "1";

    // ασφάλεια στα take/skip
    const safeTake = (() => {
      if (!Number.isFinite(take)) return 50;
      if (take <= 0) return 50;
      if (take > 200) return 200;
      return take;
    })();

    const safeSkip = (() => {
      if (!Number.isFinite(skip)) return 0;
      if (skip < 0) return 0;
      return skip;
    })();

    // Αν υπάρχει q -> full-text φίλτρα σε Postgres
    if (q && q.trim() !== "") {
      return this.searchWithQuery(
        q,
        safeSkip,
        safeTake,
        where,
        sortByPopular,
      );
    }

    // Χωρίς q: απλό where + ταξινόμηση
    const orderBy: Prisma.SongOrderByWithRelationInput[] = sortByPopular
      ? [{ views: "desc" }, { title: "asc" }]
      : [{ title: "asc" }];

    const [songs, total] = await this.prisma.$transaction([
      this.prisma.song.findMany({
        where,
        skip: safeSkip,
        take: safeTake,
        orderBy,
      }),
      this.prisma.song.count({ where }),
    ]);

    return {
      total,
      items: songs.map((s) => this.mapSongToResult(s)),
    };
  }
}
