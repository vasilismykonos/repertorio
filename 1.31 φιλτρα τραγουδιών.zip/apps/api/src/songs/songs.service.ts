// src/songs/songs.service.ts

import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

export enum VersionArtistRole {
  SINGER_FRONT = "SINGER_FRONT",
  SINGER_BACK = "SINGER_BACK",
  SOLOIST = "SOLOIST",
  MUSICIAN = "MUSICIAN",
  COMPOSER = "COMPOSER",
  LYRICIST = "LYRICIST",
}

@Injectable()
export class SongsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Επιστρέφει 1 τραγούδι σε μορφή DTO που ταιριάζει
   * με το SongDetail του Next.
   *
   * Αν noIncrement = true → ΔΕΝ αυξάνει views (π.χ. για generateMetadata).
   * Αν noIncrement = false → αυξάνει views κατά 1 στο Postgres.
   */
  async findOne(id: number, noIncrement = false): Promise<any> {
    const song = await this.prisma.song.findUnique({
      where: { id },
      include: {
        category: true,
        rythm: true,
        versions: {
          include: {
            artists: {
              include: {
                artist: true,
              },
            },
          },
        },
      },
    });

    if (!song) {
      throw new NotFoundException(`Song with id ${id} not found`);
    }

    // -----------------------------
    // Συνθέτης (composerName)
    // -----------------------------
    let composerName: string | null = null;

    // 1) ΝΕΟ schema – VersionArtistRole.COMPOSER
    for (const v of song.versions ?? []) {
      const composerArtist = v.artists?.find(
        (va) => va.role === VersionArtistRole.COMPOSER && va.artist,
      );
      if (composerArtist && composerArtist.artist) {
        const a = composerArtist.artist;
        const fullName =
          `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim() || a.title;
        if (fullName) {
          composerName = fullName;
          break;
        }
      }
    }

    // 2) Προαιρετικό fallback από legacyComposerOld ΑΝ μοιάζει με όνομα
    if (!composerName) {
      const withLegacy = song.versions?.find(
        (v) => v.legacyComposerOld && v.legacyComposerOld.trim() !== "",
      );
      if (withLegacy) {
        const candidate = withLegacy.legacyComposerOld!.trim();

        const looksLikeCode =
          /^[0-9a-f]{6,}$/i.test(candidate) ||
          candidate.length <= 2 ||
          !/[A-Za-zΑ-Ωα-ω]/.test(candidate);

        if (!looksLikeCode) {
          composerName = candidate;
        }
      }
    }

    // -----------------------------
    // Στιχουργός (lyricistName)
    // -----------------------------
    let lyricistName: string | null = null;

    // 1) ΝΕΟ schema – VersionArtistRole.LYRICIST
    for (const v of song.versions ?? []) {
      const lyricistArtist = v.artists?.find(
        (va) => va.role === VersionArtistRole.LYRICIST && va.artist,
      );
      if (lyricistArtist && lyricistArtist.artist) {
        const a = lyricistArtist.artist;
        const fullName =
          `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim() || a.title;
        if (fullName) {
          lyricistName = fullName;
          break;
        }
      }
    }

    // -----------------------------
    // Κατηγορία
    // -----------------------------
    const categoryTitle: string | null = song.category
      ? song.category.title
      : null;

    // -----------------------------
    // Προβολές (views): μόνο νέο schema (Postgres)
    // -----------------------------
    let views: number;

    if (noIncrement) {
      // ΜΟΝΟ ανάγνωση, χωρίς αύξηση
      views = song.views ?? 0;
    } else {
      // Αύξηση κατά 1 στο Postgres
      views = (song.views ?? 0) + 1;

      try {
        await this.prisma.song.update({
          where: { id: song.id },
          data: { views },
        });
      } catch (err) {
        console.error(
          "[SongsService] Αποτυχία ενημέρωσης views στο Postgres",
          {
            songId: song.id,
            err,
          },
        );
      }
    }

    // -----------------------------
    // Βασισμένο σε: από basedOn (string) -> τίτλος + ID για link
    // Χωρίς πρόσβαση στην παλιά MySQL:
    // - Αν basedOn είναι αριθμός → το θεωρούμε legacy Song_ID και ψάχνουμε στο Postgres
    // - Αλλιώς κρατάμε μόνο το raw string
    // -----------------------------
    let basedOnSongId: number | null = null;
    let basedOnSongTitle: string | null = null;

    if (song.basedOn && song.basedOn.trim() !== "") {
      const code = song.basedOn.trim();

      const numeric = Number(code);
      if (!Number.isNaN(numeric)) {
        try {
          const baseSong = await this.prisma.song.findFirst({
            where: { legacySongId: numeric },
            select: {
              id: true,
              title: true,
            },
          });

          if (baseSong) {
            basedOnSongId = baseSong.id;
            basedOnSongTitle = baseSong.title;
          }
        } catch (err) {
          console.error("[SongsService] Σφάλμα Prisma στο basedOn mapping", {
            songId: song.id,
            basedOn: code,
            err,
          });
        }
      }

      // Αν δεν βρούμε τίτλο με κανέναν τρόπο, τουλάχιστον δείχνουμε το raw string
      if (!basedOnSongTitle) {
        basedOnSongTitle = code;
      }
    }

    // -----------------------------
    // Δισκογραφία: μόνο από το νέο schema
    // -----------------------------
    const versions =
      song.versions?.map((v) => {
        let singerFront: string | null = null;
        let singerBack: string | null = null;
        let solist: string | null = null;

        for (const va of v.artists ?? []) {
          if (!va.artist) continue;
          const a = va.artist;
          const fullName =
            `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim() || a.title;

          switch (va.role) {
            case VersionArtistRole.SINGER_FRONT:
              singerFront = fullName;
              break;
            case VersionArtistRole.SINGER_BACK:
              singerBack = fullName;
              break;
            case VersionArtistRole.SOLOIST:
              solist = fullName;
              break;
          }
        }

        return {
          id: v.id,
          year: v.year,
          singerFront,
          singerBack,
          solist,
          youtubeSearch: v.youtubeSearch ?? null,
        };
      }) ?? [];

    // -----------------------------
    // Τελικό DTO προς Next
    // -----------------------------
    return {
      id: song.id,
      title: song.title,
      firstLyrics: song.firstLyrics,
      lyrics: song.lyrics,
      characteristics: song.characteristics,
      originalKey: song.originalKey,
      chords: song.chords,
      status: song.status,
      scoreFile: song.scoreFile,

      categoryTitle,
      composerName,
      lyricistName,
      rythmTitle: song.rythm ? song.rythm.title : null,

      basedOnSongId,
      basedOnSongTitle,

      views,
      versions,
    };
  }
}
