// apps/api/scripts/sync-legacy-categories-rythms.ts

import "dotenv/config";
import mysql from "mysql2/promise";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// 1ο run: μπορείς να το αφήσεις true για να δεις ΜΟΝΟ logs χωρίς UPDATE.
// Όταν είσαι σίγουρος, βάλτο false για να γίνουν οι ενημερώσεις.
const DRY_RUN = false;

type LegacyCategoryRow = {
  Category_ID: number;
  Category: string | null; // από Title AS Category
};

type LegacyRythmRow = {
  Rythm_ID: number;
  Rythm: string | null; // από Title AS Rythm
};

async function main() {
  console.log("[sync] Ξεκινάει ο συγχρονισμός κατηγοριών & ρυθμών από legacy MySQL...");

  const {
    OLD_DB_HOST,
    OLD_DB_PORT,
    OLD_DB_USER,
    OLD_DB_PASSWORD,
    OLD_DB_NAME,
  } = process.env;

  if (!OLD_DB_HOST || !OLD_DB_USER || !OLD_DB_NAME) {
    throw new Error(
      "Λείπουν τα env OLD_DB_HOST / OLD_DB_USER / OLD_DB_NAME για MySQL (δες .env).",
    );
  }

  const mysqlConn = await mysql.createConnection({
    host: OLD_DB_HOST,
    port: OLD_DB_PORT ? Number(OLD_DB_PORT) : 3306,
    user: OLD_DB_USER,
    password: OLD_DB_PASSWORD || undefined,
    database: OLD_DB_NAME,
    charset: "utf8mb4",
  });

  try {
    // =========================================================
    // 1) ΚΑΤΗΓΟΡΙΕΣ
    // =========================================================
    console.log("[sync] Διαβάζω legacy κατηγορίες από MySQL.songs_categories...");

    const [catRows] = await mysqlConn.query(
      "SELECT Category_ID, Title AS Category FROM songs_categories ORDER BY Category_ID ASC",
    );
    const legacyCategories = catRows as LegacyCategoryRow[];

    console.log(
      `[sync] Βρέθηκαν ${legacyCategories.length} legacy κατηγορίες (songs_categories).`,
    );

    // Φέρνουμε ΟΛΕΣ τις Category από Postgres για να δούμε mapping id -> currentTitle
    const currentCategories = await prisma.category.findMany({
      select: { id: true, title: true },
      orderBy: { id: "asc" },
    });

    console.log(
      `[sync] Βρέθηκαν ${currentCategories.length} κατηγορίες στη Postgres (Category).`,
    );

    // Φτιάχνουμε map: id -> legacyTitle (από MySQL)
    const legacyCatTitleById = new Map<number, string>();
    for (const row of legacyCategories) {
      const id = row.Category_ID;
      const legacyTitle = (row.Category || "").trim();
      if (!legacyTitle) continue;
      legacyCatTitleById.set(id, legacyTitle);
    }

    // Log μόνο των αλλαγών που ΘΑ γίνουν
    let willUpdateCategories = 0;
    let missingCategories = 0;

    for (const cat of currentCategories) {
      const legacyTitle = legacyCatTitleById.get(cat.id);
      if (!legacyTitle) {
        console.warn(
          `[sync][Category] ΔΕΝ βρέθηκε legacy εγγραφή για id=${cat.id} (current="${cat.title}")`,
        );
        missingCategories++;
        continue;
      }

      if (cat.title === legacyTitle) {
        continue;
      }

      console.log(
        `[sync][Category] id=${cat.id}: "${cat.title}" -> "${legacyTitle}"`,
      );
      willUpdateCategories++;
    }

    console.log(
      `[sync] Σύνοψη Category: θα ενημερωθούν ${willUpdateCategories}, missing=${missingCategories}.`,
    );

    if (!DRY_RUN && willUpdateCategories > 0) {
      console.log(
        "[sync] === ΦΑΣΗ 1: Καθαρισμός τίτλων Category σε προσωρινούς μοναδικούς τίτλους... ===",
      );

      // ΦΑΣΗ 1: Βάζουμε προσωρινά titles για να μην έχουμε collisions στο UNIQUE(title)
      for (const cat of currentCategories) {
        const legacyTitle = legacyCatTitleById.get(cat.id);
        if (!legacyTitle) {
          continue; // δεν έχουμε legacy αντιστοίχιση, δεν αλλάζουμε
        }

        const tmpTitle = `__TMP_CAT_${cat.id}`;

        if (cat.title === tmpTitle) {
          // Αν τρέξει δεύτερη φορά, δεν χρειάζεται να το ξανακάνει
          continue;
        }

        console.log(
          `[sync][Category][TMP] id=${cat.id}: "${cat.title}" -> "${tmpTitle}"`,
        );

        await prisma.category.update({
          where: { id: cat.id },
          data: { title: tmpTitle },
        });
      }

      console.log(
        "[sync] === ΦΑΣΗ 2: Εφαρμογή τελικών legacy titles σε Category... ===",
      );

      // ΦΑΣΗ 2: Εφαρμόζουμε τους σωστούς legacy τίτλους
      for (const cat of currentCategories) {
        const legacyTitle = legacyCatTitleById.get(cat.id);
        if (!legacyTitle) {
          continue;
        }

        console.log(
          `[sync][Category][FINAL] id=${cat.id}: "${legacyTitle}"`,
        );

        await prisma.category.update({
          where: { id: cat.id },
          data: { title: legacyTitle },
        });
      }

      console.log("[sync] Ολοκληρώθηκε η 2-φασική ενημέρωση Category titles.");
    } else {
      console.log(
        "[sync] DRY_RUN=true ή δεν υπάρχουν αλλαγές στις Category – δεν εκτελούνται UPDATE.",
      );
    }

    // =========================================================
    // 2) ΡΥΘΜΟΙ
    // =========================================================
    console.log("[sync] Διαβάζω legacy ρυθμούς από MySQL.rythms...");

    const [rythmRows] = await mysqlConn.query(
      "SELECT Rythm_ID, Title AS Rythm FROM rythms ORDER BY Rythm_ID ASC",
    );
    const legacyRythms = rythmRows as LegacyRythmRow[];

    console.log(
      `[sync] Βρέθηκαν ${legacyRythms.length} legacy ρυθμοί (rythms).`,
    );

    const currentRythms = await prisma.rythm.findMany({
      select: { id: true, title: true },
      orderBy: { id: "asc" },
    });

    console.log(
      `[sync] Βρέθηκαν ${currentRythms.length} ρυθμοί στη Postgres (Rythm).`,
    );

    const legacyRythmTitleById = new Map<number, string>();
    for (const row of legacyRythms) {
      const id = row.Rythm_ID;
      const legacyTitle = (row.Rythm || "").trim();
      if (!legacyTitle) continue;
      legacyRythmTitleById.set(id, legacyTitle);
    }

    let willUpdateRythms = 0;
    let missingRythms = 0;

    for (const r of currentRythms) {
      const legacyTitle = legacyRythmTitleById.get(r.id);
      if (!legacyTitle) {
        console.warn(
          `[sync][Rythm] ΔΕΝ βρέθηκε legacy εγγραφή για id=${r.id} (current="${r.title}")`,
        );
        missingRythms++;
        continue;
      }
      if (r.title === legacyTitle) continue;

      console.log(
        `[sync][Rythm] id=${r.id}: "${r.title}" -> "${legacyTitle}"`,
      );
      willUpdateRythms++;
    }

    console.log(
      `[sync] Σύνοψη Rythm: θα ενημερωθούν ${willUpdateRythms}, missing=${missingRythms}.`,
    );

    if (!DRY_RUN && willUpdateRythms > 0) {
      console.log(
        "[sync] === Ενημέρωση Rythm titles σε ένα βήμα (συνήθως δεν υπάρχουν collisions)... ===",
      );

      for (const r of currentRythms) {
        const legacyTitle = legacyRythmTitleById.get(r.id);
        if (!legacyTitle) continue;

        console.log(
          `[sync][Rythm][FINAL] id=${r.id}: "${legacyTitle}"`,
        );

        await prisma.rythm.update({
          where: { id: r.id },
          data: { title: legacyTitle },
        });
      }

      console.log("[sync] Ολοκληρώθηκε η ενημέρωση Rythm titles.");
    } else {
      console.log(
        "[sync] DRY_RUN=true ή δεν υπάρχουν αλλαγές στους Rythm – δεν εκτελούνται UPDATE.",
      );
    }

    console.log(
      "[sync] ΤΕΛΟΣ: Κατηγορίες & ρυθμοί είναι πλέον ευθυγραμμισμένα με τα legacy IDs (id = Category_ID / Rythm_ID).",
    );
  } finally {
    await mysqlConn.end();
    await prisma.$disconnect();
  }
}

main().catch((err) => {
  console.error("[sync] ΣΦΑΛΜΑ:", err);
  process.exit(1);
});
