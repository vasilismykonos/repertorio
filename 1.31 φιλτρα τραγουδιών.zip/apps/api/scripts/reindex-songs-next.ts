// apps/api/scripts/reindex-app-songs-to-es.ts
//
// Ενημέρωση του index app_songs στο Elasticsearch
// ώστε να έχουν ΟΛΑ τα τραγούδια τα πεδία:
//   - category_id / categoryId
//   - rythm_id / rythmId
//
// Χωρίς να πειράξουμε τα υπόλοιπα πεδία (_source) των documents.
//
// ΤΡΕΧΕΙΣ:
//   cd apps/api
//   pnpm ts-node scripts/reindex-app-songs-to-es.ts

import "dotenv/config";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Bulk URL – αν κάνεις proxy μέσω nginx προς το ES, άλλαξέ το εδώ
const ES_BULK_URL =
  process.env.ES_SONGS_BULK_URL ??
  "http://localhost:9200/app_songs/_bulk";

type SongRecord = {
  id: number;
  // ΠΡΟΣΟΧΗ: φρόντισε τα ονόματα να ταιριάζουν με το Prisma schema σου
  categoryId: number | null;
  rythmId: number | null;
};

async function fetchSongsBatch(
  skip: number,
  take: number,
): Promise<SongRecord[]> {
  const songs = await prisma.song.findMany({
    skip,
    take,
    orderBy: { id: "asc" },
    select: {
      id: true,
      // Αν στο Prisma τα έχεις διαφορετικά (π.χ. category_id),
      // άλλαξέ τα εδώ και στον τύπο SongRecord.
      categoryId: true,
      rythmId: true,
    },
  });

  return songs as SongRecord[];
}

// Χτίζουμε bulk body με update + doc_as_upsert,
// ώστε να ενημερώνουμε ΜΟΝΟ τα πεδία category/rythm.
function buildBulkBody(songs: SongRecord[]): string {
  const lines: string[] = [];

  for (const s of songs) {
    lines.push(
      JSON.stringify({
        update: {
          _index: "app_songs",
          _id: s.id,
        },
      }),
    );

    const categoryId =
      typeof s.categoryId === "number" ? s.categoryId : null;
    const rythmId =
      typeof s.rythmId === "number" ? s.rythmId : null;

    const doc: any = {
      category_id: categoryId,
      categoryId: categoryId,
      rythm_id: rythmId,
      rythmId: rythmId,
    };

    lines.push(
      JSON.stringify({
        doc,
        doc_as_upsert: true,
      }),
    );
  }

  // Bulk API: χρειάζεται newline στο τέλος
  return lines.join("\n") + "\n";
}

async function sendBulkToEs(body: string): Promise<void> {
  const res = await fetch(ES_BULK_URL, {
    method: "POST",
    headers: {
      "content-type": "application/x-ndjson",
    },
    body,
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    console.error("[reindex] ES bulk error", res.status, text);
    throw new Error(`ES bulk error: ${res.status}`);
  }

  const data = await res.json().catch(() => null);
  if (data && data.errors) {
    console.error(
      "[reindex] ES bulk returned errors",
      JSON.stringify(data, null, 2),
    );
    throw new Error("ES bulk had item errors");
  }
}

async function main() {
  const BATCH = 500;

  const total = await prisma.song.count();
  console.log(`[reindex] Συνολικά τραγούδια: ${total}`);

  let skip = 0;

  while (skip < total) {
    console.log(`[reindex] Batch skip=${skip}, take=${BATCH}`);
    const songs = await fetchSongsBatch(skip, BATCH);
    if (songs.length === 0) break;

    const body = buildBulkBody(songs);
    await sendBulkToEs(body);

    skip += songs.length;
  }

  console.log(
    "[reindex] Ολοκληρώθηκε η ενημέρωση category_id / rythm_id στο app_songs",
  );
}

main()
  .catch((err) => {
    console.error("[reindex] Σφάλμα", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
