import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
} from "@nestjs/common";
import { ArtistsService } from "./artists.service";

type VersionArtistRoleString =
  | "SINGER_FRONT"
  | "SINGER_BACK"
  | "SOLOIST"
  | "MUSICIAN"
  | "COMPOSER"
  | "LYRICIST";

type UpdateArtistBody = {
  title?: string;
  firstName?: string | null;
  lastName?: string | null;
};

@Controller("artists")
export class ArtistsController {
  constructor(private readonly artistsService: ArtistsService) {}

  /**
   * GET /artists/search
   */
  @Get("search")
  async searchArtists(
    @Query("q") q?: string,
    @Query("skip") skipStr?: string,
    @Query("take") takeStr?: string,
    @Query("roles") rolesStr?: string,
  ) {
    const skip = Math.max(Number(skipStr) || 0, 0);
    const takeRaw = Number(takeStr) || 50;
    const take = Math.min(Math.max(takeRaw, 1), 200);

    const roles = (rolesStr ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean) as VersionArtistRoleString[];

    return this.artistsService.search({
      q: q?.trim() || undefined,
      skip,
      take,
      roles,
    });
  }

  /**
   * GET /artists/:id
   */
  @Get(":id")
  async getArtistById(@Param("id", ParseIntPipe) id: number) {
    return this.artistsService.findOne(id);
  }

  /**
   * PATCH /artists/:id
   */
  @Patch(":id")
  async updateArtist(
    @Param("id", ParseIntPipe) id: number,
    @Body() body: UpdateArtistBody,
  ) {
    return this.artistsService.updateArtist(id, body);
  }
}
