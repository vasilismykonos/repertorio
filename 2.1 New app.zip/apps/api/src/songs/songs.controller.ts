// apps/api/src/songs/songs.controller.ts
import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Query,
  NotFoundException,
  Res,
} from "@nestjs/common";
import { Response } from "express";
import { SongsService } from "./songs.service";
import { SongStatus } from "@prisma/client";

@Controller("songs")
export class SongsController {
  constructor(private readonly songsService: SongsService) {}

  // GET /songs/legacy/:legacyId => ανακατεύθυνση στο canonical Postgres id
  @Get("legacy/:legacyId")
  async redirectFromLegacy(
    @Param("legacyId", ParseIntPipe) legacyId: number,
    @Res() res: Response,
  ) {
    const song = await this.songsService.findByLegacySongId(legacyId);
    if (!song) {
      throw new NotFoundException(`Song with legacySongId=${legacyId} not found`);
    }
    return res.redirect(301, `/songs/${song.id}`);
  }

  // GET /songs/:id?noIncrement=1
  @Get(":id")
  async getSongById(
    @Param("id", ParseIntPipe) id: number,
    @Query("noIncrement") noIncrement?: string,
  ) {
    const skip = noIncrement === "1" || noIncrement === "true" || noIncrement === "yes";
    return this.songsService.findOne(id, skip);
  }

  // PATCH /songs/:id για ενημέρωση
  @Patch(":id")
  async updateSong(
    @Param("id", ParseIntPipe) id: number,
    @Body() body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      highestVocalNote?: string | null;
      chords?: string | null;
      status?: SongStatus;
      scoreFile?: string | null;
      categoryId?: number | null;
      rythmId?: number | null;
      basedOnSongId?: number | null;
    },
  ) {
    return this.songsService.updateSong(id, body);
  }
}
