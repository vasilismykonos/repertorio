// apps/api/src/songs/songs.service.ts
import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { SongStatus, SongCreditRole, VersionArtistRole } from "@prisma/client";

@Injectable()
export class SongsService {
  constructor(private readonly prisma: PrismaService) {}

  async findByLegacySongId(legacySongId: number): Promise<{ id: number } | null> {
    return this.prisma.song.findFirst({
      where: { legacySongId },
      select: { id: true },
    });
  }

  /**
   * Επιστροφή τραγουδιού (SongDetail).
   * Αν noIncrement=true δεν αυξάνει τα views.
   */
  async findOne(id: number, noIncrement = false): Promise<any> {
    const song = await this.prisma.song.findUnique({
      where: { id },
      include: {
        category: true,
        rythm: true,
        // πολλαπλές κατηγορίες (secondary)
        songCategories: { include: { category: true } },
        credits: { include: { artist: true } }, // COMPOSER/LYRICIST
        versions: {
          orderBy: { year: "asc" },
          include: {
            artists: { include: { artist: true } }, // SINGER_*, SOLOIST, MUSICIAN
          },
        },
      },
    });

    if (!song) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    // Αυξάνουμε views μόνο όταν noIncrement=false
    if (!noIncrement) {
      await this.prisma.song.update({
        where: { id },
        data: { views: (song.views ?? 0) + 1 },
      });
    }

    // Category titles
    const categoryTitle = song.category?.title ?? null;
    const rythmTitle = song.rythm?.title ?? null;

    // Πολλαπλοί συνθέτες/στιχουργοί
    const composerNames: string[] = [];
    const composerIds: number[] = [];
    const lyricistNames: string[] = [];
    const lyricistIds: number[] = [];

    for (const credit of song.credits) {
      const artist = credit.artist;
      const name = [artist.firstName, artist.lastName].filter(Boolean).join(" ") || artist.title;
      if (credit.role === SongCreditRole.COMPOSER) {
        composerNames.push(name);
        composerIds.push(artist.id);
      } else if (credit.role === SongCreditRole.LYRICIST) {
        lyricistNames.push(name);
        lyricistIds.push(artist.id);
      }
    }

    // basedOnSongId -> βρίσκουμε τον τίτλο
    let basedOnSongId: number | null = null;
    let basedOnSongTitle: string | null = null;
    if (song.basedOnSongId) {
      const baseSong = await this.prisma.song.findUnique({
        where: { id: song.basedOnSongId },
        select: { id: true, title: true },
      });
      if (baseSong) {
        basedOnSongId = baseSong.id;
        basedOnSongTitle = baseSong.title;
      }
    }

    // Εκτελέσεις
    const versions = song.versions.map((v) => {
      // Χωρίζουμε τους καλλιτέχνες ανά ρόλο
      const singerFront: string[] = [];
      const singerFrontIds: number[] = [];
      const singerBack: string[] = [];
      const singerBackIds: number[] = [];
      const solists: string[] = [];
      const solistIds: number[] = [];
      const musicians: string[] = [];
      const musicianIds: number[] = [];

      v.artists.forEach((va) => {
        const a = va.artist;
        const name = [a.firstName, a.lastName].filter(Boolean).join(" ") || a.title;
        switch (va.role) {
          case VersionArtistRole.SINGER_FRONT:
            singerFront.push(name);
            singerFrontIds.push(a.id);
            break;
          case VersionArtistRole.SINGER_BACK:
            singerBack.push(name);
            singerBackIds.push(a.id);
            break;
          case VersionArtistRole.SOLOIST:
            solists.push(name);
            solistIds.push(a.id);
            break;
          case VersionArtistRole.MUSICIAN:
            musicians.push(name);
            musicianIds.push(a.id);
            break;
        }
      });

      return {
        id: v.id,
        year: v.year ?? null,
        youtubeUrl: v.youtubeUrl ?? null,
        youtubeSearch: v.youtubeSearch ?? null,
        singerFront,
        singerFrontIds,
        singerBack,
        singerBackIds,
        solists,
        solistIds,
        musicians,
        musicianIds,
      };
    });

    // Υπολογισμός views (αν δεν αυξήσαμε)
    const views = noIncrement ? song.views ?? 0 : (song.views ?? 0) + 1;

    // Παραγωγή DTO
    return {
      id: song.id,
      legacySongId: song.legacySongId ?? null,
      slug: song.slug,
      title: song.title,
      firstLyrics: song.firstLyrics,
      lyrics: song.lyrics,
      characteristics: song.characteristics,
      originalKey: song.originalKey,
      defaultKey: song.defaultKey,
      highestVocalNote: song.highestVocalNote,
      chords: song.chords,
      scoreFile: song.scoreFile,
      status: song.status,
      categoryId: song.categoryId ?? null,
      rythmId: song.rythmId ?? null,
      // δευτερεύουσες κατηγορίες
      categoryTitle,
      rythmTitle,

      composerNames,
      composerIds,
      lyricistNames,
      lyricistIds,

      basedOnSongId,
      basedOnSongTitle,

      views,
      // Πλήρης λίστα εκτελέσεων
      versions,
    };
  }

  /**
   * Ενημέρωση τραγουδιού.
   * Δέχεται μόνο συγκεκριμένα πεδία και επιστρέφει πάλι το SongDetail.
   * Τα enum status πρέπει να είναι valid SongStatus.
   */
  async updateSong(
    id: number,
    body: {
      title?: string;
      firstLyrics?: string | null;
      lyrics?: string | null;
      characteristics?: string | null;
      originalKey?: string | null;
      defaultKey?: string | null;
      highestVocalNote?: string | null;
      chords?: string | null;
      status?: SongStatus;
      scoreFile?: string | null;
      categoryId?: number | null;
      rythmId?: number | null;
      basedOnSongId?: number | null;
    },
  ) {
    const exists = await this.prisma.song.findUnique({ where: { id }, select: { id: true } });
    if (!exists) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    const data: any = {};
    if (body.title !== undefined) data.title = body.title;
    if ("firstLyrics" in body) data.firstLyrics = body.firstLyrics;
    if ("lyrics" in body) data.lyrics = body.lyrics;
    if ("characteristics" in body) data.characteristics = body.characteristics;
    if ("originalKey" in body) data.originalKey = body.originalKey;
    if ("defaultKey" in body) data.defaultKey = body.defaultKey;
    if ("highestVocalNote" in body) data.highestVocalNote = body.highestVocalNote;
    if ("chords" in body) data.chords = body.chords;
    if (body.status && Object.values(SongStatus).includes(body.status)) {
      data.status = body.status;
    }
    if ("scoreFile" in body) data.scoreFile = body.scoreFile;
    if ("categoryId" in body) data.categoryId = body.categoryId;
    if ("rythmId" in body) data.rythmId = body.rythmId;
    if ("basedOnSongId" in body) data.basedOnSongId = body.basedOnSongId;

    if (Object.keys(data).length > 0) {
      await this.prisma.song.update({ where: { id }, data });
    }

    return this.findOne(id, true);
  }
}
