import { Module } from "@nestjs/common";
import { SongsService } from "./songs.service";
import { SongsController } from "./songs.controller";
import { ElasticSongsController } from "./elastic-songs.controller";
import { SongsSearchController } from "./songs-search.controller";
import { SongsSearchService } from "./songs-search.service";
import { PrismaService } from "../prisma/prisma.service";

import { SongCreditsController } from "./song-credits.controller";
import { SongCreditsService } from "./song-credits.service";

@Module({
  controllers: [
    SongsSearchController,
    ElasticSongsController,
    SongsController,
    SongCreditsController,
  ],
  providers: [SongsService, SongsSearchService, SongCreditsService, PrismaService],
})
export class SongsModule {}
