"use client";

import React, { useState } from "react";
import FilterSelectWithSearch, { Option } from "./FilterSelectWithSearch";

type CountMap = Record<string, number>;

type Props = {
  q: string;
  take: number;
  skip: number;

  chords: string;
  partiture: string;
  category_id: string;
  rythm_id: string;
  characteristics: string;
  lyrics: string;
  status: string;
  popular: string;
  createdByUserId: string;

  categoryOptions: Option[];
  rythmOptions: Option[];
  characteristicsOptions: Option[];

  chordsCounts: CountMap;
  partitureCounts: CountMap;
  lyricsCounts: CountMap;
  statusCounts: CountMap;

  onChangeFilters: (patch: {
    chords?: string;
    partiture?: string;
    category_id?: string;
    rythm_id?: string;
    characteristics?: string;
    lyrics?: string;
    status?: string;
    popular?: string;
    createdByUserId?: string;
  }) => void;
};

function parseCsvToSet(value: string): Set<string> {
  if (!value) return new Set<string>();
  return new Set(
    value
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean),
  );
}

function toggleCsvValue(current: string, value: string): string {
  const set = new Set(
    (current || "")
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean),
  );
  if (set.has(value)) set.delete(value);
  else set.add(value);
  return Array.from(set).join(",");
}

const sectionStyle: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: 4,
  marginBottom: 12,
};

const labelStyle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 600,
  color: "#ddd",
};

const smallCount = (val: string, map: CountMap) =>
  typeof map[val] === "number" ? ` (${map[val]})` : " (0)";

export default function FiltersModal({
  q,
  take,
  skip,
  chords,
  partiture,
  category_id,
  rythm_id,
  characteristics,
  lyrics,
  status,
  popular,
  createdByUserId,
  categoryOptions,
  rythmOptions,
  characteristicsOptions,
  chordsCounts,
  partitureCounts,
  lyricsCounts,
  statusCounts,
  onChangeFilters,
}: Props) {
  const [open, setOpen] = useState(false);

  const chordsSet = parseCsvToSet(chords);
  const partitureSet = parseCsvToSet(partiture);
  const lyricsSet = parseCsvToSet(lyrics);
  const statusSet = parseCsvToSet(status);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const form = e.currentTarget;
    const fd = new FormData(form);

    const getMultiCsv = (key: string) => {
      const all = fd.getAll(key);
      return all
        .map((v) => v.toString().trim())
        .filter(Boolean)
        .join(",");
    };

    const getSingle = (key: string) =>
      (fd.get(key) ?? "").toString().trim();

    const patch: {
      chords?: string;
      partiture?: string;
      lyrics?: string;
      status?: string;
      category_id?: string;
      rythm_id?: string;
      characteristics?: string;
      popular?: string;
      createdByUserId?: string;
    } = {};

    const chordsCsv = getMultiCsv("chords");
    if (chordsCsv) patch.chords = chordsCsv;

    const partitureCsv = getMultiCsv("partiture");
    if (partitureCsv) patch.partiture = partitureCsv;

    const lyricsCsv = getMultiCsv("lyrics");
    if (lyricsCsv) patch.lyrics = lyricsCsv;

    const statusCsv = getMultiCsv("status");
    if (statusCsv) patch.status = statusCsv;

    const popularVal = getSingle("popular");
    patch.popular = popularVal === "1" ? "1" : "";

    const categoryCsv = getSingle("category_id");
    patch.category_id = categoryCsv;

    const rythmCsv = getSingle("rythm_id");
    patch.rythm_id = rythmCsv;

    const characteristicsCsv = getSingle("characteristics");
    patch.characteristics = characteristicsCsv;

    const createdByVal = getSingle("createdByUserId");
    patch.createdByUserId = createdByVal;

    onChangeFilters(patch);
    setOpen(false); // κλείνει μόνο με "Εφαρμογή φίλτρων"
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          padding: "6px 10px",
          borderRadius: 16,
          border: "1px solid #666",
          backgroundColor: "#111",
          color: "#fff",
          fontSize: "0.9rem",
          cursor: "pointer",
        }}
        title="Φίλτρα αναζήτησης"
      >
        <span
          style={{
            display: "inline-block",
            width: 16,
            height: 16,
            borderRadius: 4,
            border: "2px solid #fff",
            boxSizing: "border-box",
          }}
        />
        <span>Φίλτρα</span>
      </button>

      {open && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "rgba(0,0,0,0.7)",
            zIndex: 5000,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
          onClick={() => setOpen(false)}
        >
          <div
            style={{
              width: "95%",
              maxWidth: 300,
              maxHeight: "90vh",
              backgroundColor: "#000",
              borderRadius: 10,
              border: "1px solid #444",
              padding: 16,
              overflowY: "auto",
              overflowX: "hidden",
              boxSizing: "border-box",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <h2 style={{ fontSize: "1.2rem", margin: 0 }}>
                Φίλτρα αναζήτησης τραγουδιών
              </h2>
              <button
                type="button"
                onClick={() => setOpen(false)}
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#fff",
                  fontSize: "1.2rem",
                  cursor: "pointer",
                }}
              >
                ✖
              </button>
            </div>

            <form
              onSubmit={handleSubmit}
              style={{ display: "flex", flexDirection: "column", gap: 8 }}
            >
              <input type="hidden" name="search_term" value={q} />
              <input type="hidden" name="take" value={String(take)} />

              {/* Συγχορδίες */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Συγχορδίες</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="chords"
                    value="1"
                    checked={chordsSet.has("1")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(chords, "1");
                      onChangeFilters({ chords: next });
                    }}
                  />
                  <span>
                    Με συγχορδίες
                    {smallCount("1", chordsCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="chords"
                    value="0"
                    checked={chordsSet.has("0")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(chords, "0");
                      onChangeFilters({ chords: next });
                    }}
                  />
                  <span>
                    Χωρίς συγχορδίες
                    {smallCount("0", chordsCounts)}
                  </span>
                </label>
              </div>

              {/* Παρτιτούρα */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Παρτιτούρα</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="partiture"
                    value="1"
                    checked={partitureSet.has("1")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(partiture, "1");
                      onChangeFilters({ partiture: next });
                    }}
                  />
                  <span>
                    Με παρτιτούρα
                    {smallCount("1", partitureCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="partiture"
                    value="0"
                    checked={partitureSet.has("0")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(partiture, "0");
                      onChangeFilters({ partiture: next });
                    }}
                  />
                  <span>
                    Χωρίς παρτιτούρα
                    {smallCount("0", partitureCounts)}
                  </span>
                </label>
              </div>

              {/* Δημοφιλή */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Δημοφιλία</span>
                <label
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "4px 8px",
                    borderRadius: 4,
                    border: "1px solid #555",
                    backgroundColor: "#000",
                    color: "#fff",
                    fontSize: 13,
                    boxSizing: "border-box",
                    width: "fit-content",
                  }}
                >
                  <input
                    type="checkbox"
                    name="popular"
                    value="1"
                    checked={popular === "1"}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = popular === "1" ? "" : "1";
                      onChangeFilters({ popular: next });
                    }}
                  />
                  <span>⭐ Δημοφιλή (περισσότερες προβολές πρώτα)</span>
                </label>
              </div>

              {/* Κατηγορία */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Κατηγορία</span>
                <FilterSelectWithSearch
                  name="category_id"
                  options={categoryOptions}
                  selectedValue={category_id}
                  onChangeCsv={(csv) => onChangeFilters({ category_id: csv })}
                />
              </div>

              {/* Ρυθμός */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Ρυθμός</span>
                <FilterSelectWithSearch
                  name="rythm_id"
                  options={rythmOptions}
                  selectedValue={rythm_id}
                  onChangeCsv={(csv) => onChangeFilters({ rythm_id: csv })}
                />
              </div>

              {/* Χαρακτηριστικά */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Χαρακτηριστικά</span>
                <FilterSelectWithSearch
                  name="characteristics"
                  options={characteristicsOptions}
                  selectedValue={characteristics}
                  onChangeCsv={(csv) =>
                    onChangeFilters({ characteristics: csv })
                  }
                />
              </div>

              {/* Στίχοι */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Στίχοι</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="lyrics"
                    value="null"
                    checked={lyricsSet.has("null")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(lyrics, "null");
                      onChangeFilters({ lyrics: next });
                    }}
                  />
                  <span>
                    Μόνο χωρίς στίχους
                    {smallCount("null", lyricsCounts)}
                  </span>
                </label>
              </div>

              {/* Κατάσταση */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Κατάσταση</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="PUBLISHED"
                    checked={statusSet.has("PUBLISHED")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(status, "PUBLISHED");
                      onChangeFilters({ status: next });
                    }}
                  />
                  <span>
                    PUBLISHED
                    {smallCount("PUBLISHED", statusCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="PENDING_APPROVAL"
                    checked={statusSet.has("PENDING_APPROVAL")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(
                        status,
                        "PENDING_APPROVAL",
                      );
                      onChangeFilters({ status: next });
                    }}
                  />
                  <span>
                    PENDING_APPROVAL
                    {smallCount("PENDING_APPROVAL", statusCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="DRAFT"
                    checked={statusSet.has("DRAFT")}
                    style={{ margin: 0 }}
                    onChange={() => {
                      const next = toggleCsvValue(status, "DRAFT");
                      onChangeFilters({ status: next });
                    }}
                  />
                  <span>
                    DRAFT
                    {smallCount("DRAFT", statusCounts)}
                  </span>
                </label>
              </div>

              {/* User ID δημιουργού */}
              <div style={sectionStyle}>
                <label style={labelStyle} htmlFor="filter-createdByUserId">
                  User ID δημιουργού
                </label>
                <input
                  id="filter-createdByUserId"
                  type="number"
                  name="createdByUserId"
                  placeholder="π.χ. 123"
                  defaultValue={createdByUserId}
                  style={{
                    width: "100%",
                    padding: "4px 8px",
                    borderRadius: 4,
                    border: "1px solid #555",
                    backgroundColor: "#000",
                    color: "#fff",
                    height: 36,
                    boxSizing: "border-box",
                  }}
                />
              </div>

              {/* Κουμπιά */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: 8,
                  marginTop: 8,
                }}
              >
                <button
                  type="button"
                  onClick={() => {
                    onChangeFilters({
                      chords: "",
                      partiture: "",
                      category_id: "",
                      rythm_id: "",
                      characteristics: "",
                      lyrics: "",
                      status: "",
                      popular: "",
                      createdByUserId: "",
                    });
                    setOpen(false);
                  }}
                  style={{
                    padding: "6px 10px",
                    borderRadius: 4,
                    border: "1px solid #666",
                    backgroundColor: "#111",
                    color: "#fff",
                    fontSize: "0.9rem",
                    cursor: "pointer",
                  }}
                >
                  ✖ Καθαρισμός
                </button>

                <button
                  type="submit"
                  style={{
                    padding: "6px 12px",
                    borderRadius: 4,
                    border: "1px solid #777",
                    backgroundColor: "#222",
                    color: "#fff",
                    cursor: "pointer",
                    fontSize: "0.9rem",
                  }}
                >
                  🔍 Εφαρμογή φίλτρων
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
