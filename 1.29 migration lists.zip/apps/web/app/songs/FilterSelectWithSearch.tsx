"use client";

import React, { useMemo, useState } from "react";

export type Option = {
  value: string;
  label: string;
  count?: number; // πλήθος για εμφάνιση δίπλα
};

type Props = {
  name: string;
  options: Option[];
  selectedValue?: string;
};

function parseCsvToSet(value?: string): Set<string> {
  if (!value) return new Set<string>();
  return new Set(
    value
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean),
  );
}

export default function FilterSelectWithSearch({
  name,
  options,
  selectedValue,
}: Props) {
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(
    () => parseCsvToSet(selectedValue),
  );

  const MAX_VISIBLE = 10;
  // Συνολικό "budget" χαρακτήρων για label + κενό + "(123)"
  const MAX_TOTAL_CHARS = 32;

  const filteredOptions = useMemo(() => {
    if (!search.trim()) return options;
    const lower = search.toLowerCase();
    return options.filter((opt) =>
      opt.label.toLowerCase().includes(lower),
    );
  }, [options, search]);

  const visibleOptions = useMemo(() => {
    if (showAll) return filteredOptions;
    return filteredOptions.slice(0, MAX_VISIBLE);
  }, [filteredOptions, showAll]);

  const hasMore = filteredOptions.length > visibleOptions.length;

  const hiddenValue = useMemo(
    () => Array.from(selected).join(","),
    [selected],
  );

  const toggleValue = (value: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(value)) {
        next.delete(value);
      } else {
        next.add(value);
      }
      return next;
    });
  };

  return (
    <div
      style={{
        borderRadius: 4,
        border: "1px solid #555",
        backgroundColor: "#000",
        padding: 6,
      }}
    >
      {/* Κρυφό πεδίο με CSV επιλογών */}
      <input type="hidden" name={name} value={hiddenValue} />

      {/* Search – εμφανίζεται όταν υπάρχουν > 10 επιλογές */}
      {options.length > 10 && (
        <input
          type="text"
          placeholder="Αναζήτηση..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            width: "100%",
            padding: "4px 6px",
            marginBottom: 6,
            borderRadius: 3,
            border: "1px solid #555",
            backgroundColor: "#111",
            color: "#fff",
            fontSize: 12,
            boxSizing: "border-box",
          }}
        />
      )}

      {/* Λίστα επιλογών (checkbox) */}
      <div>
        {visibleOptions.length === 0 && (
          <div
            style={{
              fontSize: 12,
              color: "#aaa",
              padding: "2px 0",
            }}
          >
            Δεν βρέθηκαν επιλογές.
          </div>
        )}

        {visibleOptions.map((opt) => {
          const isChecked = selected.has(opt.value);
          const count =
            typeof opt.count === "number" && !Number.isNaN(opt.count)
              ? opt.count
              : undefined;
          const countText = count !== undefined ? `(${count})` : "";

          // Υπολογισμός label με "..." ώστε να χωράει ΚΑΙ το (count)
          let truncatedLabel = opt.label;
          const extraChars = countText ? 1 + countText.length : 0; // κενό + "(xx)"
          const maxLabelChars = MAX_TOTAL_CHARS - extraChars;

          if (maxLabelChars > 3 && truncatedLabel.length > maxLabelChars) {
            truncatedLabel =
              truncatedLabel.slice(0, maxLabelChars - 3) + "...";
          }

          return (
            <label
              key={opt.value}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                marginBottom: 2,
                fontSize: 12,
                color: "#fff",
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={isChecked}
                onChange={() => toggleValue(opt.value)}
                style={{ margin: 0 }}
              />

              {/* Κείμενο + πλήθος σε δύο "στήλες" */}
              <span
                style={{
                  display: "flex",
                  alignItems: "center",
                  width: "100%",
                  gap: 6,
                  minWidth: 0,
                }}
              >
                {/* Αριστερά: label με 3 τελείες όπου χρειάζεται */}
                <span
                  style={{
                    flex: 1,
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                    overflow: "hidden",
                  }}
                  title={opt.label}
                >
                  {truncatedLabel}
                </span>

                {/* Δεξιά: (count) ΠΑΝΤΑ ορατό, ποτέ δεν κόβεται */}
                {count !== undefined && (
                  <span
                    style={{
                      whiteSpace: "nowrap",
                      flexShrink: 0,
                      opacity: 0.85,
                    }}
                  >
                    {countText}
                  </span>
                )}
              </span>
            </label>
          );
        })}
      </div>

      {/* Περισσότερα / Λιγότερα */}
      {hasMore && (
        <button
          type="button"
          onClick={() => setShowAll((prev) => !prev)}
          style={{
            marginTop: 4,
            padding: "2px 6px",
            borderRadius: 3,
            border: "1px solid #555",
            backgroundColor: "#111",
            color: "#fff",
            fontSize: 11,
            cursor: "pointer",
          }}
        >
          {showAll ? "Λιγότερα" : "Περισσότερα..."}
        </button>
      )}
    </div>
  );
}
