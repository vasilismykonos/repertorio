// scripts/migrate-artist-details.ts
//
// Σκοπός:
// --------
// Να φέρουμε από το ΠΑΛΙΟ MySQL (πίνακας `artists`) τα πεδία:
//   - FirstName, LastName
//   - BornYear, DieYear
//   - Image
//   - Biography
//   - WiKi
// και να ενημερώσουμε τον πίνακα "Artist" στην Postgres
// (μοντέλο Prisma Artist) με βάση το legacyArtistId = Artist_ID.
//
// Προαπαιτούμενα στο .env του apps/api:
//   OLD_DB_HOST, OLD_DB_PORT, OLD_DB_USER, OLD_DB_PASSWORD, OLD_DB_NAME

import "dotenv/config";
import mysql from "mysql2/promise";
import { PrismaClient, Prisma } from "@prisma/client";

const prisma = new PrismaClient();

type LegacyArtistRow = {
  Artist_ID: number;
  FirstName: string | null;
  LastName: string | null;
  BornYear: number | null;
  DieYear: number | null;
  Image: string | null;
  Biography: string | null;
  WiKi: string | null;
};

async function main() {
  console.log("=============================================");
  console.log("[*] Εκκίνηση migrate-artist-details.ts");
  console.log("=============================================");

  const {
    OLD_DB_HOST,
    OLD_DB_PORT,
    OLD_DB_USER,
    OLD_DB_PASSWORD,
    OLD_DB_NAME,
  } = process.env;

  if (!OLD_DB_HOST || !OLD_DB_USER || !OLD_DB_NAME) {
    throw new Error(
      "Λείπουν κάποια από τα OLD_DB_* env vars (OLD_DB_HOST, OLD_DB_USER, OLD_DB_NAME)."
    );
  }

  const mysqlConn = await mysql.createConnection({
    host: OLD_DB_HOST,
    port: OLD_DB_PORT ? Number(OLD_DB_PORT) : 3306,
    user: OLD_DB_USER,
    password: OLD_DB_PASSWORD,
    database: OLD_DB_NAME,
    charset: "utf8mb4_general_ci",
  });

  console.log("[*] Συνδέθηκα στο MySQL (παλιό repertorio).");

  const [rowsRaw] = await mysqlConn.execute(
    `
    SELECT
      Artist_ID,
      FirstName,
      LastName,
      BornYear,
      DieYear,
      Image,
      Biography,
      WiKi
    FROM artists
    `
  );

  const rows = rowsRaw as LegacyArtistRow[];

  console.log(`[*] Βρέθηκαν ${rows.length} καλλιτέχνες στο MySQL.`);

  let updated = 0;
  let skippedNoLegacy = 0;
  let skippedNoArtist = 0;
  let skippedNoChanges = 0;

  for (const row of rows) {
    const legacyId = row.Artist_ID;

    if (!legacyId || legacyId <= 0) {
      skippedNoLegacy++;
      continue;
    }

    const firstName = row.FirstName ? String(row.FirstName).trim() : null;
    const lastName = row.LastName ? String(row.LastName).trim() : null;

    const bornYear =
      row.BornYear !== null && row.BornYear !== undefined
        ? Number(row.BornYear)
        : null;
    const dieYear =
      row.DieYear !== null && row.DieYear !== undefined
        ? Number(row.DieYear)
        : null;

    const imageUrl = row.Image ? String(row.Image).trim() : null;
    const biography = row.Biography ? String(row.Biography).trim() : null;
    const wikiUrl = row.WiKi ? String(row.WiKi).trim() : null;

    const existing = await prisma.artist.findFirst({
      where: { legacyArtistId: legacyId },
    });

    if (!existing) {
      console.warn(
        `[!] Δεν βρέθηκε Artist στην Postgres με legacyArtistId=${legacyId} – παράλειψη.`
      );
      skippedNoArtist++;
      continue;
    }

    const data: Prisma.ArtistUpdateInput = {};

    if (firstName && firstName.length > 0) {
      data.firstName = firstName;
    }
    if (lastName && lastName.length > 0) {
      data.lastName = lastName;
    }
    if (bornYear !== null && !Number.isNaN(bornYear)) {
      data.bornYear = bornYear;
    }
    if (dieYear !== null && !Number.isNaN(dieYear)) {
      data.dieYear = dieYear;
    }
    if (imageUrl && imageUrl.length > 0) {
      data.imageUrl = imageUrl;
    }
    if (biography && biography.length > 0) {
      data.biography = biography;
    }
    if (wikiUrl && wikiUrl.length > 0) {
      data.wikiUrl = wikiUrl;
    }

    if (Object.keys(data).length === 0) {
      skippedNoChanges++;
      continue;
    }

    try {
      await prisma.artist.update({
        where: { id: existing.id },
        data,
      });
      updated++;
    } catch (err) {
      console.error(
        `[ΣΦΑΛΜΑ] Αποτυχία update Artist (id=${existing.id}, legacyArtistId=${legacyId}):`,
        err
      );
    }
  }

  await mysqlConn.end();
  await prisma.$disconnect();

  console.log("=============================================");
  console.log("[OK] migrate-artist-details ολοκληρώθηκε.");
  console.log(`[*] Ενημερώθηκαν καλλιτέχνες: ${updated}`);
  console.log(`[*] Παραλείφθηκαν (χωρίς legacyId): ${skippedNoLegacy}`);
  console.log(`[*] Παραλείφθηκαν (δεν βρέθηκε Artist): ${skippedNoArtist}`);
  console.log(
    `[*] Παραλείφθηκαν (δεν υπήρχαν νέα δεδομένα για ενημέρωση): ${skippedNoChanges}`
  );
  console.log("=============================================");
}

main().catch((err) => {
  console.error("[FATAL] Σφάλμα στο migrate-artist-details:", err);
  process.exit(1);
});
