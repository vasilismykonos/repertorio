// apps/api/scripts/migrate-lists.ts
//
// Migration από την παλιά MySQL (group_lists, lists, lists_items)
// στα νέα Prisma models: ListGroup, List, ListItem.
//
// Χρησιμοποιεί env:
//   OLD_DB_HOST, OLD_DB_PORT, OLD_DB_USER, OLD_DB_PASSWORD, OLD_DB_NAME
//
// ΠΡΙΝ ΤΟ ΤΡΕΞΕΙΣ:
//   - Prisma migrate έχει τρέξει (υπάρχουν ListGroup, List, ListItem στην Postgres).
//   - Το .env έχει σωστά DATABASE_URL + OLD_DB_*.

import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import mysql from "mysql2/promise";

const prisma = new PrismaClient();

// --------------------------------------------------
// Τύποι που ταιριάζουν ΑΚΡΙΒΩΣ στα DESCRIBE της MySQL
// --------------------------------------------------

type MySqlGroupRow = {
  Group_List_ID: number;
  Title: string | null;
  Date_Created: string | null;
  Useremail: string | null;
  View: string | null;
  Edit: string | null;
  Count_Related_Lists: number | null;
  FullTitle: string | null;
  UserID: number | null;
  New_View: string | null;
  New_Edit: string | null;
};

type MySqlListRow = {
  List_ID: number;
  Emoji: string | null;
  Title: string | null;
  Date_Created: string | null;
  Useremail1: string | null;
  Group_List_ID: string | null; // varchar(255)
  View1: string | null;
  Edit1: string | null;
  Count_ListItems: number | null;
  json_data: string | null;
  FullTitle: string | null;
  Marked: number | null;
  UserID: number | null;
  View: string | null;
  Edit: string | null;
};

type MySqlListItemRow = {
  ListItem_ID: number;
  List_ID: number;
  Sort_ID: number | null;
  Date_Created: string | null;
  Default_Tune: string | null;
  Transport: string | null; // varchar(4)
  EditTimestamp: string | null;
  Tune_Scale_ID: string | null;
  SongTitle: string | null;
  Color: string | null;
  Notes: string | null;
  Tune: string | null;
  Song_ID: number | null;
  Title: string | null;
  Chords: string | null;
  Rythm_ID: number | null;
  Lyrics: string | null;
  UserID: number | null;
};

// Δημιουργία σύνδεσης στη legacy MySQL
async function getLegacyConnection() {
  const host = process.env.OLD_DB_HOST || "localhost";
  const port = Number(process.env.OLD_DB_PORT || "3306");
  const user = process.env.OLD_DB_USER || "root";
  const password = process.env.OLD_DB_PASSWORD || "";
  const database = process.env.OLD_DB_NAME || "repertorio.net";

  console.log("[MySQL] Connecting to", {
    host,
    port,
    database,
    user,
  });

  return mysql.createConnection({
    host,
    port,
    user,
    password,
    database,
    charset: "utf8mb4",
  });
}

async function migrateLists() {
  const conn = await getLegacyConnection();

  try {
    // --------------------------------------------------
    // 0) Καθαρίζουμε υπάρχοντα δεδομένα Lists στη Postgres
    // --------------------------------------------------
    console.log("[Postgres] Clearing existing ListItem, List, ListGroup data...");
    await prisma.listItem.deleteMany();
    await prisma.list.deleteMany();
    await prisma.listGroup.deleteMany();

    // --------------------------------------------------
    // 1) group_lists → ListGroup
    // --------------------------------------------------
    console.log("[MySQL] Fetching group_lists...");
    const [groupRowsRaw] = await conn.query(
      `
      SELECT
        Group_List_ID,
        Title,
        FullTitle,
        UserID,
        View,
        Edit
      FROM group_lists
    `
    );

    const groupRows = groupRowsRaw as MySqlGroupRow[];
    console.log(`[MySQL] group_lists rows: ${groupRows.length}`);

    const groupIdMap = new Map<number, number>(); // legacy Group_List_ID → new ListGroup.id

    for (const g of groupRows) {
      const legacyId = g.Group_List_ID;
      const title =
        (g.Title || "").trim() ||
        (g.FullTitle || "").trim() ||
        `Group ${legacyId}`;

      const created = await prisma.listGroup.create({
        data: {
          legacyId,
          title,
          fullTitle: (g.FullTitle || "").trim() || null,
          ownerWpId: g.UserID ?? null,
          // Χρησιμοποιούμε τα View/Edit ως viewWpIds/editWpIds όπως είναι
          viewWpIds: g.View || null,
          editWpIds: g.Edit || null,
        },
      });

      groupIdMap.set(legacyId, created.id);
    }

    console.log(
      `[Postgres] Created ${groupIdMap.size} ListGroup records from group_lists`
    );

    // --------------------------------------------------
    // 2) lists → List
    // --------------------------------------------------
    console.log("[MySQL] Fetching lists...");
    const [listRowsRaw] = await conn.query(
      `
      SELECT
        List_ID,
        Title,
        Group_List_ID,
        UserID,
        Marked,
        View,
        Edit,
        Emoji,
        FullTitle
      FROM lists
    `
    );

    const listRows = listRowsRaw as MySqlListRow[];
    console.log(`[MySQL] lists rows: ${listRows.length}`);

    const listIdMap = new Map<number, number>(); // legacy List_ID → new List.id

    for (const l of listRows) {
      const legacyId = l.List_ID;
      const title = (l.Title || "").trim() || `List ${legacyId}`;

      // Group_List_ID είναι varchar(255) -> μετατροπή σε number αν γίνεται
      let groupId: number | null = null;
      if (l.Group_List_ID != null && l.Group_List_ID !== "") {
        const legacyGroupId = parseInt(l.Group_List_ID, 10);
        if (!Number.isNaN(legacyGroupId)) {
          const mapped = groupIdMap.get(legacyGroupId);
          if (mapped) {
            groupId = mapped;
          }
        }
      }

      const marked =
        l.Marked != null
          ? Boolean(l.Marked)
          : false;

      const created = await prisma.list.create({
        data: {
          legacyId,
          title,
          groupId,
          ownerWpId: l.UserID ?? null,
          // εδώ οι νέες στήλες View / Edit
          viewWpIds: l.View || null,
          editWpIds: l.Edit || null,
          marked,
        },
      });

      listIdMap.set(legacyId, created.id);
    }

    console.log(
      `[Postgres] Created ${listIdMap.size} List records from lists`
    );

    // --------------------------------------------------
    // 3) lists_items → ListItem
    // --------------------------------------------------
    console.log("[MySQL] Fetching lists_items...");
    const [itemRowsRaw] = await conn.query(
      `
      SELECT
        ListItem_ID,
        List_ID,
        Song_ID,
        Sort_ID,
        Notes,
        Transport,
        Title,
        Chords,
        Lyrics
      FROM lists_items
      ORDER BY List_ID, Sort_ID, ListItem_ID
    `
    );

    const itemRows = itemRowsRaw as MySqlListItemRow[];
    console.log(`[MySQL] lists_items rows: ${itemRows.length}`);

    let createdItems = 0;
    let skippedNoList = 0;
    let matchedSongs = 0;
    let unmatchedSongs = 0;

    for (const it of itemRows) {
      const legacyListId = it.List_ID;
      const targetListId = listIdMap.get(legacyListId);

      if (!targetListId) {
        // Δεν βρέθηκε αντίστοιχη List στο Postgres
        skippedNoList++;
        continue;
      }

      // Εύρεση αντίστοιχου Song στο Postgres μέσω legacySongId
      let songId: number | null = null;
      if (it.Song_ID != null) {
        const song = await prisma.song.findFirst({
          where: { legacySongId: it.Song_ID },
          select: { id: true },
        });

        if (song) {
          songId = song.id;
          matchedSongs++;
        } else {
          unmatchedSongs++;
        }
      }

      const sortId = it.Sort_ID ?? 0;

      // Transport είναι varchar → μετατροπή σε number
      let transport = 0;
      if (it.Transport != null && it.Transport !== "") {
        const t = parseInt(it.Transport, 10);
        if (!Number.isNaN(t)) {
          transport = t;
        }
      }

      const title =
        (it.Title || "").trim() || `Item ${it.ListItem_ID}`;

      await prisma.listItem.create({
        data: {
          legacyId: it.ListItem_ID,
          listId: targetListId,
          sortId,
          notes: it.Notes || null,
          transport,
          title,
          chords: it.Chords || null,
          lyrics: it.Lyrics || null,
          songId,
        },
      });

      createdItems++;
    }

    console.log(
      `[Postgres] Created ${createdItems} ListItem records from lists_items`
    );
    console.log(
      `[Postgres] Song mapping: matched=${matchedSongs}, unmatched=${unmatchedSongs}, skipped (no list)=${skippedNoList}`
    );

    console.log("✅ Migration lists completed successfully.");
  } finally {
    await conn.end().catch(() => {});
    await prisma.$disconnect();
  }
}

migrateLists().catch((err) => {
  console.error("❌ Migration failed:", err);
  process.exit(1);
});

