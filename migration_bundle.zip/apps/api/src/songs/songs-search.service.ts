// apps/api/src/songs/songs-search.service.ts
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { Prisma, SongStatus } from "@prisma/client";

export type SearchParams = {
  q?: string;
  skip: number;
  take: number;

  createdByUserId?: number;

  // Φίλτρα όπως στο /songs page
  chords?: string; // "1" | "0" | "null"
  partiture?: string; // "1" | "0" | "null"
  categoryIds?: number[]; // από query param category_id=1,2,3
  rythmIds?: number[]; // από query param rythm_id=1,2,3
  characteristics?: string;
  lyricsFlag?: string; // "null" => μόνο χωρίς στίχους
  status?: string; // SongStatus ή "null"
  popular?: string; // "1" => sort by views desc
};

export type SongSearchItem = {
  // ✅ canonical Postgres id (αυτό πρέπει να χρησιμοποιεί το frontend στα URLs)
  id: number;

  // ✅ legacy id μόνο για συμβατότητα/πληροφόρηση
  legacySongId: number | null;

  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number | string | boolean | null;
  partiture: number | string | boolean | null;
  status: string;
  score: number;
  views: number | null;

  // για τα counts των φίλτρων στο frontend
  categoryId: number | null;
  rythmId: number | null;
};

export type SongsSearchResponse = {
  total: number;
  items: SongSearchItem[];
};

@Injectable()
export class SongsSearchService {
  constructor(private readonly prisma: PrismaService) {}

  private mapSongToResult(s: any): SongSearchItem {
    const firstLyrics =
      (s.firstLyrics ?? "").toString().trim() ||
      (s.lyrics ?? "").toString().trim().slice(0, 120);

    return {
      id: s.id,
      legacySongId: s.legacySongId ?? null,

      title: s.title ?? "",
      firstLyrics,
      lyrics: s.lyrics ?? "",
      characteristics: s.characteristics ?? "",
      originalKey: s.originalKey ?? "",
      chords: s.chords ?? null,
      partiture: s.scoreFile ? 1 : 0,
      status: s.status ?? "",
      score: 0,
      views: s.views ?? null,

      categoryId: s.categoryId ?? null,
      rythmId: s.rythmId ?? null,
    };
  }

  async searchSongs(params: SearchParams): Promise<SongsSearchResponse> {
    const {
      q,
      skip,
      take,
      createdByUserId,
      chords,
      partiture,
      categoryIds,
      rythmIds,
      characteristics,
      lyricsFlag,
      status,
      popular,
    } = params;

    const where: Prisma.SongWhereInput = {};

    // createdByUserId
    if (typeof createdByUserId === "number") {
      where.createdByUserId = createdByUserId;
    }

    // chords
    if (chords === "1") {
      where.chords = { not: null };
    } else if (chords === "0") {
      where.chords = null;
    }

    // partiture (με βάση scoreFile)
    if (partiture === "1") {
      where.scoreFile = { not: null };
    } else if (partiture === "0") {
      where.scoreFile = null;
    }

    // categoryIds
    if (categoryIds && categoryIds.length > 0) {
      where.categoryId = { in: categoryIds };
    }

    // rythmIds
    if (rythmIds && rythmIds.length > 0) {
      where.rythmId = { in: rythmIds };
    }

    // status
    if (status === "null") {
      // αν ποτέ θελήσεις "χωρίς status", εδώ δεν έχει νόημα γιατί είναι enum
      // το αφήνουμε σκόπιμα χωρίς φίλτρο
    } else if (status && status.trim() !== "") {
      if ((Object.values(SongStatus) as string[]).includes(status)) {
        where.status = status as SongStatus;
      }
    }

    // q (αναζήτηση σε title/lyrics/firstLyrics)
    if (q && q.trim() !== "") {
      const term = q.trim();
      where.OR = [
        { title: { contains: term, mode: "insensitive" } },
        { firstLyrics: { contains: term, mode: "insensitive" } },
        { lyrics: { contains: term, mode: "insensitive" } },
      ];
    }

    // characteristics
    if (characteristics === "null") {
      where.characteristics = null;
    } else if (characteristics && characteristics.trim() !== "") {
      where.characteristics = {
        contains: characteristics.trim(),
        mode: "insensitive",
      };
    }

    // lyricsFlag "null" => μόνο χωρίς στίχους
    if (lyricsFlag === "null") {
      where.lyrics = null;
    }

    const sortByPopular = popular === "1";

    // ασφάλεια στα take/skip
    const safeTake = (() => {
      if (!Number.isFinite(take)) return 50;
      if (take <= 0) return 50;
      if (take > 200) return 200;
      return take;
    })();

    const safeSkip = (() => {
      if (!Number.isFinite(skip)) return 0;
      if (skip < 0) return 0;
      if (skip > 10_000) return 10_000;
      return skip;
    })();

    const orderBy: Prisma.SongOrderByWithRelationInput = sortByPopular
      ? { views: "desc" }
      : { id: "desc" };

    const [songs, total] = await Promise.all([
      this.prisma.song.findMany({
        where,
        skip: safeSkip,
        take: safeTake,
        orderBy,
        // ✅ Για να υπάρχει legacySongId στο DTO
        select: {
          id: true,
          legacySongId: true,
          title: true,
          firstLyrics: true,
          lyrics: true,
          characteristics: true,
          originalKey: true,
          chords: true,
          status: true,
          scoreFile: true,
          views: true,
          categoryId: true,
          rythmId: true,
        },
      }),
      this.prisma.song.count({ where }),
    ]);

    return {
      total,
      items: songs.map((s) => this.mapSongToResult(s)),
    };
  }
}
