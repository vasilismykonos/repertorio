import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactCompiler: true,
  // ΧΩΡΙΣ basePath πλέον – η εφαρμογή σερβίρεται στο root του app.repertorio.net
};

export default nextConfig;
