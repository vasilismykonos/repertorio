-- AlterEnum
ALTER TYPE "VersionArtistRole" ADD VALUE 'LYRICIST';
