// apps/rooms/rooms.js
const fs = require("fs");
const crypto = require("crypto");

/**
 * Υπολογίζει SHA256(salt + password)
 */
function sha256WithSalt(salt, password) {
  return crypto.createHash("sha256").update(salt + password, "utf8").digest("hex");
}

/**
 * RoomManager – κεντρική in-memory διαχείριση rooms.
 *
 * - metaData: room -> { hasPassword, salt, passwordHash }
 * - clients: room -> Set<WebSocket>
 * - clientInfo: WeakMap<WebSocket, { room, deviceId, userId, username }>
 * - lastSync: room -> { syncId, payload }
 */
class RoomManager {
  constructor(options = {}) {
    this.metaFile = options.metaFile || null;

    /** @type {Map<string, { hasPassword: boolean; salt: string | null; passwordHash: string | null }>} */
    this.metaData = new Map();
    /** @type {Map<string, Set<any>>} */
    this.clients = new Map();
    /** @type {WeakMap<any, { room: string | null; deviceId: string | null; userId: number | null; username: string | null }>} */
    this.clientInfo = new WeakMap();
    /** @type {Map<string, { syncId: number; payload: any }>} */
    this.lastSync = new Map();

    this.loadMeta();
  }

  // ---------------------------------------------------------------------------
  // Persistence helpers για passwords
  // ---------------------------------------------------------------------------

  loadMeta() {
    if (!this.metaFile) return;
    try {
      if (!fs.existsSync(this.metaFile)) return;
      const raw = fs.readFileSync(this.metaFile, "utf8");
      const obj = JSON.parse(raw);
      this.metaData.clear();
      for (const room of Object.keys(obj)) {
        const meta = obj[room];
        this.metaData.set(room, {
          hasPassword: !!meta.hasPassword,
          salt: meta.salt || null,
          passwordHash: meta.passwordHash || null,
        });
      }
      console.log("[RoomManager] Loaded meta from", this.metaFile);
    } catch (err) {
      console.error("[RoomManager] Failed to load meta:", err);
    }
  }

  saveMeta() {
    if (!this.metaFile) return;
    try {
      const obj = {};
      for (const [room, meta] of this.metaData.entries()) {
        obj[room] = {
          hasPassword: !!meta.hasPassword,
          salt: meta.salt || null,
          passwordHash: meta.passwordHash || null,
        };
      }
      fs.writeFileSync(this.metaFile, JSON.stringify(obj, null, 2), "utf8");
      // console.log("[RoomManager] Saved meta to", this.metaFile);
    } catch (err) {
      console.error("[RoomManager] Failed to save meta:", err);
    }
  }

  // ---------------------------------------------------------------------------
  // Βασικές λειτουργίες rooms
  // ---------------------------------------------------------------------------

  ensureRoom(room) {
    if (!this.metaData.has(room)) {
      this.metaData.set(room, {
        hasPassword: false,
        salt: null,
        passwordHash: null,
      });
      this.saveMeta();
    }
    if (!this.clients.has(room)) {
      this.clients.set(room, new Set());
    }
  }

  /**
   * Δημιουργία room με προαιρετικό password.
   * Αν υπάρχει ήδη, είναι idempotent: επιστρέφει το ίδιο meta.
   */
  createRoom(room, password = "") {
    const clean = String(room || "").trim();
    if (!clean) {
      throw new Error("Άδειο όνομα room");
    }

    if (!this.metaData.has(clean)) {
      if (password && password.trim() !== "") {
        const salt = crypto.randomBytes(16).toString("hex");
        const hash = sha256WithSalt(salt, password.trim());
        this.metaData.set(clean, {
          hasPassword: true,
          salt,
          passwordHash: hash,
        });
      } else {
        this.metaData.set(clean, {
          hasPassword: false,
          salt: null,
          passwordHash: null,
        });
      }
      this.saveMeta();
    } else if (password && password.trim() !== "") {
      // update password for existing room
      const salt = crypto.randomBytes(16).toString("hex");
      const hash = sha256WithSalt(salt, password.trim());
      this.metaData.set(clean, {
        hasPassword: true,
        salt,
        passwordHash: hash,
      });
      this.saveMeta();
    }

    if (!this.clients.has(clean)) {
      this.clients.set(clean, new Set());
    }

    return this.metaData.get(clean);
  }

  deleteRoom(room) {
    const clean = String(room || "").trim();
    if (!clean) return;

    // Κλείσε όλους τους clients
    const set = this.clients.get(clean);
    if (set) {
      for (const ws of set) {
        try {
          ws.close(1000, "room_deleted");
        } catch {}
      }
      this.clients.delete(clean);
    }

    this.metaData.delete(clean);
    this.lastSync.delete(clean);
    this.saveMeta();
  }

  /**
   * Επιστρέφει λίστα rooms για UI.
   */
  getRoomsList() {
    const result = [];
    for (const [room, meta] of this.metaData.entries()) {
      const set = this.clients.get(room);
      const userCount = set ? set.size : 0;
      result.push({
        room,
        userCount,
        hasPassword: !!meta.hasPassword,
      });
    }
    // sort alfabetικά
    result.sort((a, b) => a.room.localeCompare(b.room, "el"));
    return result;
  }

  /**
   * Επισκόπηση rooms για τα REST endpoints (/health, /get-rooms, /status).
   * Εδώ μπορούμε απλά να επαναχρησιμοποιήσουμε την getRoomsList().
   */
  getRoomsOverview() {
    return this.getRoomsList();
  }

  /**
   * Συνολικός αριθμός clients σε όλα τα rooms.
   */
  getTotalClients() {
    let total = 0;
    for (const set of this.clients.values()) {
      total += set.size;
    }
    return total;
  }

  /**
   * Password check.
   */
  verifyPassword(room, password = "") {
    const clean = String(room || "").trim();
    const meta = this.metaData.get(clean);
    if (!meta || !meta.hasPassword) {
      // room χωρίς password
      return true;
    }
    if (!password || password.trim() === "") return false;
    if (!meta.salt || !meta.passwordHash) return false;

    const hash = sha256WithSalt(meta.salt, password.trim());
    return hash === meta.passwordHash;
  }

  // ---------------------------------------------------------------------------
  // Clients
  // ---------------------------------------------------------------------------

  attachClient(room, ws, info = {}) {
    const clean = String(room || "").trim();
    if (!clean) return;
    this.ensureRoom(clean);

    // remove from previous room, αν υπάρχει
    const existing = this.clientInfo.get(ws);
    if (existing && existing.room && existing.room !== clean) {
      this.detachClient(ws);
    }

    const set = this.clients.get(clean);
    set.add(ws);

    this.clientInfo.set(ws, {
      room: clean,
      deviceId: info.deviceId || null,
      userId: info.userId ?? null,
      username: info.username || null,
    });

    return set.size;
  }

  detachClient(ws) {
    const info = this.clientInfo.get(ws);
    if (!info || !info.room) return { room: null, userCount: 0 };

    const room = info.room;
    const set = this.clients.get(room);
    let userCount = 0;
    if (set) {
      set.delete(ws);
      userCount = set.size;
      if (set.size === 0) {
        // δεν διαγράφω meta / room, κρατάμε το room
      }
    }

    this.clientInfo.delete(ws);
    return { room, userCount };
  }

  getClientInfo(ws) {
    return this.clientInfo.get(ws) || {
      room: null,
      deviceId: null,
      userId: null,
      username: null,
    };
  }

  // ---------------------------------------------------------------------------
  // song_sync state
  // ---------------------------------------------------------------------------

  setLastSync(room, payload) {
    const clean = String(room || "").trim();
    if (!clean) return;
    this.lastSync.set(clean, payload);
  }

  getLastSync(room) {
    const clean = String(room || "").trim();
    return this.lastSync.get(clean);
  }
}

module.exports = {
  RoomManager,
};
