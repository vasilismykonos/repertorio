// app/Providers.tsx
"use client";

import { SessionProvider } from "next-auth/react";
import type { ReactNode } from "react";
import { RoomsProvider } from "./components/RoomsProvider";

export default function Providers({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <RoomsProvider>{children}</RoomsProvider>
    </SessionProvider>
  );
}
