// apps/web/app/components/RoomsProvider.tsx
"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useCallback,
} from "react";
import { useSession } from "next-auth/react";

type RoomsContextType = {
  wsConnected: boolean;
  currentRoom: string | null;
  switchRoom: (room: string | null, password?: string) => void;
  lastSyncId: number;
  ignoreSyncUntil: number;
};

const RoomsContext = createContext<RoomsContextType | null>(null);

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const DEVICE_ID_KEY = "rep_device_id";

function getOrCreateDeviceId(): string {
  if (typeof window === "undefined") return "server-device";
  const existing = window.localStorage.getItem(DEVICE_ID_KEY);
  if (existing && existing.trim() !== "") return existing;
  const generated = `dev_${Math.random().toString(36).slice(2)}_${Date.now()}`;
  try {
    window.localStorage.setItem(DEVICE_ID_KEY, generated);
  } catch {
    // ignore
  }
  return generated;
}

function getSenderUrl(): string | null {
  if (typeof window === "undefined") return null;
  return window.location.href;
}

// WebSocket URL (Nginx: /rooms-api/ws → rooms server)
function getWsUrl(): string | null {
  if (typeof window === "undefined") return null;

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const host = window.location.host;

  // Αν στο μέλλον θες override:
  // const envUrl = process.env.NEXT_PUBLIC_ROOMS_WS_URL;
  // if (envUrl) return envUrl;

  return `${protocol}://${host}/rooms-api/ws`;
}

export function RoomsProvider({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();

  const getUserMeta = () => {
    const anySession: any = session as any;
    const user = anySession?.user || null;
    return {
      userId: user?.id ?? null,
      username: user?.displayName || user?.name || user?.email || null,
    };
  };

  const wsRef = useRef<WebSocket | null>(null);
  // Χρησιμοποιούμε καθαρά numbers για timers (browser)
  const reconnectRef = useRef<number | null>(null);
  const heartbeatRef = useRef<number | null>(null);

  const [wsConnected, setWsConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [lastSyncId, setLastSyncId] = useState<number>(0);
  const [ignoreSyncUntil, setIgnoreSyncUntil] = useState<number>(0);

  // Αποθήκευση room σε localStorage + event
  const saveRoom = (room: string | null) => {
    if (typeof window === "undefined") return;

    if (room && room.trim() !== "") {
      window.localStorage.setItem("rep_current_room", room.trim());
    } else {
      window.localStorage.removeItem("rep_current_room");
    }

    const evt = new CustomEvent("rep_current_room_changed", {
      detail: { room: room || null },
    });
    window.dispatchEvent(evt);
  };

  // Αποστολή join στον WebSocket (με device_id / user_id / username)
  const sendJoin = (room: string, password: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    const deviceId = getOrCreateDeviceId();
    const meta = getUserMeta();

    const msg = {
      type: "join_room",
      room,
      password,
      deviceId,
      userId: meta.userId,
      username: meta.username,
      senderUrl: getSenderUrl(),
    };

    try {
      wsRef.current.send(JSON.stringify(msg));
    } catch (err) {
      console.error("[RoomsProvider] sendJoin error:", err);
    }
  };

  const sendLeave = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    try {
      wsRef.current.send(JSON.stringify({ type: "leave_room" }));
    } catch (err) {
      console.error("[RoomsProvider] sendLeave error:", err);
    }
  };

  // Heartbeat προς server
  const startHeartbeat = () => {
    if (typeof window === "undefined") return;
    if (heartbeatRef.current !== null) return;

    const id = window.setInterval(() => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
      try {
        wsRef.current.send(JSON.stringify({ type: "ping" }));
      } catch {
        // ignore
      }
    }, 15000);

    heartbeatRef.current = id;
  };

  const stopHeartbeat = () => {
    if (typeof window === "undefined") return;
    if (heartbeatRef.current !== null) {
      window.clearInterval(heartbeatRef.current);
      heartbeatRef.current = null;
    }
  };

  const scheduleReconnect = () => {
    if (typeof window === "undefined") return;
    if (reconnectRef.current !== null) return;

    const id = window.setTimeout(() => {
      reconnectRef.current = null;
      connectWs();
    }, 3000);

    reconnectRef.current = id;
  };

  // Βασική σύνδεση WebSocket
  const connectWs = () => {
    if (typeof window === "undefined") return;

    if (
      wsRef.current &&
      (wsRef.current.readyState === WebSocket.OPEN ||
        wsRef.current.readyState === WebSocket.CONNECTING)
    ) {
      return;
    }

    const wsUrl = getWsUrl();
    if (!wsUrl) return;

    console.log("[RoomsProvider] connecting to", wsUrl);

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("[RoomsProvider] WebSocket open");
      setWsConnected(true);
      startHeartbeat();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data || typeof data !== "object") return;

        const t = (data as any).type || (data as any).action;

        if (t === "welcome") {
          // Απλώς επιβεβαίωση σύνδεσης
          return;
        }

        if (t === "join_accepted") {
          console.log(
            "[RoomsProvider] join_accepted:",
            (data as any).room,
            "users:",
            (data as any).userCount
          );
          return;
        }

        if (t === "join_denied") {
          console.warn(
            "[RoomsProvider] join_denied:",
            (data as any).reason || "unknown reason"
          );
          return;
        }

        if (t === "update_count") {
          if (typeof window !== "undefined") {
            const evt = new CustomEvent("rep_rooms_update_count", {
              detail: {
                room: (data as any).room,
                userCount: (data as any).userCount,
              },
            });
            window.dispatchEvent(evt);
          }
          return;
        }

        if (t === "song_sync") {
          const syncId = Number((data as any).syncId ?? 0);
          setLastSyncId(syncId);

          if (typeof window !== "undefined") {
            const evt = new CustomEvent("rep_song_sync", {
              detail: {
                room: (data as any).room,
                syncId,
                payload: (data as any).payload,
              },
            });
            window.dispatchEvent(evt);
          }
          return;
        }

        if (t === "pong") {
          // optional
          return;
        }
      } catch (err) {
        console.error("[RoomsProvider] onmessage error:", err);
      }
    };

    ws.onclose = (event) => {
      console.log(
        "[RoomsProvider] WebSocket closed",
        "code=",
        event.code,
        "reason=",
        event.reason
      );
      setWsConnected(false);
      stopHeartbeat();
      scheduleReconnect();
    };

    ws.onerror = (event) => {
      // Αν το socket είναι ήδη σε CLOSING/CLOSED, αντιμετώπισέ το πιο ήπια
      if (
        ws.readyState === WebSocket.CLOSING ||
        ws.readyState === WebSocket.CLOSED
      ) {
        console.debug("[RoomsProvider] WebSocket error after close:", event);
        return;
      }

      console.error(
        "[RoomsProvider] WebSocket error (state=" + ws.readyState + "):",
        event
      );
    };
  };

  // Αρχικό connect + cleanup
  useEffect(() => {
    connectWs();

    return () => {
      const ws = wsRef.current;

      if (ws) {
        try {
          // ΜΟΝΟ αν είναι OPEN ή CLOSING το κλείνουμε άμεσα.
          if (
            ws.readyState === WebSocket.OPEN ||
            ws.readyState === WebSocket.CLOSING
          ) {
            ws.close();
          } else if (ws.readyState === WebSocket.CONNECTING) {
            // Αν είναι ακόμη CONNECTING, δεν κάνουμε άμεσο close
            // (για να μην πετάει "closed before the connection is established").
            // Αποσυνδέουμε τους handlers ώστε να μην επηρεάζει τη λογική μας.
            ws.onopen = () => {
              try {
                ws.close();
              } catch {
                // ignore
              }
            };
            ws.onmessage = null as any;
            ws.onerror = null as any;
            ws.onclose = null as any;
          }
        } catch {
          // ignore
        }
        wsRef.current = null;
      }

      stopHeartbeat();

      if (typeof window !== "undefined" && reconnectRef.current !== null) {
        window.clearTimeout(reconnectRef.current);
        reconnectRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Όταν αλλάξει wsConnected ή currentRoom → κάνε join
  useEffect(() => {
    if (!wsConnected || !currentRoom) return;
    sendJoin(currentRoom, "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wsConnected, currentRoom]);

  // Public API: switchRoom (memoized)
  const switchRoom = useCallback(
    (room: string | null, password: string = "") => {
      if (!room || room.trim() === "") {
        sendLeave();
        setCurrentRoom(null);
        saveRoom(null);
        return;
      }

      const clean = room.trim();
      setCurrentRoom(clean);
      saveRoom(clean);

      sendJoin(clean, password);
    },
    []
  );

  // GLOBAL EXPOSE – για RoomsClient / WordPress compatibility
  useEffect(() => {
    if (typeof window === "undefined") return;

    (window as any).RepRoomsSwitchRoom = (room: string | null, password = "") =>
      switchRoom(room, password);

    return () => {
      if (typeof window !== "undefined") {
        delete (window as any).RepRoomsSwitchRoom;
      }
    };
  }, [switchRoom]);

  const value: RoomsContextType = {
    wsConnected,
    currentRoom,
    switchRoom,
    lastSyncId,
    ignoreSyncUntil,
  };

  return (
    <RoomsContext.Provider value={value}>{children}</RoomsContext.Provider>
  );
}

export function useRooms(): RoomsContextType {
  const ctx = useContext(RoomsContext);
  if (!ctx) {
    throw new Error("useRooms must be used within a RoomsProvider");
  }
  return ctx;
}
