/** @type {import('postcss-load-config').Config} */
const config = {
  plugins: {
    // Δεν χρησιμοποιούμε Tailwind προς το παρόν.
    // Αφήνουμε κενό ώστε το Next να μην προσπαθεί να φορτώσει επιπλέον plugins.
  },
};

export default config;
