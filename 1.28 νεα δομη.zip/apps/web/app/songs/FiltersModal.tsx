"use client";

import React, { useState } from "react";
import FilterSelectWithSearch, { Option } from "./FilterSelectWithSearch";

type CountMap = Record<string, number>;

type Props = {
  q: string;
  take: number;
  skip: number;

  chords: string;
  partiture: string;
  category_id: string;
  rythm_id: string;
  characteristics: string;
  lyrics: string;
  status: string;
  popular: string;
  createdByUserId: string;

  categoryOptions: Option[];
  rythmOptions: Option[];
  characteristicsOptions: Option[];

  chordsCounts: CountMap;
  partitureCounts: CountMap;
  lyricsCounts: CountMap;
  statusCounts: CountMap;
};

function parseCsvToSet(value: string): Set<string> {
  if (!value) return new Set<string>();
  return new Set(
    value
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean),
  );
}

export default function FiltersModal({
  q,
  take,
  skip,
  chords,
  partiture,
  category_id,
  rythm_id,
  characteristics,
  lyrics,
  status,
  popular,
  createdByUserId,
  categoryOptions,
  rythmOptions,
  characteristicsOptions,
  chordsCounts,
  partitureCounts,
  lyricsCounts,
  statusCounts,
}: Props) {
  const [open, setOpen] = useState(false);

  // sets για multi-select
  const chordsSet = parseCsvToSet(chords);
  const partitureSet = parseCsvToSet(partiture);
  const lyricsSet = parseCsvToSet(lyrics);
  const statusSet = parseCsvToSet(status);

  const sectionStyle: React.CSSProperties = {
    display: "flex",
    flexDirection: "column",
    gap: 4,
    marginBottom: 12,
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 13,
    fontWeight: 600,
    color: "#ddd",
  };

  const smallCount = (val: string, map: CountMap) =>
    typeof map[val] === "number" ? ` (${map[val]})` : " (0)";

  return (
    <>
      {/* Κουμπί ΦΙΛΤΡΑ (πάνω στη σελίδα) */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          padding: "6px 10px",
          borderRadius: 16,
          border: "1px solid #666",
          backgroundColor: "#111",
          color: "#fff",
          fontSize: "0.9rem",
          cursor: "pointer",
        }}
        title="Φίλτρα αναζήτησης"
      >
        <span
          style={{
            display: "inline-block",
            width: 16,
            height: 16,
            borderRadius: 4,
            border: "2px solid #fff",
            boxSizing: "border-box",
          }}
        />
        <span>Φίλτρα</span>
      </button>

      {/* MODAL OVERLAY */}
      {open && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "rgba(0,0,0,0.7)",
            zIndex: 5000,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
          onClick={() => setOpen(false)}
        >
          {/* MODAL CONTENT */}
          <div
            style={{
              width: "95%",
              maxWidth: 300,
              maxHeight: "90vh",
              backgroundColor: "#000",
              borderRadius: 10,
              border: "1px solid #444",
              padding: 16,
              overflowY: "auto",
              overflowX: "hidden",
              boxSizing: "border-box",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header modal */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <h2 style={{ fontSize: "1.2rem", margin: 0 }}>
                Φίλτρα αναζήτησης τραγουδιών
              </h2>
              <button
                type="button"
                onClick={() => setOpen(false)}
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#fff",
                  fontSize: "1.2rem",
                  cursor: "pointer",
                }}
              >
                ✖
              </button>
            </div>

            {/* ΦΟΡΜΑ ΦΙΛΤΡΩΝ – όλα expanded, με checkbox + counts */}
            <form
              method="GET"
              action="/songs"
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              {/* Hidden βασικά */}
              <input type="hidden" name="search_term" value={q} />
              <input type="hidden" name="take" value={String(take)} />
              <input type="hidden" name="skip" value="0" />

              {/* 1. Συγχορδίες */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Συγχορδίες</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="chords"
                    value="1"
                    defaultChecked={chordsSet.has("1")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    Με συγχορδίες
                    {smallCount("1", chordsCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="chords"
                    value="0"
                    defaultChecked={chordsSet.has("0")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    Χωρίς συγχορδίες
                    {smallCount("0", chordsCounts)}
                  </span>
                </label>
              </div>

              {/* 2. Παρτιτούρα */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Παρτιτούρα</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="partiture"
                    value="1"
                    defaultChecked={partitureSet.has("1")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    Με παρτιτούρα
                    {smallCount("1", partitureCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="partiture"
                    value="0"
                    defaultChecked={partitureSet.has("0")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    Χωρίς παρτιτούρα
                    {smallCount("0", partitureCounts)}
                  </span>
                </label>
              </div>

              {/* 3. Δημοφιλή */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Δημοφιλία</span>
                <label
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "4px 8px",
                    borderRadius: 4,
                    border: "1px solid #555",
                    backgroundColor: "#000",
                    color: "#fff",
                    fontSize: 13,
                    boxSizing: "border-box",
                    width: "fit-content",
                  }}
                >
                  <input
                    type="checkbox"
                    name="popular"
                    value="1"
                    defaultChecked={popular === "1"}
                    style={{ margin: 0 }}
                  />
                  <span>⭐ Δημοφιλή (περισσότερες προβολές πρώτα)</span>
                </label>
              </div>

              {/* 4. Κατηγορία – multi-select */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Κατηγορία</span>
                <FilterSelectWithSearch
                  name="category_id"
                  options={categoryOptions}
                  selectedValue={category_id}
                />
              </div>

              {/* 5. Ρυθμός – multi-select */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Ρυθμός</span>
                <FilterSelectWithSearch
                  name="rythm_id"
                  options={rythmOptions}
                  selectedValue={rythm_id}
                />
              </div>

              {/* 6. Χαρακτηριστικά – multi-select */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Χαρακτηριστικά</span>
                <FilterSelectWithSearch
                  name="characteristics"
                  options={characteristicsOptions}
                  selectedValue={characteristics}
                />
              </div>

              {/* 7. Στίχοι */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Στίχοι</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="lyrics"
                    value="null"
                    defaultChecked={lyricsSet.has("null")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    Μόνο χωρίς στίχους
                    {smallCount("null", lyricsCounts)}
                  </span>
                </label>
              </div>

              {/* 8. Κατάσταση – multi-select */}
              <div style={sectionStyle}>
                <span style={labelStyle}>Κατάσταση</span>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="PUBLISHED"
                    defaultChecked={statusSet.has("PUBLISHED")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    PUBLISHED
                    {smallCount("PUBLISHED", statusCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="PENDING_APPROVAL"
                    defaultChecked={statusSet.has("PENDING_APPROVAL")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    PENDING_APPROVAL
                    {smallCount("PENDING_APPROVAL", statusCounts)}
                  </span>
                </label>

                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 13,
                    color: "#fff",
                  }}
                >
                  <input
                    type="checkbox"
                    name="status"
                    value="DRAFT"
                    defaultChecked={statusSet.has("DRAFT")}
                    style={{ margin: 0 }}
                  />
                  <span>
                    DRAFT
                    {smallCount("DRAFT", statusCounts)}
                  </span>
                </label>
              </div>

              {/* 9. User ID δημιουργού */}
              <div style={sectionStyle}>
                <label style={labelStyle} htmlFor="filter-createdByUserId">
                  User ID δημιουργού
                </label>
                <input
                  id="filter-createdByUserId"
                  type="number"
                  name="createdByUserId"
                  placeholder="π.χ. 123"
                  defaultValue={createdByUserId}
                  style={{
                    width: "100%",
                    padding: "4px 8px",
                    borderRadius: 4,
                    border: "1px solid #555",
                    backgroundColor: "#000",
                    color: "#fff",
                    height: 36,
                    boxSizing: "border-box",
                  }}
                />
              </div>

              {/* Κουμπιά υποβολής / καθαρισμού */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: 8,
                  marginTop: 8,
                }}
              >
                <a
                  href="/songs"
                  style={{
                    padding: "6px 10px",
                    borderRadius: 4,
                    border: "1px solid #666",
                    backgroundColor: "#111",
                    color: "#fff",
                    textDecoration: "none",
                    fontSize: "0.9rem",
                  }}
                >
                  ✖ Καθαρισμός
                </a>

                <button
                  type="submit"
                  style={{
                    padding: "6px 12px",
                    borderRadius: 4,
                    border: "1px solid #777",
                    backgroundColor: "#222",
                    color: "#fff",
                    cursor: "pointer",
                    fontSize: "0.9rem",
                  }}
                  onClick={() => setOpen(false)}
                >
                  🔍 Εφαρμογή φίλτρων
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
