// apps/web/app/lists/page.tsx

import type { Metadata } from "next";
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi } from "@/lib/currentUser";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Λίστες | Repertorio Next",
  description: "Λίστες τραγουδιών του χρήστη από το παλιό Repertorio.",
};

type ListSummary = {
  id: number;
  title: string;
  groupId: number | null;
  marked: boolean;
};

type ListGroupSummary = {
  id: number;
  title: string;
  fullTitle: string | null;
  listsCount: number;
};

type ListsIndexResponse = {
  items: ListSummary[];
  total: number;
  page: number;
  pageSize: number;
  groups: ListGroupSummary[];
};

type ListsPageSearchParams = {
  search?: string;
  group?: string; // "", "null" ή αριθμός groupId
  page?: string;
};

function buildPageUrl(params: {
  search?: string;
  group?: string;
  page?: number;
}) {
  const qs = new URLSearchParams();

  if (params.search && params.search.trim() !== "") {
    qs.set("search", params.search.trim());
  }

  if (params.group && params.group !== "") {
    qs.set("group", params.group);
  }

  if (params.page && params.page > 1) {
    qs.set("page", String(params.page));
  }

  const query = qs.toString();
  return query ? `/lists?${query}` : "/lists";
}

export default async function ListsPage({
  searchParams,
}: {
  searchParams: ListsPageSearchParams;
}) {
  const currentUser = await getCurrentUserFromApi();

  if (!currentUser) {
    return (
      <section style={{ padding: "1rem" }}>
        <h1 style={{ fontSize: "1.6rem", marginBottom: "0.5rem" }}>Λίστες</h1>
        <p>Πρέπει να είστε συνδεδεμένος για να δείτε τις λίστες σας.</p>
      </section>
    );
  }

  const search = (searchParams.search || "").trim();
  const group = searchParams.group || "";
  const page = Math.max(Number(searchParams.page || "1") || 1, 1);
  const pageSize = 20;

  const apiParams = new URLSearchParams();
  apiParams.set("userId", String(currentUser.id));
  apiParams.set("page", String(page));
  apiParams.set("pageSize", String(pageSize));

  if (search) apiParams.set("search", search);
  if (group) apiParams.set("group", group);

  const apiUrl = `/lists?${apiParams.toString()}`;

  let data: ListsIndexResponse;
  try {
    data = await fetchJson<ListsIndexResponse>(apiUrl);
  } catch (err: any) {
    return (
      <section style={{ padding: "1rem" }}>
        <h1 style={{ fontSize: "1.6rem", marginBottom: "0.5rem" }}>Λίστες</h1>
        <p>
          Σφάλμα κατά την ανάγνωση των λιστών:{" "}
          {String(err?.message || err)}
        </p>
      </section>
    );
  }

  const { items, total, groups } = data;
  const hasPrev = page > 1;
  const hasNext = page * pageSize < total;

  // Υπολογισμός αριθμού λιστών χωρίς ομάδα (όπως στο παλιό site)
  const totalFromGroups = groups.reduce(
    (acc, g) => acc + (Number.isFinite(g.listsCount) ? g.listsCount : 0),
    0,
  );
  const noGroupCount = Math.max(total - totalFromGroups, 0);

  return (
    <section style={{ padding: "1rem" }}>
      <h1 style={{ fontSize: "1.8rem", marginBottom: "0.75rem" }}>Λίστες</h1>

      {/* Φόρμα αναζήτησης + φίλτρα ομάδων (κουμπιά) */}
      <form
        action="/lists"
        method="get"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "0.5rem",
          marginBottom: "1rem",
        }}
      >
        {/* Γραμμή αναζήτησης */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "0.5rem",
            alignItems: "center",
          }}
        >
          <input
            type="text"
            name="search"
            defaultValue={search}
            placeholder="Αναζήτηση λίστας..."
            style={{
              flex: "1 1 200px",
              padding: "0.4rem 0.6rem",
              borderRadius: 4,
              border: "1px solid #ccc",
            }}
          />
          {/* Προαιρετικά θα μπορούσε να υπάρχει submit, αλλά εδώ γίνεται
              submit με Enter, όπως και στο παλιό site με το searchbox. */}
        </div>

        {/* Κουμπιά ομάδων όπως στο παλιό lists.php (Όλες / Χωρίς ομάδα / Ομάδες) */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "8px",
            marginTop: "0.5rem",
          }}
        >
          {/* Όλες */}
          <Link
            href={buildPageUrl({ search, group: "", page: 1 })}
            style={{
              padding: "6px 12px",
              borderRadius: 16,
              background: !group ? "#0070f3" : "#222",
              color: "#fff",
              textDecoration: "none",
              fontWeight: 500,
              fontSize: "0.9rem",
            }}
          >
            Όλες ({total})
          </Link>

          {/* Χωρίς ομάδα */}
          <Link
            href={buildPageUrl({ search, group: "null", page: 1 })}
            style={{
              padding: "6px 12px",
              borderRadius: 16,
              background: group === "null" ? "#0070f3" : "#222",
              color: "#fff",
              textDecoration: "none",
              fontWeight: 500,
              fontSize: "0.9rem",
            }}
          >
            Χωρίς ομάδα ({noGroupCount})
          </Link>

          {/* Ομάδες από group_lists (fullTitle / title) */}
          {groups.map((g) => (
            <Link
              key={g.id}
              href={buildPageUrl({
                search,
                group: String(g.id),
                page: 1,
              })}
              style={{
                padding: "6px 12px",
                borderRadius: 16,
                background: group === String(g.id) ? "#0070f3" : "#222",
                color: "#fff",
                textDecoration: "none",
                fontWeight: 500,
                fontSize: "0.9rem",
              }}
            >
              {g.fullTitle || g.title} ({g.listsCount})
            </Link>
          ))}
        </div>
      </form>

      {/* Στατιστικά, όπως ενημέρωνε και το παλιό UI */}
      <div style={{ marginBottom: "0.75rem", fontSize: "0.95rem" }}>
        Συνολικά: <strong>{total}</strong> λίστες
        {search && (
          <>
            {" "}
            – αναζήτηση για <strong>{search}</strong>
          </>
        )}
      </div>

      {/* Λίστα λιστών */}
      {items.length === 0 ? (
        <p>Δεν βρέθηκαν λίστες με τα τρέχοντα φίλτρα.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
          {items.map((list) => (
            <li
              key={list.id}
              style={{
                border: "1px solid #e0e0e0",
                borderRadius: 8,
                padding: "0.6rem 0.8rem",
                marginBottom: "0.5rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "0.5rem",
              }}
            >
              <div style={{ flex: "1 1 auto", minWidth: 0 }}>
                <Link
                  href={`/lists/${list.id}`}
                  style={{
                    fontWeight: 600,
                    textDecoration: "none",
                    color: "#111",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.35rem",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    maxWidth: "100%",
                  }}
                >
                  {list.marked && (
                    <span
                      aria-label="Αγαπημένη λίστα"
                      title="Αγαπημένη λίστα"
                      style={{ color: "#f5a623" }}
                    >
                      ★
                    </span>
                  )}
                  <span>{list.title || "(Χωρίς τίτλο)"}</span>
                </Link>
              </div>

              <div>
                <Link
                  href={`/lists/${list.id}`}
                  style={{
                    fontSize: "0.85rem",
                    textDecoration: "none",
                    color: "#0070f3",
                  }}
                >
                  Προβολή
                </Link>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Σελιδοποίηση */}
      {(hasPrev || hasNext) && (
        <div
          style={{
            marginTop: "1rem",
            display: "flex",
            justifyContent: "center",
            gap: "0.75rem",
            fontSize: "0.95rem",
          }}
        >
          {hasPrev ? (
            <Link
              href={buildPageUrl({
                search,
                group,
                page: page - 1,
              })}
            >
              ← Προηγούμενη
            </Link>
          ) : (
            <span style={{ color: "#aaa" }}>← Προηγούμενη</span>
          )}

          <span>
            Σελίδα <strong>{page}</strong>
          </span>

          {hasNext ? (
            <Link
              href={buildPageUrl({
                search,
                group,
                page: page + 1,
              })}
            >
              Επόμενη →
            </Link>
          ) : (
            <span style={{ color: "#aaa" }}>Επόμενη →</span>
          )}
        </div>
      )}
    </section>
  );
}
