// apps/api/src/songs/songs-search.controller.ts
import { Controller, Get, Query } from "@nestjs/common";
import { SongsSearchService } from "./songs-search.service";

@Controller("songs")
export class SongsSearchController {
  constructor(private readonly songsSearchService: SongsSearchService) {}

  @Get("search")
  async search(
    @Query("q") q?: string,
    @Query("search_term") searchTerm?: string, // συμβατότητα με παλιό όνομα
    @Query("skip") skip?: string,
    @Query("take") take?: string,
    @Query("createdByUserId") createdByUserId?: string,

    // Φίλτρα από το /songs
    @Query("chords") chords?: string,
    @Query("partiture") partiture?: string,
    @Query("category_id") categoryId?: string,
    @Query("rythm_id") rythmId?: string,
    @Query("characteristics") characteristics?: string,
    @Query("lyrics") lyricsFlag?: string,
    @Query("status") status?: string,
    @Query("popular") popular?: string,
  ) {
    const skipNum = skip ? parseInt(skip, 10) : 0;
    const takeNum = take ? parseInt(take, 10) : 50;

    const parsedUserId = createdByUserId
      ? parseInt(createdByUserId, 10)
      : undefined;
    const createdByUserIdNum =
      parsedUserId !== undefined && !Number.isNaN(parsedUserId)
        ? parsedUserId
        : undefined;

    const parsedCategoryId = categoryId ? parseInt(categoryId, 10) : undefined;
    const categoryIdNum =
      parsedCategoryId !== undefined && !Number.isNaN(parsedCategoryId)
        ? parsedCategoryId
        : undefined;

    const parsedRythmId = rythmId ? parseInt(rythmId, 10) : undefined;
    const rythmIdNum =
      parsedRythmId !== undefined && !Number.isNaN(parsedRythmId)
        ? parsedRythmId
        : undefined;

    // Προτιμάμε q, αλλά αν δεν δοθεί, χρησιμοποιούμε search_term (όπως στο παλιό /songs)
    const effectiveQ = (q || searchTerm || "").trim() || undefined;

    return this.songsSearchService.search({
      q: effectiveQ,
      skip: skipNum,
      take: takeNum,
      createdByUserId: createdByUserIdNum,
      chords,
      partiture,
      categoryId: categoryIdNum,
      rythmId: rythmIdNum,
      characteristics,
      lyricsFlag,
      status,
      popular,
    });
  }
}
