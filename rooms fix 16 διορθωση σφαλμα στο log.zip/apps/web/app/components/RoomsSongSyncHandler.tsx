// app/components/RoomsSongSyncHandler.tsx
"use client";

import { useEffect } from "react";

/**
 * RoomsSongSyncHandler
 *
 * Ακούει το custom event "rep_song_sync" που εκπέμπει το RoomsProvider
 * όταν λάβει μήνυμα type: "song_sync" από τον WebSocket server.
 *
 * Όταν το payload.kind === "song" και υπάρχει payload.url,
 * κάνει redirect τον browser σε αυτό το URL, ώστε όλοι στο ίδιο room
 * να βλέπουν το ίδιο τραγούδι (όπως στο παλιό site), ΚΑΙ μεταφέρει την τονικότητα.
 */
export default function RoomsSongSyncHandler() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const handler = (ev: Event) => {
      const custom = ev as CustomEvent<any>;
      const detail = custom.detail || {};
      const payload = detail.payload || {};

      // Περιμένουμε payload.kind === "song"
      if (payload.kind !== "song") {
        return;
      }

      const url = payload.url;
      if (!url || typeof url !== "string") {
        return;
      }

      // Τονικότητα που στάλθηκε από τον αποστολέα (π.χ. "Ρε-", "Μι")
      const selectedTonicity: string | null =
        typeof payload.selectedTonicity === "string"
          ? payload.selectedTonicity
          : null;

      // Αποθηκεύουμε global pending ώστε το SongChordsClient / score-player
      // να μπορούν να την εφαρμόσουν όταν φορτώσει η σελίδα.
      const w = window as any;
      w.__repPendingSelectedTonicity = selectedTonicity || null;

      // Helper: εφαρμόζει την pending τονικότητα στο τρέχον τραγούδι,
      // προσπαθώντας επαναληπτικά μέχρι να εμφανιστούν τα κουμπιά.
      const applyPendingTonicityNow = () => {
        if (!selectedTonicity) return;

        let attempts = 0;
        const maxAttempts = 20;
        const interval = 250;

        const tryApply = () => {
          const ton =
            (w.__repPendingSelectedTonicity as string | null | undefined) ||
            selectedTonicity;
          if (!ton) return;

          const btn = document.querySelector<HTMLButtonElement>(
            '.tonicity-button[data-tonicity="' + ton + '"]'
          );
          if (btn) {
            // Το click ενεργοποιεί ΚΑΙ το React state ΚΑΙ το score-audio.js
            btn.click();
            w.__repPendingSelectedTonicity = null;
            return;
          }

          attempts += 1;
          if (attempts < maxAttempts) {
            window.setTimeout(tryApply, interval);
          } else {
            console.warn(
              "[RoomsSongSyncHandler] Δεν βρέθηκε κουμπί τονικότητας για:",
              ton
            );
          }
        };

        tryApply();
      };

      try {
        const current = window.location.href;
        if (current === url) {
          // Ήδη στο ίδιο URL → δεν κάνουμε redirect, απλώς εφαρμόζουμε την τονικότητα.
          applyPendingTonicityNow();
          return;
        }
      } catch {
        // Αν για κάποιο λόγο αποτύχει, προχωράμε στο redirect.
      }

      console.log("[RoomsSongSyncHandler] Navigating to synced song url:", url);

      // Απλό hard redirect – συμβατό με όλες τις σελίδες (Next, παλιό WP, κτλ.)
      window.location.href = url;
    };

    window.addEventListener("rep_song_sync", handler as EventListener);

    return () => {
      window.removeEventListener("rep_song_sync", handler as EventListener);
    };
  }, []);

  // Δεν αποδίδει τίποτα στο DOM – απλά side-effect.
  return null;
}
