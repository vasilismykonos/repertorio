// apps/web/app/components/RoomsProvider.tsx
"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { useSession } from "next-auth/react";

type SongSyncPayload = {
  /**
   * Προαιρετικό – ID τραγουδιού, αν το ξέρουμε (στο νέο Next.js song page).
   * Για παλιές σελίδες (μόνο URL) μπορεί να μείνει null/undefined.
   */
  songId?: number | null;

  /**
   * Προαιρετικός τίτλος. Αν δεν υπάρχει, μπορεί να είναι null.
   */
  title?: string | null;

  /**
   * ΥΠΟΧΡΕΩΤΙΚΟ – το πλήρες URL της σελίδας του τραγουδιού
   * (αντίστοιχο του window.location.href στο παλιό sync.js).
   */
  url: string;

  /**
   * Προαιρετική τονικότητα (selected_tonicity από το παλιό σύστημα).
   * Αν δεν την χρησιμοποιείς ακόμα στο νέο site, άφησέ την undefined/null.
   */
  selectedTonicity?: string | null;
};

type RoomsContextType = {
  currentRoom: string | null;
  switchRoom: (room: string | null, password?: string) => void;
  sendSongToRoom: (payload: SongSyncPayload) => void;
};

const RoomsContext = createContext<RoomsContextType | null>(null);

const DEVICE_ID_KEY = "repertorio_device_id";

const SYNC_ID_STORAGE_PREFIX = "rep_last_sync_id_";

function getSyncStorageKey(room: string | null): string | null {
  if (!room) return null;
  const trimmed = room.trim();
  if (!trimmed) return null;
  return `${SYNC_ID_STORAGE_PREFIX}${trimmed}`;
}

function getOrCreateDeviceId(): string {
  if (typeof window === "undefined") return "server-device";
  const existing = window.localStorage.getItem(DEVICE_ID_KEY);
  if (existing && existing.trim() !== "") return existing;
  const generated = `dev_${Math.random().toString(36).slice(2)}_${Date.now()}`;
  try {
    window.localStorage.setItem(DEVICE_ID_KEY, generated);
  } catch {
    // ignore
  }
  return generated;
}

function getSenderUrl(): string | null {
  if (typeof window === "undefined") return null;
  return window.location.href;
}

// WebSocket URL (Nginx: /rooms-api/ws → rooms server)
function getWsUrl(): string | null {
  if (typeof window === "undefined") return null;

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const host = window.location.host;

  // Αν θέλεις, μπορείς να χρησιμοποιήσεις και:
  // const envUrl = process.env.NEXT_PUBLIC_ROOMS_WS_URL;
  // if (envUrl) return envUrl;

  return `${protocol}://${host}/rooms-api/ws`;
}

export function RoomsProvider({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();

  const getUserMeta = () => {
    const anySession: any = session as any;
    const user = anySession?.user || null;
    return {
      userId: user?.id ?? null,
      username: user?.displayName || user?.name || user?.email || null,
    };
  };

  const wsRef = useRef<WebSocket | null>(null);
  // Χρησιμοποιούμε καθαρά numbers για timers (browser)
  const reconnectRef = useRef<number | null>(null);
  const heartbeatRef = useRef<number | null>(null);
  // Πότε άνοιξε τελευταία φορά το WebSocket (για φίλτρο "just connected")
  const connectedAtRef = useRef<number>(0);
  // Τελευταίο syncId που επεξεργαστήκαμε σε αυτή τη σελίδα (dedupe)
  const lastProcessedSyncIdRef = useRef<number | null>(null);
  // ΝΕΟ: έχει υπάρξει έστω μία επιτυχημένη σύνδεση (onopen) σε αυτό το lifecycle;
  const hasEverOpenedRef = useRef(false);

  const [wsConnected, setWsConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [lastSyncId, setLastSyncId] = useState<number | null>(null);

  // Restore previously selected room from localStorage on first mount,
  // so that the user stays connected to the same room across all pages
  // (όπως στο παλιό WordPress sync.js).
  useEffect(() => {
    if (typeof window === "undefined") return;

    // Αν έχουμε ήδη room στη μνήμη, δεν κάνουμε override
    if (currentRoom && currentRoom.trim() !== "") {
      return;
    }

    try {
      const stored = window.localStorage.getItem("rep_current_room");
      if (stored && stored.trim() !== "") {
        setCurrentRoom(stored.trim());
      }
    } catch {
      // ignore
    }
  }, [currentRoom]);

  // Αποθήκευση room σε localStorage + event
  const saveRoom = (room: string | null) => {
    if (typeof window === "undefined") return;

    if (room && room.trim() !== "") {
      window.localStorage.setItem("rep_current_room", room.trim());
    } else {
      window.localStorage.removeItem("rep_current_room");
    }

    // Προαιρετικά: custom event, αν θες να ενημερώνεις άλλο JS
    const anyWindow = window as any;
    if (typeof anyWindow.dispatchEvent === "function") {
      const evt = new CustomEvent("rep_room_changed", {
        detail: { room },
      });
      anyWindow.dispatchEvent(evt);
    }
  };

  // Σταματά οποιοδήποτε pending reconnect timer
  const stopReconnect = () => {
    if (typeof window === "undefined") return;
    if (reconnectRef.current !== null) {
      window.clearTimeout(reconnectRef.current);
      reconnectRef.current = null;
    }
  };

  // ξεκινά / σταματά heartbeat (ping/pong)
  const startHeartbeat = () => {
    if (typeof window === "undefined") return;
    stopHeartbeat();
    heartbeatRef.current = window.setInterval(() => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      try {
        ws.send(JSON.stringify({ type: "ping" }));
      } catch {
        // ignore
      }
    }, 15000);
  };

  const stopHeartbeat = () => {
    if (typeof window === "undefined") return;
    if (heartbeatRef.current !== null) {
      window.clearInterval(heartbeatRef.current);
      heartbeatRef.current = null;
    }
  };

  // Προγραμματίζει reconnect του WebSocket
  const scheduleReconnect = () => {
    if (typeof window === "undefined") return;
    stopReconnect();
    reconnectRef.current = window.setTimeout(() => {
      connectWs();
    }, 5000) as unknown as number;
  };

  // Συνάρτηση που ανοίγει (ή ξανανοίγει) WebSocket σύνδεση
  const connectWs = () => {
    if (typeof window === "undefined") return;
    const wsUrl = getWsUrl();
    if (!wsUrl) {
      console.error("[RoomsProvider] Cannot compute WS URL");
      return;
    }

    // Αν ήδη υπάρχει σύνδεση που είναι OPEN ή CONNECTING, μην ανοίγεις δεύτερη
    const existing = wsRef.current;
    if (existing) {
      if (
        existing.readyState === WebSocket.OPEN ||
        existing.readyState === WebSocket.CONNECTING
      ) {
        return;
      }
    }

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("[RoomsProvider] WebSocket open");
      connectedAtRef.current = Date.now();
      hasEverOpenedRef.current = true; // <-- σημαντικό: σημειώνουμε ότι άνοιξε έστω μία φορά
      setWsConnected(true);
      startHeartbeat();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data || typeof data !== "object") return;

        const t = (data as any).type || (data as any).action;

        if (t === "welcome") {
          return;
        }

        if (t === "join_accepted") {
          console.log(
            "[RoomsProvider] join_accepted:",
            (data as any).room,
            "count:",
            (data as any).userCount
          );
          return;
        }

        if (t === "join_denied") {
          console.warn(
            "[RoomsProvider] join_denied:",
            (data as any).room,
            "reason:",
            (data as any).reason
          );
          return;
        }

        if (t === "update_count") {
          // Ενημέρωση DOM / custom event για UI (όπως στο παλιό sync.js)
          if (typeof window !== "undefined") {
            const evt = new CustomEvent("rep_rooms_update_count", {
              detail: {
                room: (data as any).room,
                userCount: (data as any).userCount,
              },
            });
            window.dispatchEvent(evt);
          }
          return;
        }

        if (t === "song_sync") {
          const roomName = String((data as any).room || "").trim();
          if (!roomName) {
            return;
          }

          // Πρέπει να ανήκει στο τρέχον room
          if (!currentRoom || roomName !== currentRoom.trim()) {
            return;
          }

          const rawSyncId = (data as any).syncId as
            | number
            | string
            | undefined;
          const syncIdNumber =
            typeof rawSyncId === "number"
              ? rawSyncId
              : rawSyncId
              ? Number(rawSyncId)
              : 0;
          const syncId = Number.isFinite(syncIdNumber) ? syncIdNumber : 0;

          const payload: any = (data as any).payload ?? {};
          const now = Date.now();

          const myDeviceId = getOrCreateDeviceId();
          const payloadDeviceId =
            payload && (payload.deviceId || payload.device_id)
              ? payload.deviceId || payload.device_id
              : null;

          // 1) Ποτέ μην "ακολουθούμε" τον εαυτό μας
          if (payloadDeviceId && myDeviceId && payloadDeviceId === myDeviceId) {
            return;
          }

          // 2) TTL για πολύ παλιά sync (ασφάλεια, όπως στο παλιό σύστημα)
          const sentAt =
            typeof payload.sentAt === "number"
              ? (payload.sentAt as number)
              : null;
          const MAX_LAST_SYNC_AGE_MS = 10 * 60 * 1000; // 10 λεπτά
          if (sentAt && now - sentAt > MAX_LAST_SYNC_AGE_MS) {
            return;
          }

          // 3) Αν το έχουμε ήδη "δει" σε αυτό το room (per-room localStorage), αγνόησέ το
          let lastSeenId: number | null = null;
          if (typeof window !== "undefined") {
            try {
              const key = getSyncStorageKey(currentRoom);
              if (key) {
                const stored = window.localStorage.getItem(key);
                if (stored) {
                  const n = Number(stored);
                  if (!Number.isNaN(n)) {
                    lastSeenId = n;
                  }
                }
              }
            } catch {
              // ignore
            }
          }

          if (syncId && lastSeenId && syncId === lastSeenId) {
            return;
          }

          // 4) Dedupe μέσα στο ίδιο session (χωρίς να γράφουμε κάθε φορά σε state)
          if (
            syncId &&
            lastProcessedSyncIdRef.current &&
            syncId === lastProcessedSyncIdRef.current
          ) {
            return;
          }

          // 5) Στην αρχή της σύνδεσης, αγνόησε παλιά / αυτόματα syncs
          const connectedAt = connectedAtRef.current || 0;
          const justConnected = connectedAt && now - connectedAt < 2500;
          const isManual = !!(payload && (payload.manual || payload.isManual));
          if (justConnected && !isManual) {
            return;
          }

          // --- Αν φτάσαμε εδώ, αποδεχόμαστε το sync ---
          if (syncId) {
            lastProcessedSyncIdRef.current = syncId;
            setLastSyncId(syncId);

            if (typeof window !== "undefined") {
              try {
                const key = getSyncStorageKey(currentRoom);
                if (key) {
                  window.localStorage.setItem(key, String(syncId));
                }
              } catch {
                // ignore
              }
            }
          }

          // Dispatch custom event στο window, ώστε ο score-player / JS να το πιάσει
          if (typeof window !== "undefined") {
            const evt = new CustomEvent("rep_song_sync", {
              detail: {
                room: roomName,
                syncId,
                payload,
              },
            });
            window.dispatchEvent(evt);
          }

          return;
        }

        if (t === "pong") {
          return;
        }
      } catch (err) {
        console.error("[RoomsProvider] onmessage error:", err);
      }
    };

    ws.onclose = () => {
      console.log("[RoomsProvider] WebSocket closed");
      setWsConnected(false);
      stopHeartbeat();
      scheduleReconnect();
    };

    ws.onerror = (event) => {
      // Αν δεν έχει υπάρξει ΠΟΤΕ επιτυχημένη σύνδεση (onopen),
      // αυτό το error είναι σχεδόν πάντα αποτέλεσμα dev/StrictMode cleanup
      // όπου κλείσαμε τη σύνδεση ενώ ήταν ακόμα CONNECTING.
      if (!hasEverOpenedRef.current) {
        console.warn(
          "[RoomsProvider] WebSocket error πριν το πρώτο open (πιθανό dev/StrictMode cleanup):",
          event
        );
        return;
      }

      // Μετά την πρώτη επιτυχή σύνδεση, θεωρούμε τα errors κανονικά.
      console.error("[RoomsProvider] WebSocket error:", event);
    };
  };

  useEffect(() => {
    connectWs();
    return () => {
      stopHeartbeat();
      stopReconnect();
      const ws = wsRef.current;
      if (ws) {
        try {
          ws.close();
        } catch {
          // ignore
        }
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ------------------------------------------------------
  // API: join / leave room
  // ------------------------------------------------------
  const sendJoinMessage = (room: string | null, password?: string) => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.warn("[RoomsProvider] Cannot send join_room – WS not open");
      return;
    }

    const { userId, username } = getUserMeta();
    const deviceId = getOrCreateDeviceId();

    const msg = {
      type: "join_room",
      room,
      password: password || "",
      deviceId,
      userId,
      username,
    };

    try {
      ws.send(JSON.stringify(msg));
      console.log("[RoomsProvider] join_room sent:", msg);
    } catch (err) {
      console.error("[RoomsProvider] join_room send error:", err);
    }
  };

  const sendLeaveMessage = (room: string | null) => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      return;
    }

    const deviceId = getOrCreateDeviceId();

    const msg = {
      type: "leave_room",
      room,
      deviceId,
    };

    try {
      ws.send(JSON.stringify(msg));
      console.log("[RoomsProvider] leave_room sent:", msg);
    } catch (err) {
      console.error("[RoomsProvider] leave_room send error:", err);
    }
  };

  const switchRoom = (room: string | null, password?: string) => {
    const trimmed = room ? room.trim() : null;

    if (currentRoom && currentRoom.trim() !== "") {
      sendLeaveMessage(currentRoom);
    }

    if (trimmed && trimmed !== "") {
      setCurrentRoom(trimmed);
      saveRoom(trimmed);
      sendJoinMessage(trimmed, password);
    } else {
      setCurrentRoom(null);
      saveRoom(null);
    }
  };

  // ------------------------------------------------------
  // Public API: sendSongToRoom – χρησιμοποιεί το πρωτόκολλο song_sync
  // ------------------------------------------------------
  const sendSongToRoom = (payload: SongSyncPayload) => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.warn(
        "[RoomsProvider] Cannot send song_sync – WebSocket not open"
      );
      return;
    }

    if (!currentRoom || currentRoom.trim() === "") {
      console.warn(
        "[RoomsProvider] Cannot send song_sync – no active room selected"
      );
      return;
    }

    const { userId, username } = getUserMeta();
    const deviceId = getOrCreateDeviceId();
    const url = payload.url || getSenderUrl();
    if (!url) {
      console.warn("[RoomsProvider] Cannot send song_sync – no URL");
      return;
    }

    const msg = {
      type: "song_sync",
      room: currentRoom, // συμβατό με ws-handler.js (type === "song_sync")
      syncId: Date.now(), // απλό unique id
      payload: {
        kind: "song",
        songId: payload.songId ?? null,
        title: payload.title ?? null,
        url,
        selectedTonicity: payload.selectedTonicity ?? null,
        deviceId,
        userId,
        username,
        sentAt: Date.now(),
        manual: true, // ώστε ο client να το δεχτεί ακόμη και αμέσως μετά τη σύνδεση
      },
    };

    try {
      ws.send(JSON.stringify(msg));
      console.log("[RoomsProvider] song_sync sent:", msg);
    } catch (err) {
      console.error("[RoomsProvider] song_sync send error:", err);
    }
  };

  // Optional: expose Web API for legacy scripts if needed (π.χ. global functions)
  useEffect(() => {
    if (typeof window === "undefined") return;

    const anyWindow = window as any;

    anyWindow.RepRoomsSwitchRoom = (room: string | null, password?: string) => {
      switchRoom(room, password);
    };

    anyWindow.RepRoomsSendSong = (payload: SongSyncPayload) => {
      sendSongToRoom(payload);
    };

    return () => {
      delete anyWindow.RepRoomsSwitchRoom;
      delete anyWindow.RepRoomsSendSong;
    };
  }, [switchRoom, sendSongToRoom]);

  const value: RoomsContextType = {
    currentRoom,
    switchRoom,
    sendSongToRoom,
  };

  return (
    <RoomsContext.Provider value={value}>{children}</RoomsContext.Provider>
  );
}

export function useRooms(): RoomsContextType {
  const ctx = useContext(RoomsContext);
  if (!ctx) {
    throw new Error("useRooms must be used within a RoomsProvider");
  }
  return ctx;
}
