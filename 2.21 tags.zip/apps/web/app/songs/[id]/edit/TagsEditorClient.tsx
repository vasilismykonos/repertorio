// apps/web/app/songs/[id]/edit/TagsEditorClient.tsx
"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

type TagDto = {
  id: number;
  title: string;
  slug: string;
};

type Props = {
  apiBase: string; // e.g. https://api.repertorio.net/api/v1
  initialTags: TagDto[];
};

function normalizeId(n: unknown): number | null {
  const v = typeof n === "string" ? Number(n) : typeof n === "number" ? n : NaN;
  return Number.isFinite(v) && v > 0 ? v : null;
}

function uniqById(tags: TagDto[]): TagDto[] {
  const seen = new Set<number>();
  const out: TagDto[] = [];
  for (const t of tags) {
    if (!seen.has(t.id)) {
      seen.add(t.id);
      out.push(t);
    }
  }
  return out;
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, init);
  if (!r.ok) {
    const text = await r.text().catch(() => "");
    throw new Error(`HTTP ${r.status} ${r.statusText} :: ${text.slice(0, 200)}`);
  }
  return (await r.json()) as T;
}

export default function TagsEditorClient({ apiBase, initialTags }: Props) {
  const [selectedTags, setSelectedTags] = useState<TagDto[]>(
    () =>
      uniqById(
        (initialTags ?? []).map((t) => ({
          id: Number(t.id),
          title: String(t.title ?? ""),
          slug: String(t.slug ?? ""),
        }))
      )
  );

  const selectedIds = useMemo(() => selectedTags.map((t) => t.id), [selectedTags]);

  const [query, setQuery] = useState<string>("");
  const [suggestions, setSuggestions] = useState<TagDto[]>([]);
  const [status, setStatus] = useState<string>("");

  const debounceRef = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const tagsListUrl = useCallback(
    (q: string, take: number) => {
      const clean = (q || "").trim();
      if (!clean) return `${apiBase}/songs/tags?take=${take}`;
      return `${apiBase}/songs/tags?search=${encodeURIComponent(clean)}&take=${take}`;
    },
    [apiBase]
  );

  const tagsCreateUrl = useMemo(() => `${apiBase}/songs/tags`, [apiBase]);

  const loadSuggestions = useCallback(
    async (q: string) => {
      const isEmpty = !q || !q.trim();
      setStatus(isEmpty ? "Φόρτωση tags…" : "Αναζήτηση tags…");

      try {
        const list = await fetchJson<TagDto[]>(tagsListUrl(q, 25), {
          credentials: "include",
        });
        setSuggestions(Array.isArray(list) ? list : []);
        setStatus(Array.isArray(list) && list.length ? `Βρέθηκαν: ${list.length}` : "Δεν βρέθηκαν tags");
      } catch {
        setSuggestions([]);
        setStatus("Tag search failed (έλεγξε endpoint /songs/tags)");
      }
    },
    [tagsListUrl]
  );

  const onFocus = useCallback(() => {
    loadSuggestions("");
  }, [loadSuggestions]);

  const onInput = useCallback(
    (v: string) => {
      setQuery(v);

      if (debounceRef.current) window.clearTimeout(debounceRef.current);
      debounceRef.current = window.setTimeout(() => {
        loadSuggestions(v);
      }, 200);
    },
    [loadSuggestions]
  );

  const attachTag = useCallback((t: TagDto) => {
    const id = normalizeId(t.id);
    if (!id) return;

    setSelectedTags((prev) => {
      if (prev.some((x) => x.id === id)) return prev;
      return uniqById([...prev, { id, title: String(t.title ?? ""), slug: String(t.slug ?? "") }]);
    });

    setQuery("");
    setSuggestions([]);
    setStatus("OK");
    window.setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  const removeTag = useCallback((id: number) => {
    setSelectedTags((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const findExactSuggestion = useCallback(
    (q: string): TagDto | null => {
      const s = (q || "").trim().toLowerCase();
      if (!s) return null;
      for (const t of suggestions) {
        if (String(t.title ?? "").trim().toLowerCase() === s) return t;
      }
      return null;
    },
    [suggestions]
  );

  const addFromInput = useCallback(async () => {
    const q = (query || "").trim();
    if (!q) return;

    const exact = findExactSuggestion(q);
    if (exact && normalizeId(exact.id)) {
      attachTag(exact);
      return;
    }

    setStatus("Δημιουργία tag…");

    try {
      const created = await fetchJson<TagDto>(tagsCreateUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ title: q }),
      });

      if (!created || !normalizeId(created.id)) {
        setStatus("Tag create failed (invalid response)");
        return;
      }

      attachTag(created);
    } catch {
      setStatus("Tag create failed (έλεγξε POST /songs/tags)");
      alert("Αποτυχία δημιουργίας tag. Έλεγξε POST /songs/tags (auth/cookies/CORS).");
    }
  }, [attachTag, findExactSuggestion, query, tagsCreateUrl]);

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addFromInput();
      }
    },
    [addFromInput]
  );

  useEffect(() => {
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, []);

  return (
    <div className="song-edit-section">
      <h2 className="song-edit-section-title">Tags</h2>

      {/* hidden input που διαβάζει το Next route (/api/songs/[id]) */}
      <input type="hidden" id="tagIdsJson" name="tagIdsJson" value={JSON.stringify(selectedIds)} readOnly />

      <div style={{ border: "1px solid #333", borderRadius: 10, padding: 12, background: "#0f0f0f" }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {selectedTags.length === 0 ? (
            <span style={{ opacity: 0.8 }}>Δεν υπάρχουν tags.</span>
          ) : (
            selectedTags.map((t) => (
              <span
                key={t.id}
                style={{
                  border: "1px solid #444",
                  borderRadius: 999,
                  padding: "4px 10px",
                  display: "inline-flex",
                  gap: 8,
                  alignItems: "center",
                }}
              >
                <span>{t.title}</span>
                <button
                  type="button"
                  onClick={() => removeTag(t.id)}
                  style={{
                    border: "1px solid #555",
                    borderRadius: 999,
                    padding: "0px 8px",
                    background: "transparent",
                    cursor: "pointer",
                  }}
                  aria-label={`Αφαίρεση tag ${t.title}`}
                  title="Αφαίρεση"
                >
                  ×
                </button>
              </span>
            ))
          )}
        </div>

        <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onFocus={onFocus}
            onChange={(e) => onInput(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Πληκτρολόγησε tag…"
            list="tagSuggestions"
            style={{ minWidth: 260 }}
            autoComplete="off"
          />

          <datalist id="tagSuggestions">
            {suggestions.map((t) => (
              <option key={t.id} value={t.title} />
            ))}
          </datalist>

          <button type="button" onClick={addFromInput}>
            Προσθήκη
          </button>

          <span style={{ opacity: 0.75, fontSize: 12 }}>{status}</span>

          <small style={{ opacity: 0.8 }}>
            Στέλνονται tagIds στο <code>tagIdsJson</code>.
          </small>
        </div>
      </div>
    </div>
  );
}
