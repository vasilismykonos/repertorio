// apps/api/src/songs/songs.service.ts

import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import {
  AssetKind,
  AssetType,
  SongCreditRole,
  SongStatus,
  VersionArtistRole,
} from "@prisma/client";

type TagDto = {
  id: number;
  title: string;
  slug: string;
};

type SongAssetDto = {
  id: number;
  kind: AssetKind;
  type: AssetType;
  title: string | null;
  url: string | null;
  filePath: string | null;
  mimeType: string | null;
  sizeBytes: string | null;

  label: string | null;
  sort: number;
  isPrimary: boolean;
};

type SongVersionDto = {
  id: number;
  year: number | null;
  singerFront: string | null;
  singerBack: string | null;
  solist: string | null;
  youtubeSearch: string | null;

  singerFrontId?: number | null;
  singerBackId?: number | null;
  solistId?: number | null;
};

type SongDetailDto = {
  id: number;
  legacySongId: number;
  scoreFile: string | null;
  hasScore: boolean;

  title: string;
  firstLyrics: string | null;
  lyrics: string | null;

  // legacy/compat
  characteristics: string | null;

  // ✅ NEW (EXPLICIT μέσω join tables)
  tags: TagDto[];
  assets: SongAssetDto[];

  originalKey: string | null;
  chords: string | null;
  status: string | null;

  categoryId: number | null;
  rythmId: number | null;
  makamId: number | null;

  categoryTitle: string | null;
  composerName: string | null;
  lyricistName: string | null;
  rythmTitle: string | null;

  basedOnSongId: number | null;
  basedOnSongTitle: string | null;

  views: number;

  createdByUserId: number | null;

  versions: SongVersionDto[];
};

function buildArtistDisplayName(a: {
  title: string;
  firstName: string | null;
  lastName: string | null;
}): string {
  const full = `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim();
  return full || a.title;
}

/**
 * Παράγει firstLyrics από τους στίχους:
 * - παίρνει την ΠΡΩΤΗ μη-κενή γραμμή
 * - κάνει trim
 * - επιστρέφει null αν δεν υπάρχει περιεχόμενο
 */
function extractFirstLyricsFromLyrics(
  lyrics: string | null | undefined,
): string | null {
  if (lyrics === null || lyrics === undefined) return null;
  const text = String(lyrics);
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  for (const line of lines) {
    const t = line.trim();
    if (t) return t.length > 300 ? t.slice(0, 300) : t;
  }
  return null;
}

function toNullableBigIntString(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  try {
    if (typeof v === "bigint") return v.toString();
    if (typeof v === "number" && Number.isFinite(v)) return BigInt(v).toString();
    if (typeof v === "string" && v.trim() !== "") return BigInt(v.trim()).toString();
    return null;
  } catch {
    return null;
  }
}

function toNullableBigInt(v: unknown): bigint | null {
  if (v === null || v === undefined) return null;
  try {
    if (typeof v === "bigint") return v;
    if (typeof v === "number" && Number.isFinite(v)) return BigInt(v);
    if (typeof v === "string" && v.trim() !== "") return BigInt(v.trim());
    return null;
  } catch {
    throw new BadRequestException("Invalid sizeBytes (must be integer/bigint)");
  }
}

type UpdateSongBody = {
  title?: string;
  firstLyrics?: string | null;
  lyrics?: string | null;

  // legacy/compat
  characteristics?: string | null;

  originalKey?: string | null;
  defaultKey?: string | null;
  chords?: string | null;
  status?: SongStatus;
  categoryId?: number | null;
  rythmId?: number | null;
  basedOnSongId?: number | null;
  scoreFile?: string | null;
  highestVocalNote?: string | null;

  // ✅ NEW (tags replace-all)
  tagIds?: number[] | null;

  // ✅ NEW (assets replace-all)
  assets?: Array<{
    id?: number;
    kind: AssetKind;
    type?: AssetType;
    title?: string | null;
    url?: string | null;
    filePath?: string | null;
    mimeType?: string | null;
    sizeBytes?: string | number | bigint | null;

    // relation metadata
    label?: string | null;
    sort?: number | null;
    isPrimary?: boolean | null;
  }> | null;
};

@Injectable()
export class SongsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Επιστρέφει 1 τραγούδι σε DTO συμβατό με το SongDetail του Next.
   * Αν noIncrement=true δεν αυξάνει τα views.
   */
  async findOne(id: number, noIncrement = false): Promise<SongDetailDto> {
    const song = await this.prisma.song.findUnique({
      where: { id },
      include: {
        category: true,
        rythm: true,
        basedOnSong: { select: { id: true, title: true } },
        credits: { include: { artist: true } },
        versions: {
          include: {
            artists: { include: { artist: true } },
          },
        },

        // ✅ EXPLICIT: Tags μέσω SongTag
        // Στο schema σου το relation field στο Song λέγεται "SongTag" (ΚΕΦΑΛΑΙΑ)
        SongTag: {
          include: {
            // Στο schema σου το relation field στο SongTag λέγεται "Tag" (ΚΕΦΑΛΑΙΑ)
            Tag: { select: { id: true, title: true, slug: true } },
          },
          orderBy: [{ tagId: "asc" }],
        },

        // ✅ EXPLICIT: Assets μέσω SongAsset
        // Στο schema σου το relation field στο Song λέγεται "SongAsset" (ΚΕΦΑΛΑΙΑ)
        SongAsset: {
          include: {
            // Στο schema σου το relation field στο SongAsset λέγεται "Asset" (ΚΕΦΑΛΑΙΑ)
            Asset: true,
          },
          orderBy: [{ sort: "asc" }, { assetId: "asc" }],
        },
      },
    });

    if (!song) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    if (!noIncrement) {
      await this.prisma.song.update({
        where: { id },
        data: { views: { increment: 1 } },
      });
    }

    const categoryTitle = song.category?.title ?? null;
    const rythmTitle = song.rythm?.title ?? null;

    const composerArtists = (song.credits ?? [])
      .filter((c) => c.role === SongCreditRole.COMPOSER && c.artist)
      .map((c) => c.artist);

    const lyricistArtists = (song.credits ?? [])
      .filter((c) => c.role === SongCreditRole.LYRICIST && c.artist)
      .map((c) => c.artist);

    const composerName =
      composerArtists.length > 0
        ? composerArtists.map((a) => buildArtistDisplayName(a)).join(", ")
        : null;

    const lyricistName =
      lyricistArtists.length > 0
        ? lyricistArtists.map((a) => buildArtistDisplayName(a)).join(", ")
        : null;

    const basedOnSongId = song.basedOnSong?.id ?? null;
    const basedOnSongTitle = song.basedOnSong?.title ?? null;

    const versions: SongVersionDto[] =
      song.versions?.map((v) => {
        const frontArray = (v.artists ?? []).filter(
          (x) => x.role === VersionArtistRole.SINGER_FRONT,
        );
        const backArray = (v.artists ?? []).filter(
          (x) => x.role === VersionArtistRole.SINGER_BACK,
        );
        const soloArray = (v.artists ?? []).filter(
          (x) => x.role === VersionArtistRole.SOLOIST,
        );

        const singerFront =
          frontArray.length > 0
            ? frontArray
                .map((x) => x.artist)
                .filter((a): a is NonNullable<typeof a> => !!a)
                .map((a) => buildArtistDisplayName(a))
                .join(", ")
            : null;

        const singerBack =
          backArray.length > 0
            ? backArray
                .map((x) => x.artist)
                .filter((a): a is NonNullable<typeof a> => !!a)
                .map((a) => buildArtistDisplayName(a))
                .join(", ")
            : null;

        const solist =
          soloArray.length > 0
            ? soloArray
                .map((x) => x.artist)
                .filter((a): a is NonNullable<typeof a> => !!a)
                .map((a) => buildArtistDisplayName(a))
                .join(", ")
            : null;

        const singerFrontId = frontArray.length > 0 ? frontArray[0].artistId : null;
        const singerBackId = backArray.length > 0 ? backArray[0].artistId : null;
        const solistId = soloArray.length > 0 ? soloArray[0].artistId : null;

        return {
          id: v.id,
          year: v.year ?? null,
          singerFront,
          singerBack,
          solist,
          youtubeSearch: v.youtubeSearch ?? null,
          singerFrontId,
          singerBackId,
          solistId,
        };
      }) ?? [];

    // ✅ εδώ αλλάζει: song.songTags -> song.SongTag και st.tag -> st.Tag
    const tags: TagDto[] = (song.SongTag ?? [])
      .map((st) => st.Tag)
      .filter((t): t is NonNullable<typeof t> => !!t)
      .map((t) => ({ id: t.id, title: t.title, slug: t.slug }));

    // ✅ εδώ αλλάζει: song.songAssets -> song.SongAsset και sa.asset -> sa.Asset
    const assets: SongAssetDto[] = (song.SongAsset ?? []).map((sa) => ({
      id: sa.Asset.id,
      kind: sa.Asset.kind,
      type: sa.Asset.type,
      title: sa.Asset.title ?? null,
      url: sa.Asset.url ?? null,
      filePath: sa.Asset.filePath ?? null,
      mimeType: sa.Asset.mimeType ?? null,
      sizeBytes: toNullableBigIntString(sa.Asset.sizeBytes),

      label: sa.label ?? null,
      sort: sa.sort ?? 0,
      isPrimary: sa.isPrimary ?? false,
    }));

    const views = (song.views ?? 0) + (noIncrement ? 0 : 1);

    return {
      id: song.id,
      legacySongId: song.legacySongId,
      scoreFile: song.scoreFile ?? null,
      hasScore: song.hasScore ?? false,

      title: song.title,
      firstLyrics: song.firstLyrics ?? null,
      lyrics: song.lyrics ?? null,

      characteristics: song.characteristics ?? null,

      tags,
      assets,

      originalKey: song.originalKey ?? null,
      chords: song.chords ?? null,
      status: song.status ?? null,

      categoryId: song.categoryId ?? null,
      rythmId: song.rythmId ?? null,
      makamId: null,

      categoryTitle,
      composerName,
      lyricistName,
      rythmTitle,

      basedOnSongId,
      basedOnSongTitle,

      views,

      createdByUserId: song.createdByUserId ?? null,

      versions,
    };
  }

  private validateAssetInput(input: {
    kind: AssetKind;
    url?: string | null;
    filePath?: string | null;
  }) {
    if (input.kind === AssetKind.LINK) {
      const url = (input.url ?? "").trim();
      if (!url) throw new BadRequestException("Asset LINK requires url");
    }
    if (input.kind === AssetKind.FILE) {
      const fp = (input.filePath ?? "").trim();
      if (!fp) throw new BadRequestException("Asset FILE requires filePath");
    }
  }

  async updateSong(id: number, body: UpdateSongBody) {
    const existing = await this.prisma.song.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException(`Song with id=${id} not found`);
    }

    const data: any = {};

    if (typeof body.title === "string") data.title = body.title;

    // ✅ Αν έρχονται lyrics, παράγουμε firstLyrics αυτόματα
    if (Object.prototype.hasOwnProperty.call(body, "lyrics")) {
      data.lyrics = body.lyrics;
      data.firstLyrics = extractFirstLyricsFromLyrics(body.lyrics);
    } else if (Object.prototype.hasOwnProperty.call(body, "firstLyrics")) {
      data.firstLyrics = body.firstLyrics;
    }

    if (Object.prototype.hasOwnProperty.call(body, "characteristics"))
      data.characteristics = body.characteristics;

    if (Object.prototype.hasOwnProperty.call(body, "originalKey"))
      data.originalKey = body.originalKey;

    if (Object.prototype.hasOwnProperty.call(body, "defaultKey"))
      data.defaultKey = body.defaultKey;

    if (Object.prototype.hasOwnProperty.call(body, "highestVocalNote"))
      data.highestVocalNote = body.highestVocalNote;

    if (Object.prototype.hasOwnProperty.call(body, "chords"))
      data.chords = body.chords;

    if (Object.prototype.hasOwnProperty.call(body, "scoreFile"))
      data.scoreFile = body.scoreFile;

    if (body.status && Object.values(SongStatus).includes(body.status)) {
      data.status = body.status;
    }

    if (Object.prototype.hasOwnProperty.call(body, "categoryId"))
      data.categoryId = body.categoryId;

    if (Object.prototype.hasOwnProperty.call(body, "rythmId"))
      data.rythmId = body.rythmId;

    if (Object.prototype.hasOwnProperty.call(body, "basedOnSongId"))
      data.basedOnSongId = body.basedOnSongId;

    const hasTagIds = Object.prototype.hasOwnProperty.call(body, "tagIds");
    const hasAssets = Object.prototype.hasOwnProperty.call(body, "assets");

    if (Object.keys(data).length === 0 && !hasTagIds && !hasAssets) {
      return this.findOne(id, true);
    }

    await this.prisma.$transaction(async (tx) => {
      // 1) Song core fields
      if (Object.keys(data).length > 0) {
        await tx.song.update({
          where: { id },
          data,
        });
      }

      // 2) Tags (EXPLICIT): replace-all μέσω SongTag
      if (hasTagIds) {
        const ids = Array.isArray(body.tagIds)
          ? body.tagIds.filter((x) => typeof x === "number" && Number.isFinite(x))
          : [];

        await tx.songTag.deleteMany({ where: { songId: id } });

        if (ids.length > 0) {
          await tx.songTag.createMany({
            data: ids.map((tagId) => ({ songId: id, tagId })),
            skipDuplicates: true,
          });
        }
      }

      // 3) Assets (EXPLICIT): replace-all μέσω SongAsset
      if (hasAssets) {
        const assets = Array.isArray(body.assets) ? body.assets : [];

        await tx.songAsset.deleteMany({ where: { songId: id } });

        for (let i = 0; i < assets.length; i++) {
          const a = assets[i];

          const kind = a.kind;
          const type = a.type ?? AssetType.GENERIC;

          this.validateAssetInput({
            kind,
            url: a.url ?? null,
            filePath: a.filePath ?? null,
          });

          const sort =
            typeof a.sort === "number" && Number.isFinite(a.sort) ? a.sort : i * 10;

          const isPrimary = a.isPrimary === true;

          let assetId: number;

          if (typeof a.id === "number" && Number.isFinite(a.id)) {
            const updated = await tx.asset.update({
              where: { id: a.id },
              data: {
                kind,
                type,
                title: Object.prototype.hasOwnProperty.call(a, "title")
                  ? (a.title ?? null)
                  : undefined,
                url: kind === AssetKind.LINK ? (a.url ?? null) : null,
                filePath: kind === AssetKind.FILE ? (a.filePath ?? null) : null,
                mimeType: Object.prototype.hasOwnProperty.call(a, "mimeType")
                  ? (a.mimeType ?? null)
                  : undefined,
                sizeBytes: Object.prototype.hasOwnProperty.call(a, "sizeBytes")
                  ? toNullableBigInt(a.sizeBytes ?? null)
                  : undefined,
              },
              select: { id: true },
            });
            assetId = updated.id;
          } else {
            const created = await tx.asset.create({
              data: {
                kind,
                type,
                title: a.title ?? null,
                url: kind === AssetKind.LINK ? (a.url ?? null) : null,
                filePath: kind === AssetKind.FILE ? (a.filePath ?? null) : null,
                mimeType: a.mimeType ?? null,
                sizeBytes: toNullableBigInt(a.sizeBytes ?? null),
              },
              select: { id: true },
            });
            assetId = created.id;
          }

          await tx.songAsset.create({
            data: {
              songId: id,
              assetId,
              label: a.label ?? null,
              sort,
              isPrimary,
            },
          });
        }
      }
    });

    return this.findOne(id, true);
  }
}
