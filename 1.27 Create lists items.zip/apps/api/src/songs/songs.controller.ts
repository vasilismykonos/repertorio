// src/songs/songs.controller.ts
import {
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Query,
} from "@nestjs/common";
import { SongsService } from "./songs.service";

@Controller("songs")
export class SongsController {
  constructor(private readonly songsService: SongsService) {}

  /**
   * Επιστρέφει ένα τραγούδι σε μορφή DTO, συμβατή
   * με το SongDetail του Next (SongPage.tsx).
   *
   * Αν καλέσεις /songs/:id?noIncrement=1 → ΔΕΝ αυξάνει views.
   * Αλλιώς αυξάνει views κατά 1.
   */
  @Get(":id")
  async getSongById(
    @Param("id", ParseIntPipe) id: number,
    @Query("noIncrement") noIncrement?: string,
  ) {
    const skipIncrement =
      noIncrement === "1" || noIncrement === "true" || noIncrement === "yes";
    return this.songsService.findOne(id, skipIncrement);
  }
}
