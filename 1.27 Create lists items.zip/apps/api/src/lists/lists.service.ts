// apps/api/src/lists/lists.service.ts

import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import mysql from "mysql2/promise";

type ListSummaryDto = {
  id: number;
  title: string;
  groupId: number | null;
  marked: boolean;
};

type ListGroupSummaryDto = {
  id: number;
  title: string;
  fullTitle: string | null;
  listsCount: number;
};

type ListItemDto = {
  listItemId: number;
  listId: number;
  sortId: number;
  notes: string | null;
  transport: number;
  rythmId: number | null;
  title: string;
  songId: number | null;
  // Πηγές / περιεχόμενο στίχων & συγχορδιών
  chordsSource: "LIST" | "SONG" | "NONE";
  chords: string | null;
  lyricsSource: "LIST" | "SONG" | "NONE";
  lyrics: string | null;
};

type ListDetailDto = {
  id: number;
  title: string;
  notes: string | null;
  groupId: number | null;
  groupTitle: string | null;
  marked: boolean;
  role: "EDITOR" | "VIEWER";
  items: ListItemDto[];
};

type ListsIndexResponse = {
  items: ListSummaryDto[];
  total: number;
  page: number;
  pageSize: number;
  groups: ListGroupSummaryDto[];
};

type ListItemsResponse = {
  items: ListItemDto[];
  total: number;
  page: number;
  pageSize: number;
};

@Injectable()
export class ListsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Επιστρέφει το legacy WP user ID (wpId) για έναν νέο User.id.
   * Αν δεν υπάρχει, επιστρέφει null και η πρόσβαση σε λίστες είναι κενή.
   */
  private async getLegacyUserId(userId: number): Promise<number | null> {
    if (!userId) return null;

    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { wpId: true },
    });

    if (!user) return null;
    return user.wpId ?? null;
  }

  /**
   * Δημιουργεί connection προς την παλιά MySQL βάση (WordPress),
   * χρησιμοποιώντας τα ίδια OLD_DB_* env vars που χρησιμοποιούνται
   * ήδη στο SongsService.
   */
  private async getMysqlConnection() {
    const {
      OLD_DB_HOST,
      OLD_DB_PORT,
      OLD_DB_USER,
      OLD_DB_PASSWORD,
      OLD_DB_NAME,
    } = process.env;

    if (!OLD_DB_HOST || !OLD_DB_USER || !OLD_DB_NAME) {
      throw new Error(
        "OLD_DB_* environment variables are not configured for legacy MySQL connection",
      );
    }

    const connection = await mysql.createConnection({
      host: OLD_DB_HOST,
      port: Number(OLD_DB_PORT || 3306),
      user: OLD_DB_USER,
      password: OLD_DB_PASSWORD,
      database: OLD_DB_NAME,
      charset: "utf8mb4_general_ci",
    });

    return connection;
  }

  /**
   * Helper για parsing comma-separated λιστών IDs (Edit / View).
   */
  private parseIdList(value: any): number[] {
    if (value === null || value === undefined) return [];
    const s = String(value).trim();
    if (!s) return [];
    return s
      .split(",")
      .map((part) => Number(part.trim()))
      .filter((n) => Number.isFinite(n) && n > 0);
  }

  /**
   * Υπολογισμός ρόλου χρήστη σε λίστα, σύμφωνα με τη λογική του get_list_role()
   * στο παλιό list.php:
   * - Owner: UserID == legacyUserId
   * - Editor: μέσα στο Edit ή Owner
   * - Viewer: μέσα στο View
   *
   * Αν δεν έχει καθόλου δικαίωμα, επιστρέφει null (για Forbidden).
   */
  private computeListRole(
    legacyUserId: number | null,
    row: {
      UserID: any;
      Edit: any;
      View: any;
    },
  ): "EDITOR" | "VIEWER" | null {
    if (!legacyUserId) return null;

    const ownerId = Number(row.UserID ?? 0) || 0;
    const editIds = this.parseIdList(row.Edit);
    const viewIds = this.parseIdList(row.View);

    const isOwner = ownerId === legacyUserId;
    const isEditor = isOwner || editIds.includes(legacyUserId);
    const isViewer = viewIds.includes(legacyUserId);

    if (isEditor) return "EDITOR";
    if (isViewer) return "VIEWER";
    return null;
  }

  /**
   * Λίστα λιστών για συγκεκριμένο χρήστη (με βάση το νέο User.id).
   * Διαβάζει από τα παλιά tables:
   * - lists
   * - group_lists
   *
   * Εφαρμόζει τα δικαιώματα View/Edit όπως στο lists.php.
   */
  async getListsForUser(params: {
    userId: number;
    search?: string;
    groupId?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListsIndexResponse> {
    const { userId, search, groupId, page = 1, pageSize = 20 } = params;

    const legacyUserId = await this.getLegacyUserId(userId);
    if (!legacyUserId) {
      // Αν δεν υπάρχει mapping σε wpId, δεν υπάρχουν λίστες στο παλιό σύστημα
      return {
        items: [],
        total: 0,
        page,
        pageSize,
        groups: [],
      };
    }

    const safePage = Math.max(page, 1);
    const safePageSize = Math.min(Math.max(pageSize, 1), 100);
    const offset = (safePage - 1) * safePageSize;

    const trimmedSearch = (search || "").trim();

    let connection: mysql.Connection | null = null;

    try {
      connection = await this.getMysqlConnection();

      // WHERE φίλτρο για δικαιώματα προβολής (όπως $view_filter στο lists.php)
      const whereParts: string[] = [];
      const paramsBase: any[] = [];

      whereParts.push(
        "(FIND_IN_SET(?, `View`) > 0 OR FIND_IN_SET(?, `Edit`) > 0 OR `UserID` = ?)",
      );
      paramsBase.push(legacyUserId, legacyUserId, legacyUserId);

      if (trimmedSearch) {
        whereParts.push("(`Title` LIKE ?)");
        paramsBase.push(`%${trimmedSearch}%`);
      }

      if (groupId !== undefined && groupId !== "") {
        if (groupId === "null") {
          // "Χωρίς ομάδα" όπως στο παλιό site
          whereParts.push(
            "(`Group_List_ID` IS NULL OR `Group_List_ID` = '' OR `Group_List_ID` = 0)",
          );
        } else {
          const gidNum = Number(groupId);
          if (Number.isFinite(gidNum) && gidNum > 0) {
            whereParts.push("`Group_List_ID` = ?");
            paramsBase.push(gidNum);
          }
        }
      }

      const whereClause =
        whereParts.length > 0 ? "WHERE " + whereParts.join(" AND ") : "";

      const baseFromClause = `
        FROM lists
        ${whereClause}
      `;

      // Συνολικός αριθμός λιστών
      const [countRows] = await connection.execute<any[]>(
        `SELECT COUNT(*) AS total ${baseFromClause}`,
        paramsBase,
      );
      const total = Number(countRows[0]?.total ?? 0);

      // Δεδομένα λιστών (summary)
      const [listRows] = await connection.execute<any[]>(
        `
        SELECT
          List_ID,
          Title,
          Group_List_ID,
          UserID,
          View,
          Edit,
          Marked
        ${baseFromClause}
        ORDER BY Marked DESC, Title ASC
        LIMIT ? OFFSET ?
        `,
        [...paramsBase, safePageSize, offset],
      );

      const items: ListSummaryDto[] = listRows.map((row) => ({
        id: Number(row.List_ID),
        title: row.Title ?? "",
        groupId:
          row.Group_List_ID === null ||
          row.Group_List_ID === "" ||
          Number(row.Group_List_ID) === 0
            ? null
            : Number(row.Group_List_ID),
        marked: Boolean(row.Marked && Number(row.Marked) !== 0),
      }));

      // Groups – βασισμένο στο group_lists + lists, για τον χρήστη
      const [groupRows] = await connection.execute<any[]>(
        `
        SELECT
          gl.Group_List_ID AS id,
          gl.Title AS title,
          gl.FullTitle AS fullTitle,
          COUNT(DISTINCT l.List_ID) AS listsCount
        FROM group_lists gl
        LEFT JOIN lists l
          ON l.Group_List_ID = gl.Group_List_ID
          AND (
            FIND_IN_SET(?, l.View) > 0
            OR FIND_IN_SET(?, l.Edit) > 0
            OR l.UserID = ?
          )
        WHERE
          (FIND_IN_SET(?, gl.View) > 0
           OR FIND_IN_SET(?, gl.Edit) > 0
           OR gl.UserID = ?)
        GROUP BY gl.Group_List_ID, gl.Title, gl.FullTitle
        ORDER BY gl.Title ASC
        `,
        [
          legacyUserId,
          legacyUserId,
          legacyUserId,
          legacyUserId,
          legacyUserId,
          legacyUserId,
        ],
      );

      const groups: ListGroupSummaryDto[] = groupRows.map((row) => ({
        id: Number(row.id),
        title: row.title ?? "",
        fullTitle: row.fullTitle ?? null,
        listsCount: Number(row.listsCount ?? 0),
      }));

      return {
        items,
        total,
        page: safePage,
        pageSize: safePageSize,
        groups,
      };
    } finally {
      if (connection) {
        await connection.end();
      }
    }
  }

  /**
   * Λεπτομέρειες συγκεκριμένης λίστας:
   * - Metadata λίστας
   * - Ρόλος χρήστη (EDITOR/VIEWER)
   * - Αντικείμενα λίστας (items) με βάση το lists_items + songs,
   *   όπως στο list_item.php.
   *
   * Αν ο χρήστης δεν έχει δικαίωμα ( ούτε Editor ούτε Viewer ), γίνεται NotFound,
   * όπως και στο παλιό list.php που έλεγε "Δεν έχετε δικαίωμα να δείτε αυτή τη λίστα."
   */
  async getListDetail(params: {
    userId: number;
    listId: number;
  }): Promise<ListDetailDto> {
    const { userId, listId } = params;

    const legacyUserId = await this.getLegacyUserId(userId);
    if (!legacyUserId) {
      throw new NotFoundException("Λίστα δεν βρέθηκε ή δεν έχετε πρόσβαση.");
    }

    let connection: mysql.Connection | null = null;

    try {
      connection = await this.getMysqlConnection();

      // 1. Ανάγνωση λίστας
      const [listRows] = await connection.execute<any[]>(
        `
        SELECT
          List_ID,
          Title,
          Group_List_ID,
          UserID,
          View,
          Edit,
          Marked
        FROM lists
        WHERE List_ID = ?
        LIMIT 1
        `,
        [listId],
      );

      if (!listRows || listRows.length === 0) {
        throw new NotFoundException("Η λίστα δεν βρέθηκε.");
      }

      const listRow = listRows[0];

      const role = this.computeListRole(legacyUserId, {
        UserID: listRow.UserID,
        Edit: listRow.Edit,
        View: listRow.View,
      });

      if (!role) {
        // Όπως στο παλιό PHP: "Δεν έχετε δικαίωμα να δείτε αυτήν την λίστα."
        throw new NotFoundException("Λίστα δεν βρέθηκε ή δεν έχετε πρόσβαση.");
      }

      const rawGroupId = listRow.Group_List_ID;
      const groupId =
        rawGroupId === null ||
        rawGroupId === "" ||
        Number(rawGroupId) === 0
          ? null
          : Number(rawGroupId);

      // 2. Τίτλος ομάδας (group_lists)
      let groupTitle: string | null = null;
      if (groupId !== null) {
        const [groupRows] = await connection.execute<any[]>(
          `
          SELECT FullTitle
          FROM group_lists
          WHERE Group_List_ID = ?
          LIMIT 1
          `,
          [groupId],
        );
        if (groupRows && groupRows.length > 0) {
          groupTitle = groupRows[0].FullTitle ?? null;
        }
      }

      // 3. Αντικείμενα λίστας (lists_items + songs)
      const [itemRows] = await connection.execute<any[]>(
        `
        SELECT
          li.ListItem_ID AS listItemId,
          li.List_ID AS listId,
          li.Sort_ID AS sortId,
          li.Notes AS notes,
          li.Transport AS transport,
          li.Rythm_ID AS li_Rythm_ID,
          li.Title AS li_Title,
          li.Chords AS li_Chords,
          li.Lyrics AS li_Lyrics,
          li.Song_ID AS li_Song_ID,
          s.Song_ID AS s_song_id,
          s.Title AS s_title,
          s.Lyrics AS s_lyrics,
          s.Chords AS s_Chords,
          s.Rythm_ID AS s_Rythm_ID
        FROM lists_items li
        LEFT JOIN songs s
          ON li.Song_ID = s.Song_ID
        WHERE li.List_ID = ?
        ORDER BY li.Sort_ID ASC
        `,
        [listId],
      );

      const items: ListItemDto[] = itemRows.map((row) => {
        const listItemId = Number(row.listItemId);
        const listIdVal = Number(row.listId);
        const sortId = Number(row.sortId ?? 0);
        const notes = row.notes ?? null;
        const transport = Number(row.transport ?? 0) || 0;

        const liTitle = row.li_Title ?? "";
        const sTitle = row.s_title ?? "";
        const title = liTitle || sTitle || "";

        const liChords = row.li_Chords ?? null;
        const sChords = row.s_Chords ?? null;
        let chordsSource: "LIST" | "SONG" | "NONE" = "NONE";
        let chords: string | null = null;
        if (liChords && String(liChords).trim() !== "") {
          chordsSource = "LIST";
          chords = String(liChords);
        } else if (sChords && String(sChords).trim() !== "") {
          chordsSource = "SONG";
          chords = String(sChords);
        }

        const liLyrics = row.li_Lyrics ?? null;
        const sLyrics = row.s_lyrics ?? null;
        let lyricsSource: "LIST" | "SONG" | "NONE" = "NONE";
        let lyrics: string | null = null;
        if (liLyrics && String(liLyrics).trim() !== "") {
          lyricsSource = "LIST";
          lyrics = String(liLyrics);
        } else if (sLyrics && String(sLyrics).trim() !== "") {
          lyricsSource = "SONG";
          lyrics = String(sLyrics);
        }

        const liRythmId =
          row.li_Rythm_ID === null || row.li_Rythm_ID === ""
            ? null
            : Number(row.li_Rythm_ID);
        const sRythmId =
          row.s_Rythm_ID === null || row.s_Rythm_ID === ""
            ? null
            : Number(row.s_Rythm_ID);
        const rythmId = liRythmId ?? sRythmId ?? null;

        const listSongId =
          row.li_Song_ID === null || row.li_Song_ID === ""
            ? null
            : Number(row.li_Song_ID);
        const songId =
          listSongId ??
          (row.s_song_id === null || row.s_song_id === ""
            ? null
            : Number(row.s_song_id));

        return {
          listItemId,
          listId: listIdVal,
          sortId,
          notes,
          transport,
          rythmId,
          title,
          songId,
          chordsSource,
          chords,
          lyricsSource,
          lyrics,
        };
      });

      const detail: ListDetailDto = {
        id: Number(listRow.List_ID),
        title: listRow.Title ?? "",
        // Σημειώσεις λίστας: στο παλιό schema δεν υπήρχε πεδίο Notes στον πίνακα lists,
        // οπότε τις αφήνουμε null (τα Notes είναι ανά list_item).
        notes:
          typeof (listRow as any).Notes === "string"
            ? (listRow as any).Notes
            : null,
        groupId,
        groupTitle,
        marked: Boolean(listRow.Marked && Number(listRow.Marked) !== 0),
        role,
        items,
      };

      return detail;
    } finally {
      if (connection) {
        await connection.end();
      }
    }
  }

  /**
   * Επιπλέον endpoint για λίστα items (π.χ. /lists/:id/items),
   * που χρησιμοποιεί εσωτερικά το getListDetail και εφαρμόζει σελιδοποίηση.
   */
  async getListItems(params: {
    userId: number;
    listId: number;
    page?: number;
    pageSize?: number;
  }): Promise<ListItemsResponse> {
    const { userId, listId, page = 1, pageSize = 50 } = params;

    // Ξαναχρησιμοποιούμε ΟΛΗ τη λογική δικαιωμάτων + φόρτωσης από getListDetail
    const detail = await this.getListDetail({ userId, listId });

    const safePage = Math.max(page, 1);
    const safePageSize = Math.min(Math.max(pageSize, 1), 200);

    const total = detail.items.length;
    const offset = (safePage - 1) * safePageSize;

    const items = detail.items.slice(offset, offset + safePageSize);

    return {
      items,
      total,
      page: safePage,
      pageSize: safePageSize,
    };
  }
}
