// apps/api/src/lists/lists.controller.ts

import {
  BadRequestException,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Query,
} from "@nestjs/common";
import { ListsService } from "./lists.service";

@Controller("lists")
export class ListsController {
  constructor(private readonly listsService: ListsService) {}

  /**
   * GET /lists
   *
   * Query params:
   * - userId (υποχρεωτικό, νέο User.id)
   * - search (προαιρετικό)
   * - group (προαιρετικό: "", "null", ή αριθμός Group_List_ID)
   * - page (προαιρετικό, default 1)
   * - pageSize (προαιρετικό, default 20, max 100)
   */
  @Get()
  async getLists(
    @Query("userId") userIdStr?: string,
    @Query("search") search?: string,
    @Query("group") group?: string,
    @Query("page") pageStr?: string,
    @Query("pageSize") pageSizeStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Parameter 'userId' is required.");
    }
    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    const pageNum = Number(pageStr || "1");
    const pageSizeNum = Number(pageSizeStr || "20");

    return this.listsService.getListsForUser({
      userId: userIdNum,
      search,
      groupId: group,
      page: pageNum,
      pageSize: pageSizeNum,
    });
  }

  /**
   * GET /lists/:id
   *
   * Επιστρέφει:
   * - metadata λίστας
   * - group info
   * - ρόλο χρήστη (EDITOR/VIEWER)
   * - items (lists_items + songs)
   *
   * Query params:
   * - userId (υποχρεωτικό, νέο User.id, για να βρεθεί το wpId και τα δικαιώματα)
   */
  @Get(":id")
  async getListById(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Parameter 'userId' is required.");
    }
    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    return this.listsService.getListDetail({
      userId: userIdNum,
      listId: id,
    });
  }

  /**
   * GET /lists/:id/items
   *
   * Επιστρέφει ΜΟΝΟ τα items της λίστας (ListItemDto[]),
   * με τους ίδιους ελέγχους πρόσβασης όπως στο GET /lists/:id.
   *
   * Query params:
   * - userId (υποχρεωτικό, νέο User.id)
   */
  @Get(":id/items")
  async getListItemsById(
    @Param("id", ParseIntPipe) id: number,
    @Query("userId") userIdStr?: string,
  ) {
    if (!userIdStr) {
      throw new BadRequestException("Parameter 'userId' is required.");
    }
    const userIdNum = Number(userIdStr);
    if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
      throw new BadRequestException(
        "Parameter 'userId' must be a positive number.",
      );
    }

    return this.listsService.getListItems({
      userId: userIdNum,
      listId: id,
    });
  }
}
