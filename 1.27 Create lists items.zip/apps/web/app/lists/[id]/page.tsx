// apps/web/app/lists/[id]/page.tsx

import type { Metadata } from "next";
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import { getCurrentUserFromApi } from "@/lib/currentUser";

export const dynamic = "force-dynamic";

type ListItemDto = {
  listItemId: number;
  listId: number;
  sortId: number;
  notes: string | null;
  transport: number;
  rythmId: number | null;
  title: string;
  songId: number | null;
  chordsSource: "LIST" | "SONG" | "NONE";
  chords: string | null;
  lyricsSource: "LIST" | "SONG" | "NONE";
  lyrics: string | null;
};

type ListDetailDto = {
  id: number;
  title: string;
  notes: string | null;
  groupId: number | null;
  groupTitle: string | null;
  marked: boolean;
  role: "EDITOR" | "VIEWER";
  items: ListItemDto[];
};

type PageProps = {
  params: { id: string };
};

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const id = params.id;
  return {
    title: `Λίστα #${id} | Repertorio Next`,
  };
}

// Προαιρετικός χάρτης για transport -> label, αντίστοιχα με $notes_tunes στο παλιό list.php
const TRANSPORT_NOTES: Record<number, string> = {
  101: "Ντο",
  102: "Ντο#",
  103: "Ρε",
  104: "Ρε#",
  105: "Μι",
  106: "Φα",
  107: "Φα#",
  108: "Σολ",
  109: "Σολ#",
  110: "Λα",
  111: "Λα#",
  112: "Σι",
};

function formatTransport(transport: number): string {
  if (!Number.isFinite(transport) || transport === 0) return "—";
  if (TRANSPORT_NOTES[transport]) {
    return TRANSPORT_NOTES[transport];
  }
  // Fallback σε +N / N, αν βγούμε εκτός του κλασικού mapping
  return transport > 0 ? `+${transport}` : String(transport);
}

export default async function ListDetailPage({ params }: PageProps) {
  const rawId = params.id;
  const id = Number(rawId);

  if (!Number.isFinite(id) || id <= 0) {
    return (
      <section style={{ padding: "1rem" }}>
        <h1>Λίστα</h1>
        <p>Μη έγκυρο ID λίστας.</p>
      </section>
    );
  }

  const currentUser = await getCurrentUserFromApi();

  if (!currentUser) {
    return (
      <section style={{ padding: "1rem" }}>
        <h1>Λίστα</h1>
        <p>Πρέπει να είστε συνδεδεμένος για να δείτε τις λίστες.</p>
      </section>
    );
  }

  const apiUrl = `/lists/${id}?userId=${currentUser.id}`;

  let data: ListDetailDto;
  try {
    data = await fetchJson<ListDetailDto>(apiUrl);
  } catch (err: any) {
    return (
      <section style={{ padding: "1rem" }}>
        <h1>Λίστα</h1>
        <p>
          Η λίστα δεν βρέθηκε ή δεν έχετε δικαίωμα να τη δείτε (
          {String(err?.message || err)}).
        </p>
      </section>
    );
  }

  const { title, notes, groupTitle, marked, role, items } = data;

  return (
    <section style={{ padding: "1rem" }}>
      <header style={{ marginBottom: "1rem" }}>
        <h1 style={{ fontSize: "1.8rem", marginBottom: "0.3rem" }}>
          {marked && (
            <span
              aria-label="Αγαπημένη λίστα"
              title="Αγαπημένη λίστα"
              style={{ color: "#f5a623", marginRight: "0.35rem" }}
            >
              ★
            </span>
          )}
          {title || `Λίστα #${id}`}
        </h1>

        <div
          style={{
            fontSize: "0.9rem",
            color: "#555",
            display: "flex",
            flexWrap: "wrap",
            gap: "0.75rem",
            alignItems: "center",
          }}
        >
          <span>
            ID: <strong>{id}</strong>
          </span>

          <span>
            Ρόλος:{" "}
            <strong>{role === "EDITOR" ? "Επεξεργαστής" : "Προβολή"}</strong>
          </span>

          <span>
            Ομάδα:{" "}
            {groupTitle ? (
              <strong>{groupTitle}</strong>
            ) : (
              <strong>Χωρίς ομάδα</strong>
            )}
          </span>
        </div>

        {notes && (
          <p
            style={{
              marginTop: "0.5rem",
              fontSize: "0.9rem",
              color: "#444",
            }}
          >
            <strong>Σημειώσεις:</strong> {notes}
          </p>
        )}
      </header>

      {items.length === 0 ? (
        <p>Η λίστα δεν περιέχει τραγούδια.</p>
      ) : (
        <div
          style={{
            overflowX: "auto",
          }}
        >
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              fontSize: "0.9rem",
            }}
          >
            <thead>
              <tr>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "3rem",
                  }}
                >
                  #
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                  }}
                >
                  Τίτλος
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "6rem",
                  }}
                >
                  Τόνος
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "6rem",
                  }}
                >
                  Ρυθμός
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "6rem",
                  }}
                >
                  Στίχοι
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "7rem",
                  }}
                >
                  Συγχορδίες
                </th>
                <th
                  style={{
                    borderBottom: "1px solid #ddd",
                    textAlign: "left",
                    padding: "0.4rem",
                    width: "10rem",
                  }}
                >
                  Σημειώσεις
                </th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, idx) => {
                const rowNumber = idx + 1;
                const targetTitle =
                  item.title || `(αντικείμενο #${item.listItemId})`;

                const songLink =
                  item.songId && item.songId > 0
                    ? `/songs/${item.songId}`
                    : null;

                const rythmLabel =
                  item.rythmId === null ? "—" : `#${item.rythmId}`;

                const hasLyrics = item.lyricsSource !== "NONE";
                const hasChords = item.chordsSource !== "NONE";

                return (
                  <tr key={item.listItemId}>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {rowNumber}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {songLink ? (
                        <Link
                          href={songLink}
                          style={{
                            textDecoration: "none",
                            color: "#0070f3",
                            fontWeight: 500,
                          }}
                        >
                          {targetTitle}
                        </Link>
                      ) : (
                        <span>{targetTitle}</span>
                      )}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {formatTransport(item.transport)}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {rythmLabel}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {hasLyrics ? (
                        <span title="Υπάρχουν στίχοι">Ναι</span>
                      ) : (
                        <span>—</span>
                      )}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                      }}
                    >
                      {hasChords ? (
                        <span title="Υπάρχουν συγχορδίες">Ναι</span>
                      ) : (
                        <span>—</span>
                      )}
                    </td>
                    <td
                      style={{
                        borderBottom: "1px solid #f0f0f0",
                        padding: "0.4rem",
                        verticalAlign: "top",
                        maxWidth: "18rem",
                      }}
                    >
                      {item.notes ? (
                        <span>{item.notes}</span>
                      ) : (
                        <span style={{ color: "#aaa" }}>—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div style={{ marginTop: "1rem" }}>
        <Link href="/lists" style={{ textDecoration: "none", color: "#0070f3" }}>
          ← Επιστροφή στις λίστες
        </Link>
      </div>
    </section>
  );
}
