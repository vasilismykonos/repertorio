// apps/web/app/songs/page.tsx
import Link from "next/link";
import { fetchJson } from "@/lib/api";
import type { Option } from "./FilterSelectWithSearch";
import FiltersModal from "./FiltersModal";

export const dynamic = "force-dynamic";

type SongSearchItem = {
  song_id: number;
  title: string;
  firstLyrics: string;
  lyrics: string;
  characteristics: string;
  originalKey: string;
  chords: number | string | boolean | null;
  partiture: number | string | boolean | null;
  status: string;
  score: number;
  views: number | null;

  // Πιθανά πεδία για κατηγορία / ρυθμό (αν ο backend τα δίνει)
  category_id?: number | null;
  categoryId?: number | null;
  categoryTitle?: string | null;
  category?: string | null;
  category_title?: string | null;

  rythm_id?: number | null;
  rythmId?: number | null;
  rythmTitle?: string | null;
  rythm?: string | null;
  rhythm_id?: number | null;
  rhythmId?: number | null;
  rhythmTitle?: string | null;
};

type SongsSearchResponse = {
  total: number;
  items: SongSearchItem[];
};

type SongsPageSearchParams = {
  take?: string | string[];
  skip?: string | string[];

  q?: string | string[];
  search_term?: string | string[];

  chords?: string | string[];
  partiture?: string | string[];
  category_id?: string | string[];
  rythm_id?: string | string[];
  characteristics?: string | string[];
  lyrics?: string | string[];
  status?: string | string[];
  popular?: string | string[];
  createdByUserId?: string | string[];
};

type SongsPageProps = {
  searchParams?: SongsPageSearchParams;
};

type CategoryDto = {
  id: number;
  title: string;
  _count?: { songs?: number };
  songCount?: number;
  songsCount?: number;
  [key: string]: any;
};

type RythmDto = {
  id: number;
  title: string;
  _count?: { songs?: number };
  songCount?: number;
  songsCount?: number;
  [key: string]: any;
};

function normalizeParam(p: string | string[] | undefined): string {
  if (!p) return "";
  if (Array.isArray(p)) {
    return p
      .join(",")
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean)
      .join(",");
  }
  return p;
}

// επιστρέφει το ΠΡΩΤΟ αριθμητικό key (πέρα από id/title) ενός object
function detectNumericCountKey(obj: any): string | undefined {
  if (!obj || typeof obj !== "object") return undefined;
  for (const key of Object.keys(obj)) {
    if (key === "id" || key === "title") continue;
    const val = obj[key];
    if (typeof val === "number" && Number.isFinite(val)) {
      return key;
    }
  }
  return undefined;
}

// -------------------- helpers --------------------
function buildLyricsPreview(song: SongSearchItem): string {
  const characteristics = song.characteristics || "";
  const isOrganiko = characteristics.includes("Οργανικό");

  if (isOrganiko) {
    return "(Οργανικό)";
  }

  const lyrics = (song.lyrics || "").trim();
  if (!lyrics) {
    return "(Χωρίς διαθέσιμους στίχους)";
  }

  const base = (song.firstLyrics || "").trim() || lyrics;
  const words = base.split(/\s+/).filter(Boolean);
  const short = words.slice(0, 5).join(" ");
  return words.length > 5 ? `${short}...` : short;
}

function buildYoutubeUrl(song: SongSearchItem): string {
  const base = "https://www.youtube.com/results";
  const q = `${song.title || ""} ${song.firstLyrics || ""}`.trim();
  const params = new URLSearchParams({
    search_query: q || song.title || "",
    app: "revanced",
  });
  return `${base}?${params.toString()}`;
}

const YOUTUBE_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/youtube.png";
const GUITAR_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/guitar.png";
const SOL_ICON_URL =
  "https://repertorio.net/wp-content/plugins/repertorio/images/sol.png";

// -------------------- page --------------------
export default async function SongsPage({ searchParams }: SongsPageProps) {
  const take = Number(normalizeParam(searchParams?.take) || "50");
  const skip = Number(normalizeParam(searchParams?.skip) || "0");

  const qRaw =
    normalizeParam(searchParams?.q) ||
    normalizeParam(searchParams?.search_term) ||
    "";
  const q = qRaw.toString().trim();

  const chords = normalizeParam(searchParams?.chords);
  const partiture = normalizeParam(searchParams?.partiture);
  const category_id = normalizeParam(searchParams?.category_id);
  const rythm_id = normalizeParam(searchParams?.rythm_id);
  const characteristics = normalizeParam(searchParams?.characteristics);
  const lyrics = normalizeParam(searchParams?.lyrics);
  const status = normalizeParam(searchParams?.status);
  const popular = normalizeParam(searchParams?.popular);
  const createdByUserId = normalizeParam(searchParams?.createdByUserId);

  // -------------------- Φόρτωση Κατηγοριών / Ρυθμών --------------------
  let categories: CategoryDto[] = [];
  let rythms: RythmDto[] = [];

  try {
    const [catsRes, rythmsRes] = await Promise.all([
      fetchJson<CategoryDto[]>("/categories"),
      fetchJson<RythmDto[]>("/rythms"),
    ]);
    categories = Array.isArray(catsRes) ? catsRes : [];
    rythms = Array.isArray(rythmsRes) ? rythmsRes : [];
  } catch (err) {
    console.error("Failed to fetch categories/rythms", err);
  }

  // Αν δεν υπάρχει _count.songs, ψάχνουμε για ένα generic numeric key
  const categoryCountKey =
    categories.length > 0 ? detectNumericCountKey(categories[0]) : undefined;
  const rythmCountKey =
    rythms.length > 0 ? detectNumericCountKey(rythms[0]) : undefined;

  // -------------------- Αναζήτηση τραγουδιών --------------------
  const params = new URLSearchParams();
  params.set("take", String(take));
  params.set("skip", String(skip));

  if (q) {
    params.set("q", q);
    params.set("search_term", q);
    params.set("term", q);
    params.set("searchTerm", q);
  }
  if (chords) params.set("chords", chords);
  if (partiture) params.set("partiture", partiture);
  if (category_id) params.set("category_id", category_id);
  if (rythm_id) params.set("rythm_id", rythm_id);
  if (characteristics) params.set("characteristics", characteristics);
  if (lyrics) params.set("lyrics", lyrics);
  if (status) params.set("status", status);
  if (popular) params.set("popular", popular);
  if (createdByUserId) params.set("createdByUserId", createdByUserId);

  let data: SongsSearchResponse = { total: 0, items: [] };
  let songs: SongSearchItem[] = [];

  try {
    // Πρώτα Elasticsearch
    try {
      const apiUrlEs = `/songs-es/search?${params.toString()}`;
      data = await fetchJson<SongsSearchResponse>(apiUrlEs);
    } catch (errEs) {
      console.error(
        "[SongsPage] ES search failed, fallback to /songs/search",
        errEs,
      );
      try {
        const apiUrlFallback = `/songs/search?${params.toString()}`;
        data = await fetchJson<SongsSearchResponse>(apiUrlFallback);
      } catch (errFallback) {
        console.error(
          "[SongsPage] Fallback /songs/search also failed – using empty result",
          errFallback,
        );
        data = { total: 0, items: [] };
      }
    }

    songs = data.items ?? [];

    // Φόρτωση πραγματικών προβολών
    songs = await Promise.all(
      songs.map(async (song) => {
        try {
          const detail = await fetchJson<any>(
            `/songs/${song.song_id}?noIncrement=1`,
          );

          const views =
            detail && typeof detail.views === "number"
              ? detail.views
              : song.views ?? null;

          return { ...song, views };
        } catch (err) {
          console.error("[SongsPage] Failed to fetch views for song", {
            songId: song.song_id,
            err,
          });
          return song;
        }
      }),
    );

    // Ταξινόμηση κατά δημοφιλία (αν ζητηθεί)
    if (popular === "1") {
      songs.sort((a, b) => {
        const va =
          typeof a.views === "number" && !Number.isNaN(a.views) ? a.views : -1;
        const vb =
          typeof b.views === "number" && !Number.isNaN(b.views) ? b.views : -1;
        return vb - va;
      });
    }
  } catch (errOuter) {
    console.error("[SongsPage] Unexpected error while loading songs", errOuter);
    data = { total: 0, items: [] };
    songs = [];
  }

  // -------------------- Counts για φίλτρα (τρέχουσα σελίδα) --------------------
  const chordsCounts: Record<string, number> = { "1": 0, "0": 0, "null": 0 };
  const partitureCounts: Record<string, number> = { "1": 0, "0": 0, "null": 0 };
  const lyricsCounts: Record<string, number> = { "null": 0 };
  const statusCounts: Record<string, number> = {};

  const characteristicsSet = new Set<string>();
  const characteristicsCountMap: Record<string, number> = {};

  // Αυτά τα maps θα μείνουν, έστω κι αν τελικά χρησιμοποιήσουμε backend counts
  const categoryCountById: Record<string, number> = {};
  const categoryCountByTitle: Record<string, number> = {};
  const rythmCountById: Record<string, number> = {};
  const rythmCountByTitle: Record<string, number> = {};

  for (const song of songs) {
    // chords
    const chordsVal = song.chords;
    if (chordsVal === 1 || chordsVal === "1" || chordsVal === true) {
      chordsCounts["1"]++;
    } else if (
      chordsVal === 0 ||
      chordsVal === "0" ||
      chordsVal === false
    ) {
      chordsCounts["0"]++;
    } else {
      chordsCounts["null"]++;
    }

    // partiture
    const partVal = song.partiture;
    if (partVal === 1 || partVal === "1" || partVal === true) {
      partitureCounts["1"]++;
    } else if (partVal === 0 || partVal === "0" || partVal === false) {
      partitureCounts["0"]++;
    } else {
      partitureCounts["null"]++;
    }

    // lyrics
    const hasLyrics = !!(song.lyrics && song.lyrics.trim().length > 0);
    if (!hasLyrics) {
      lyricsCounts["null"] = (lyricsCounts["null"] || 0) + 1;
    }

    // status
    const st = song.status || "";
    if (st) {
      statusCounts[st] = (statusCounts[st] || 0) + 1;
    }

    // characteristics
    const rawChar = (song.characteristics || "").trim();
    if (rawChar) {
      for (const part of rawChar.split(",")) {
        const v = part.trim();
        if (!v) continue;
        characteristicsSet.add(v);
        characteristicsCountMap[v] = (characteristicsCountMap[v] || 0) + 1;
      }
    }

    // ------- ΚΑΤΗΓΟΡΙΑ από διάφορα πιθανά πεδία (αν υπάρξουν στο μέλλον) -------
    const rawCategoryId =
      song.category_id ??
      song.categoryId ??
      (song as any).category_id ??
      (song as any).categoryId ??
      null;

    if (rawCategoryId !== null && rawCategoryId !== undefined) {
      const cid = String(rawCategoryId);
      categoryCountById[cid] = (categoryCountById[cid] || 0) + 1;
    }

    const rawCategoryTitle =
      song.categoryTitle ??
      song.category ??
      song.category_title ??
      (song as any).categoryTitle ??
      (song as any).category ??
      (song as any).category_title ??
      "";

    const cTitle = String(rawCategoryTitle).trim();
    if (!rawCategoryId && cTitle) {
      categoryCountByTitle[cTitle] =
        (categoryCountByTitle[cTitle] || 0) + 1;
    }

    // ------- ΡΥΘΜΟΣ από διάφορα πιθανά πεδία (αν υπάρξουν στο μέλλον) -------
    const rawRythmId =
      song.rythm_id ??
      song.rythmId ??
      song.rhythm_id ??
      song.rhythmId ??
      (song as any).rythm_id ??
      (song as any).rythmId ??
      (song as any).rhythm_id ??
      (song as any).rhythmId ??
      null;

    if (rawRythmId !== null && rawRythmId !== undefined) {
      const rid = String(rawRythmId);
      rythmCountById[rid] = (rythmCountById[rid] || 0) + 1;
    }

    const rawRythmTitle =
      song.rythmTitle ??
      song.rythm ??
      song.rhythmTitle ??
      (song as any).rhythm ?? // ← ΔΙΟΡΘΩΣΗ: χρησιμοποιούμε any για το rhythm
      (song as any).rythmTitle ??
      (song as any).rythm ??
      (song as any).rhythmTitle ??
      (song as any).rhythm ??
      "";

    const rTitle = String(rawRythmTitle).trim();
    if (!rawRythmId && rTitle) {
      rythmCountByTitle[rTitle] =
        (rythmCountByTitle[rTitle] || 0) + 1;
    }
  }

  const characteristicsList = Array.from(characteristicsSet).sort((a, b) =>
    a.localeCompare(b, "el"),
  );

  const characteristicsOptions: Option[] =
    characteristicsList.length > 0
      ? characteristicsList.map((c) => ({
          value: c,
          label: c,
          count: characteristicsCountMap[c] ?? 0,
        }))
      : [
          {
            value: "Οργανικό",
            label: "Οργανικό",
            count: characteristicsCountMap["Οργανικό"] ?? 0,
          },
        ];

  // -------------------- ΚΑΤΗΓΟΡΙΑ / ΡΥΘΜΟΣ OPTIONS --------------------
  const categoryOptions: Option[] = categories.map((c) => {
    const idKey = String(c.id);
    const fromId = categoryCountById[idKey];
    const fromTitle = categoryCountByTitle[c.title];

    // κύριο fallback: Prisma _count.songs ή άλλα πιθανά numeric fields
    const backendCount =
      (c._count && typeof c._count.songs === "number"
        ? c._count.songs
        : undefined) ??
      (typeof c.songCount === "number" ? c.songCount : undefined) ??
      (typeof c.songsCount === "number" ? c.songsCount : undefined) ??
      (categoryCountKey &&
      typeof (c as any)[categoryCountKey] === "number"
        ? ((c as any)[categoryCountKey] as number)
        : undefined);

    const count =
      fromId !== undefined
        ? fromId
        : fromTitle !== undefined
        ? fromTitle
        : backendCount !== undefined
        ? backendCount
        : 0;

    return {
      value: idKey,
      label: c.title,
      count,
    };
  });

  const rythmOptions: Option[] = rythms.map((r) => {
    const idKey = String(r.id);
    const fromId = rythmCountById[idKey];
    const fromTitle = rythmCountByTitle[r.title];

    const backendCount =
      (r._count && typeof r._count.songs === "number"
        ? r._count.songs
        : undefined) ??
      (typeof r.songCount === "number" ? r.songCount : undefined) ??
      (typeof r.songsCount === "number" ? r.songsCount : undefined) ??
      (rythmCountKey &&
      typeof (r as any)[rythmCountKey] === "number"
        ? ((r as any)[rythmCountKey] as number)
        : undefined);

    const count =
      fromId !== undefined
        ? fromId
        : fromTitle !== undefined
        ? fromTitle
        : backendCount !== undefined
        ? backendCount
        : 0;

    return {
      value: idKey,
      label: r.title,
      count,
    };
  });

  // -------------------- Βοηθητικά URLs --------------------
  const buildPageUrl = (newSkip: number) => {
    const uiParams = new URLSearchParams();
    uiParams.set("take", String(take));
    uiParams.set("skip", String(newSkip));
    if (q) uiParams.set("search_term", q);
    if (chords) uiParams.set("chords", chords);
    if (partiture) uiParams.set("partiture", partiture);
    if (category_id) uiParams.set("category_id", category_id);
    if (rythm_id) uiParams.set("rythm_id", rythm_id);
    if (characteristics) uiParams.set("characteristics", characteristics);
    if (lyrics) uiParams.set("lyrics", lyrics);
    if (status) uiParams.set("status", status);
    if (popular) uiParams.set("popular", popular);
    if (createdByUserId) uiParams.set("createdByUserId", createdByUserId);

    const queryString = uiParams.toString();
    return queryString ? `/songs?${queryString}` : "/songs";
  };

  const buildFilterUrl = (overrides: {
    chords?: string;
    partiture?: string;
    characteristics?: string;
    lyrics?: string;
    popular?: string;
  }) => {
    const uiParams = new URLSearchParams();

    uiParams.set("take", String(take));
    uiParams.set("skip", "0");

    if (q) uiParams.set("search_term", q);

    uiParams.set("chords", overrides.chords ?? chords ?? "");
    uiParams.set("partiture", overrides.partiture ?? partiture ?? "");
    uiParams.set(
      "characteristics",
      overrides.characteristics ?? characteristics ?? "",
    );
    uiParams.set("lyrics", overrides.lyrics ?? lyrics ?? "");
    uiParams.set("popular", overrides.popular ?? popular ?? "");

    if (category_id) uiParams.set("category_id", category_id);
    if (rythm_id) uiParams.set("rythm_id", rythm_id);
    if (status) uiParams.set("status", status);
    if (createdByUserId) uiParams.set("createdByUserId", createdByUserId);

    ["chords", "partiture", "characteristics", "lyrics", "popular"].forEach(
      (key) => {
        if (!uiParams.get(key)) uiParams.delete(key);
      },
    );

    const qs = uiParams.toString();
    return qs ? `/songs?${qs}` : "/songs";

  };

  const hasPrev = skip > 0;
  const hasNext = skip + take < data.total;

  // Υπολογισμός max score για σχετική βαθμολογία (0–100)
  const maxScore =
    songs.length > 0
      ? songs.reduce((max, s) => {
          const val =
            typeof s.score === "number" && !Number.isNaN(s.score)
              ? s.score
              : 0;
          return val > max ? val : max;
        }, 0)
      : 0;

  // -------------------- Render --------------------
  return (
    <section style={{ padding: "16px 24px" }}>
      <h1 style={{ fontSize: "1.6rem", marginBottom: 12 }}>
        Αναζήτηση τραγουδιών
      </h1>

      <header style={{ marginBottom: 12 }}>
        <p style={{ marginTop: 4 }}>
          Βρέθηκαν <strong>{data.total}</strong> τραγούδια.
        </p>
        {q && (
          <p style={{ marginTop: 4 }}>
            Φράση αναζήτησης: <strong>{q}</strong>
          </p>
        )}
      </header>

      {/* Γρήγορα φίλτρα + κουμπί Modal φίλτρων */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          gap: 8,
          marginBottom: 12,
        }}
      >
        <Link
          href={buildFilterUrl({ chords: chords === "1" ? "" : "1" })}
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border: chords === "1" ? "2px solid #fff" : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
          }}
        >
          🎸 Με συγχορδίες
        </Link>

        <Link
          href={buildFilterUrl({
            partiture: partiture === "1" ? "" : "1",
          })}
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border: partiture === "1" ? "2px solid #fff" : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
          }}
        >
          🎼 Με παρτιτούρα
        </Link>

        <Link
          href={buildFilterUrl({
            lyrics: lyrics === "null" ? "" : "null",
          })}
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border: lyrics === "null" ? "2px solid #fff" : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
          }}
        >
          📜 Χωρίς στίχους
        </Link>

        <Link
          href={buildFilterUrl({
            characteristics:
              characteristics === "Οργανικό" ? "" : "Οργανικό",
          })}
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border:
              characteristics === "Οργανικό"
                ? "2px solid #fff"
                : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
          }}
        >
          🌿 Οργανικό
        </Link>

        <Link
          href={buildFilterUrl({
            popular: popular === "1" ? "" : "1",
          })}
          style={{
            padding: "4px 10px",
            borderRadius: 16,
            border: popular === "1" ? "2px solid #fff" : "1px solid #666",
            backgroundColor: "#111",
            fontSize: "0.9rem",
            whiteSpace: "nowrap",
          }}
        >
          ⭐ Δημοφιλή
        </Link>

        <div style={{ marginLeft: "auto" }}>
          <FiltersModal
            q={q}
            take={take}
            skip={skip}
            chords={chords}
            partiture={partiture}
            category_id={category_id}
            rythm_id={rythm_id}
            characteristics={characteristics}
            lyrics={lyrics}
            status={status}
            popular={popular}
            createdByUserId={createdByUserId}
            categoryOptions={categoryOptions}
            rythmOptions={rythmOptions}
            characteristicsOptions={characteristicsOptions}
            chordsCounts={chordsCounts}
            partitureCounts={partitureCounts}
            lyricsCounts={lyricsCounts}
            statusCounts={statusCounts}
          />
        </div>
      </div>

      {/* Λίστα τραγουδιών */}
      {songs.length === 0 ? (
        <p>Δεν βρέθηκαν τραγούδια.</p>
      ) : (
        <div id="songs-list">
          <ul style={{ listStyleType: "none", padding: 0, margin: 0 }}>
            {songs.map((song) => {
              const youtubeUrl = buildYoutubeUrl(song);
              const lyricsPreview = buildLyricsPreview(song);

              const hasViews =
                song.views !== null &&
                song.views !== undefined &&
                !Number.isNaN(song.views);

              const rawScore =
                typeof song.score === "number" && !Number.isNaN(song.score)
                  ? song.score
                  : null;

              const displayScore =
                rawScore !== null && maxScore > 0
                  ? (rawScore / maxScore) * 100
                  : rawScore;

              const hasScore =
                displayScore !== null && typeof displayScore === "number";

              return (
                <li
                  key={song.song_id}
                  className="song-item"
                  style={{
                    padding: "3px 0",
                  }}
                >
                  <div
                    className="icons-and-title"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      marginBottom: 2,
                    }}
                  >
                    <a
                      href={youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-block",
                        marginRight: 5,
                        verticalAlign: "middle",
                      }}
                      title="YouTube"
                    >
                      <img
                        src={YOUTUBE_ICON_URL}
                        alt="YouTube"
                        style={{
                          width: 25,
                          verticalAlign: "middle",
                          display: "block",
                        }}
                      />
                    </a>

                    <Link
                      className="song-title"
                      href={`/songs/${song.song_id}`}
                      style={{
                        color: "#fff",
                        fontWeight: 700,
                        textDecoration: "none",
                        whiteSpace: "nowrap",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        maxWidth: "650px",
                      }}
                    >
                      {song.chords ? (
                        <img
                          src={GUITAR_ICON_URL}
                          alt="Chords"
                          style={{
                            width: 25,
                            marginRight: 5,
                            verticalAlign: "middle",
                            display: "inline-block",
                          }}
                        />
                      ) : null}
                      {song.partiture ? (
                        <img
                          src={SOL_ICON_URL}
                          alt="Partiture"
                          style={{
                            width: 25,
                            marginRight: 5,
                            verticalAlign: "middle",
                            display: "inline-block",
                          }}
                        />
                      ) : null}
                      {song.title || "(χωρίς τίτλο)"}
                    </Link>
                  </div>

                  {hasViews && (
                    <span
                      className="song-views"
                      style={{
                        display: "inline-block",
                        marginLeft: 8,
                        fontSize: "0.8rem",
                        color: "#ccc",
                        whiteSpace: "nowrap",
                        verticalAlign: "baseline",
                      }}
                      title={`${song.views} προβολές`}
                    >
                      👁 {song.views}
                    </span>
                  )}

                  {hasScore && displayScore !== null && (
                    <span
                      className="song-score"
                      style={{
                        display: "inline-block",
                        marginLeft: 8,
                        fontSize: "0.8rem",
                        color: "#ffd700",
                        whiteSpace: "nowrap",
                        verticalAlign: "baseline",
                      }}
                      title={`Βαθμολογία: ${displayScore.toFixed(1)} / 100`}
                    >
                      ⭐ {displayScore.toFixed(1)}
                    </span>
                  )}

                  <span
                    className="song-lyrics"
                    style={{
                      display: "inline-block",
                      marginLeft: 5,
                      fontStyle: "italic",
                      color: "darkgray",
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                      overflow: "hidden",
                      maxWidth: "700px",
                      verticalAlign: "baseline",
                    }}
                    title={lyricsPreview}
                  >
                    {" "}
                    {lyricsPreview}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* Pagination */}
      <div
        style={{
          marginTop: 16,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          fontSize: "0.9rem",
        }}
      >
        <div>
          Εμφάνιση από <strong>{skip + 1}</strong> έως{" "}
          <strong>{Math.min(skip + take, data.total)}</strong> από{" "}
          <strong>{data.total}</strong> τραγούδια.
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {hasPrev && (
            <Link
              href={buildPageUrl(Math.max(skip - take, 0))}
              style={{
                padding: "4px 10px",
                borderRadius: 4,
                border: "1px solid #555",
                backgroundColor: "#000",
              }}
            >
              ◀ Προηγούμενα
            </Link>
          )}
          {hasNext && (
            <Link
              href={buildPageUrl(skip + take)}
              style={{
                padding: "4px 10px",
                borderRadius: 4,
                border: "1px solid #555",
                backgroundColor: "#000",
              }}
            >
              Επόμενα ▶
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
